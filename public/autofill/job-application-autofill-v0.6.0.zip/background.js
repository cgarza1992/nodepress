// src/ai/providers/ollama.ts
var SYSTEM = `You map a job-application form field to the applicant's data.
Return STRICT JSON: {"value": string, "confidence": number 0..1, "reason": short string}.
Rules:
- If kind is "map": pick the value FROM THE APPLICANT PROFILE that answers this field. Use only values present in the profile \u2014 never invent, guess, or reformat a fact (email, phone, name, URL, address). If the field has options, value MUST be one of them exactly. If nothing in the profile fits, value "" and confidence 0.
- If kind is "generate": write a concise, specific answer in the applicant's first-person voice using ONLY facts from their profile. The answer must be ABOUT THE APPLICANT \u2014 their real work and experience \u2014 not about the company. Use the job posting ONLY to decide which of the applicant's experiences to emphasize; do NOT quote it, paraphrase it, echo its buzzwords, or list its requirements back. Naming the company once is fine; restating what the company says it wants is not. Replace any [COMPANY]/[ROLE]/[BRACKET] placeholders with real details and NEVER output brackets. Write like a real person, not an AI: plain, direct sentences and natural contractions. Do NOT use em-dashes or en-dashes (\u2014 \u2013); use commas or periods. Avoid AI-tell words (delve, tapestry, testament, boasts, moreover, furthermore, seamless, navigating, "in the realm of", "it's worth noting", "leverage" as a verb). Do not invent facts about the applicant.
- Never output anything except the JSON object.`;
function buildPrompt(item) {
  const f = item.field;
  return [
    `kind: ${item.kind}`,
    `field label: ${f.label || "(none)"}`,
    `field type: ${f.type}`,
    f.group ? `section: ${f.group}` : "",
    f.options ? `options: ${JSON.stringify(f.options.map((o) => o.label))}` : "",
    item.kind === "generate" && item.jobContext ? `job posting (tailor to this; do not fabricate applicant facts):
${item.jobContext}` : "",
    `applicant profile: ${JSON.stringify(item.profile)}`
  ].filter(Boolean).join("\n");
}
var PLACEHOLDER = /\[[A-Za-z][A-Za-z0-9 _/-]*\]/;
function parse(out) {
  try {
    const obj = typeof out === "string" ? JSON.parse(out) : out;
    const value = String(obj.value ?? "");
    if (PLACEHOLDER.test(value)) {
      return {
        value: "",
        confidence: 0,
        reason: "model returned a template \u2014 write this one yourself",
        source: "ollama"
      };
    }
    let c = Number(obj.confidence);
    if (!isFinite(c)) c = 0;
    c = Math.max(0, Math.min(1, c));
    return { value, confidence: c, reason: String(obj.reason || "model"), source: "ollama" };
  } catch {
    return { value: "", confidence: 0, reason: "unparseable model output", source: "ollama" };
  }
}
async function OllamaProvider(items, cfg) {
  const host = cfg.host || "http://localhost:11434";
  const model = cfg.model || "llama3.1";
  const system = cfg.styleNote?.trim() ? `${SYSTEM}
- WRITING VOICE (follow this for "generate" answers; it overrides the default phrasing): ${cfg.styleNote.trim()}` : SYSTEM;
  const results = [];
  for (const item of items) {
    try {
      const res = await fetch(`${host}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          system,
          prompt: buildPrompt(item),
          format: "json",
          stream: false,
          options: { temperature: 0 }
        })
      });
      if (!res.ok) {
        throw new Error(
          res.status === 403 ? "HTTP 403 \u2014 Ollama blocked the extension's origin. Restart it with OLLAMA_ORIGINS='chrome-extension://*'" : "HTTP " + res.status
        );
      }
      const data = await res.json();
      const parsed = parse(data.response);
      if (item.kind === "generate") parsed.confidence = Math.min(parsed.confidence, 0.6);
      results.push(parsed);
    } catch (e) {
      results.push({
        value: "",
        confidence: 0,
        reason: "ollama error: " + (e instanceof Error ? e.message : String(e)),
        source: "ollama"
      });
    }
  }
  return results;
}

// src/shared/humanize.ts
var matchCase = (word, sample) => sample && sample[0] === sample[0].toUpperCase() ? word[0].toUpperCase() + word.slice(1) : word;
var WORD_SWAPS = {
  leverage: "use",
  leverages: "uses",
  leveraged: "used",
  leveraging: "using",
  utilize: "use",
  utilizes: "uses",
  utilized: "used",
  utilizing: "using",
  seamless: "smooth",
  seamlessly: "smoothly",
  showcase: "show",
  showcases: "shows",
  showcased: "showed",
  showcasing: "showing",
  spearhead: "lead",
  spearheaded: "led",
  spearheading: "leading",
  "delve into": "dig into",
  "delved into": "dug into",
  "myriad of": "many",
  "plethora of": "plenty of",
  robust: "solid",
  "cutting-edge": "modern",
  "state-of-the-art": "modern"
};
var escapeRe = (s) => s.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
function destyle(text) {
  let s = text;
  s = s.replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/…/g, "...");
  s = s.replace(
    /\b(Moreover|Furthermore|Additionally|In addition|Notably|Importantly|Overall|In conclusion|Ultimately),\s*/g,
    ""
  );
  for (const [from, to] of Object.entries(WORD_SWAPS)) {
    s = s.replace(new RegExp(`\\b${escapeRe(from)}\\b`, "gi"), (m) => matchCase(to, m));
  }
  s = s.replace(/(^|[.!?]\s+)([a-z])/g, (_, p, c) => p + c.toUpperCase());
  return s;
}
function humanize(text, level = "standard") {
  if (!text || level === "off") return text;
  let s = text;
  s = s.replace(/(\d)\s*[–—]\s*(\d)/g, "$1-$2");
  s = s.replace(/\s*(?:—|–|―|--)\s*/g, ", ");
  if (level === "strong") s = destyle(s);
  s = s.replace(/,\s*([,.;:!?])/g, "$1");
  s = s.replace(/\s+([,.;:!?])/g, "$1");
  s = s.replace(/\s{2,}/g, " ");
  s = s.replace(/^\s*,\s*/, "");
  return s.trim();
}

// src/ai/provider.ts
var NoneProvider = async (items) => items.map(() => ({ value: "", confidence: 0, reason: "no model configured", source: "none" }));
var PROVIDERS = {
  none: NoneProvider,
  ollama: OllamaProvider
};
async function getConfig() {
  const { aiConfig } = await chrome.storage.local.get("aiConfig");
  const cfg = aiConfig;
  return {
    provider: cfg?.provider ?? "none",
    host: cfg?.host ?? "http://localhost:11434",
    model: cfg?.model ?? "llama3.1",
    humanizeLevel: cfg?.humanizeLevel ?? "standard",
    styleNote: cfg?.styleNote ?? ""
  };
}
async function resolveFields(items) {
  const cfg = await getConfig();
  const provider = PROVIDERS[cfg.provider] ?? NoneProvider;
  try {
    const results = await provider(items, cfg);
    if (!Array.isArray(results)) return [];
    return results.map(
      (r, i) => items[i]?.kind === "generate" && r.value ? { ...r, value: humanize(r.value, cfg.humanizeLevel) } : r
    );
  } catch (e) {
    return items.map(() => ({
      value: "",
      confidence: 0,
      reason: "provider error: " + (e instanceof Error ? e.message : String(e)),
      source: cfg.provider
    }));
  }
}

// src/ai/resume.ts
var SYSTEM2 = `Extract the resume into STRICT JSON matching EXACTLY this shape (no extra keys, no prose):
{"identity":{"firstName":"","lastName":"","email":"","phone":"","city":"","state":"","postal":"","country":""},
"links":{"linkedin":"","github":"","portfolio":""},
"work":[{"company":"","title":"","location":"","start":"","end":"","current":false,"description":""}],
"education":[{"school":"","degree":"","fieldOfStudy":"","gpa":""}],
"skills":["..."]}
Rules:
- Use "" for anything not present. Never invent facts.
- Dates as "YYYY-MM" (or just the year if that's all that's given); end "" and current true for the present role.
- description: one or two sentences summarizing that role's bullet points / impact.
- skills: a flat list of individual technologies/skills.
- Output ONLY the JSON object.`;
async function parseResume(text, cfg) {
  const host = cfg.host || "http://localhost:11434";
  const model = cfg.model || "llama3.1";
  const res = await fetch(`${host}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      system: SYSTEM2,
      prompt: `RESUME:
${text}`,
      format: "json",
      stream: false,
      options: { temperature: 0 }
    })
  });
  if (!res.ok) {
    throw new Error(
      res.status === 403 ? "Ollama blocked the extension's origin. Restart it with OLLAMA_ORIGINS='chrome-extension://*'." : "Ollama HTTP " + res.status
    );
  }
  const data = await res.json();
  try {
    return JSON.parse(String(data.response ?? "{}"));
  } catch {
    throw new Error("Ollama returned unparseable output \u2014 try again or shorten the resume.");
  }
}

// src/shared/drafts.ts
var KEY = "drafts";
var CAP = 15;
var JOB_KEY = "draftJob";
var JOB_STALE_MS = 4 * 60 * 1e3;
async function setDraftJob(job) {
  if (job) await chrome.storage.local.set({ [JOB_KEY]: job });
  else await chrome.storage.local.remove(JOB_KEY);
}
var queue = Promise.resolve();
function serialize(fn) {
  const run = queue.then(fn, fn);
  queue = run.catch(() => void 0);
  return run;
}
function newId() {
  return "d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
var escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
async function loadDrafts() {
  const o = await chrome.storage.local.get(KEY);
  const list = o[KEY];
  return Array.isArray(list) ? list : [];
}
function saveVariant(baseTitle, text) {
  return serialize(async () => {
    const list = await loadDrafts();
    const base = baseTitle.trim() || "Draft";
    const re = new RegExp(`^${escapeRegExp(base)} (\\d+)$`);
    let max = 0;
    for (const d of list) {
      const m = re.exec(d.title);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    const rec = { id: newId(), title: `${base} ${max + 1}`, text, at: Date.now() };
    list.push(rec);
    const trimmed = list.sort((a, b) => b.at - a.at).slice(0, CAP);
    await chrome.storage.local.set({ [KEY]: trimmed });
    return rec;
  });
}

// src/shared/tracking.ts
var DEFAULT_TRACKING = {
  notionEnabled: false,
  notionToken: "",
  notionDatabaseId: ""
};
function cleanUrl(raw) {
  try {
    const u = new URL(raw);
    return (u.origin + u.pathname).replace(/\/+$/, "");
  } catch {
    return raw.trim();
  }
}
function recordKey(r) {
  return `${cleanUrl(r.url)}::${r.role.trim().toLowerCase()}`;
}
function makeRecord(input, now) {
  const role = (input.role ?? "").trim();
  const url = cleanUrl(input.url);
  return {
    id: input.id ?? recordKey({ url, role }),
    company: (input.company ?? "").trim(),
    role,
    url,
    board: input.board,
    status: input.status ?? "applied",
    appliedAt: input.appliedAt ?? now,
    notes: (input.notes ?? "").trim(),
    ...input.notionPageId ? { notionPageId: input.notionPageId } : {}
  };
}
function upsert(list, rec) {
  const key = recordKey(rec);
  const prior = list.find((r) => recordKey(r) === key);
  const merged = {
    ...rec,
    appliedAt: prior?.appliedAt ?? rec.appliedAt,
    ...prior?.notionPageId ? { notionPageId: prior.notionPageId } : {},
    ...rec.notionPageId ? { notionPageId: rec.notionPageId } : {}
  };
  const rest = list.filter((r) => recordKey(r) !== key);
  return [merged, ...rest];
}
var NOTION_API = "https://api.notion.com/v1";
var NOTION_VERSION = "2025-09-03";
function findProp(schema, keywords, types) {
  for (const [name, def] of Object.entries(schema)) {
    const lower = name.toLowerCase();
    if (types.includes(def.type) && keywords.some((k) => lower.includes(k))) {
      return { name, type: def.type, options: def.options };
    }
  }
  return null;
}
function resolveChoice(col, text) {
  if (col.type !== "select" && col.type !== "status") return text;
  const hit = col.options?.find((o) => o.toLowerCase() === text.toLowerCase());
  if (hit) return hit;
  return col.type === "select" ? text : null;
}
function titleProp(schema) {
  for (const [name, def] of Object.entries(schema)) {
    if (def.type === "title") return name;
  }
  return null;
}
function valueFor(type, text) {
  switch (type) {
    case "title":
      return { title: [{ text: { content: text } }] };
    case "rich_text":
      return { rich_text: [{ text: { content: text } }] };
    case "url":
      return { url: text || null };
    case "select":
      return text ? { select: { name: text } } : null;
    case "status":
      return text ? { status: { name: text } } : null;
    case "date":
      return text ? { date: { start: text } } : null;
    default:
      return null;
  }
}
function notionPropsFor(schema, rec) {
  const props = {};
  const set = (col, text) => {
    if (!col) return;
    const resolved = resolveChoice(col, text);
    if (resolved == null) return;
    const v = valueFor(col.type, resolved);
    if (v) props[col.name] = v;
  };
  const title = titleProp(schema);
  if (title) set({ name: title, type: "title" }, rec.company || rec.role || "Untitled");
  set(findProp(schema, ["role", "position", "job"], ["rich_text", "select"]), rec.role);
  set(findProp(schema, ["url", "link", "posting"], ["url", "rich_text"]), rec.url);
  set(findProp(schema, ["status", "stage"], ["status", "select"]), rec.status);
  set(findProp(schema, ["board", "source", "site"], ["select", "rich_text"]), rec.board);
  const dateCol = findProp(schema, ["applied"], ["date"]) ?? findProp(schema, ["date"], ["date"]);
  set(dateCol, rec.appliedAt);
  if (rec.notes) set(findProp(schema, ["note", "comment"], ["rich_text"]), rec.notes);
  return props;
}

// src/background.ts
console.log("[autofill] worker ready");
var CONTENT_BUNDLE = "content.js";
var RESTRICTED = /^(chrome|edge|brave|about|chrome-extension|moz-extension|devtools|view-source|file):/i;
async function runOn(tab) {
  if (!tab || !tab.id || !tab.url) {
    console.warn("[autofill] no active tab");
    return;
  }
  if (RESTRICTED.test(tab.url)) {
    console.warn("[autofill] can't run on a browser page:", tab.url);
    return;
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: [CONTENT_BUNDLE]
    });
    console.log("[autofill] content injected");
  } catch (e) {
    console.error("[autofill] injection failed:", e);
  }
}
chrome.action.onClicked.addListener((tab) => void runOn(tab));
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "run-autofill") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  void runOn(tab);
});
var handledTabs = /* @__PURE__ */ new Map();
chrome.runtime.onMessage.addListener(
  (msg, sender, sendResponse) => {
    if (msg && msg.type === "af:handled") {
      const id = sender.tab?.id;
      if (id != null) handledTabs.set(id, Date.now());
      return void 0;
    }
    if (msg && msg.type === "af:wasHandled") {
      const id = sender.tab?.id;
      const ts = id != null ? handledTabs.get(id) : void 0;
      sendResponse({ handled: ts != null && Date.now() - ts < 4e3 });
      return true;
    }
    if (msg && msg.type === "resolveFields") {
      resolveFields(msg.items ?? []).then((results) => sendResponse({ results })).catch((e) => sendResponse({ error: e instanceof Error ? e.message : String(e) }));
      return true;
    }
    if (msg && msg.type === "af:coverLetter") {
      void (async () => {
        const items = msg.items ?? [];
        await setDraftJob({ label: "Cover letter", count: items.length, startedAt: Date.now() });
        try {
          const results = await resolveFields(items);
          const drafts = [];
          for (const r of results) {
            const text = r?.value ?? "";
            if (text) drafts.push(await saveVariant("Cover letter", text));
          }
          await setDraftJob(null);
          sendResponse({ drafts });
        } catch (e) {
          await setDraftJob(null);
          sendResponse({ error: e instanceof Error ? e.message : String(e) });
        }
      })();
      return true;
    }
    if (msg && msg.type === "parseResume") {
      (async () => {
        const { aiConfig } = await chrome.storage.local.get("aiConfig");
        const cfg = {
          provider: "ollama",
          host: "http://localhost:11434",
          model: "llama3.1",
          humanizeLevel: "standard",
          styleNote: "",
          ...aiConfig
        };
        return parseResume(msg.text ?? "", cfg);
      })().then((profile) => sendResponse({ profile })).catch((e) => sendResponse({ error: e instanceof Error ? e.message : String(e) }));
      return true;
    }
    return void 0;
  }
);
async function getTracking() {
  const { trackingConfig } = await chrome.storage.local.get("trackingConfig");
  return { ...DEFAULT_TRACKING, ...trackingConfig };
}
async function getApplications() {
  const { applications } = await chrome.storage.local.get("applications");
  return Array.isArray(applications) ? applications : [];
}
function notionHeaders(token) {
  return {
    Authorization: `Bearer ${token}`,
    "Notion-Version": NOTION_VERSION,
    "Content-Type": "application/json"
  };
}
async function notionError(res) {
  try {
    const body = await res.json();
    return body.message || `Notion error ${res.status}`;
  } catch {
    return `Notion error ${res.status}`;
  }
}
async function notionSchema(cfg) {
  const id = cfg.notionDatabaseId?.trim();
  if (!id)
    return { ok: false, error: "No Notion database link set \u2014 add it in Options \u2192 Application tracking." };
  const headers = notionHeaders(cfg.notionToken);
  let dataSourceId = "";
  let dbTitle = "";
  const dbRes = await fetch(`${NOTION_API}/databases/${id}`, { headers });
  if (dbRes.ok) {
    const db = await dbRes.json();
    dbTitle = db.title?.map((t) => t.plain_text ?? "").join("") || "";
    dataSourceId = db.data_sources?.[0]?.id ?? "";
    if (!dataSourceId)
      return {
        ok: false,
        error: "That database isn't shared with your integration (or has no data source). In Notion: open it \u2192 \u22EF \u2192 Connections \u2192 add your integration."
      };
  } else if (dbRes.status === 404) {
    dataSourceId = id;
  } else {
    return { ok: false, error: await notionError(dbRes) };
  }
  const dsRes = await fetch(`${NOTION_API}/data_sources/${dataSourceId}`, { headers });
  if (!dsRes.ok) return { ok: false, error: await notionError(dsRes) };
  const ds = await dsRes.json();
  const schema = {};
  for (const [name, def] of Object.entries(ds.properties ?? {})) {
    const options = (def.select?.options ?? def.status?.options)?.map((o) => o.name);
    schema[name] = options ? { type: def.type, options } : { type: def.type };
  }
  const title = ds.title?.map((t) => t.plain_text ?? "").join("") || dbTitle || "(untitled database)";
  return { ok: true, schema, title, dataSourceId };
}
async function notionSync(cfg, rec) {
  const schema = await notionSchema(cfg);
  if (!schema.ok || !schema.schema || !schema.dataSourceId)
    return { ok: false, error: schema.error };
  const properties = notionPropsFor(schema.schema, rec);
  if (rec.notionPageId) {
    const res2 = await fetch(`${NOTION_API}/pages/${rec.notionPageId}`, {
      method: "PATCH",
      headers: notionHeaders(cfg.notionToken),
      body: JSON.stringify({ properties })
    });
    if (!res2.ok) return { ok: false, error: await notionError(res2) };
    return { ok: true, pageId: rec.notionPageId };
  }
  const res = await fetch(`${NOTION_API}/pages`, {
    method: "POST",
    headers: notionHeaders(cfg.notionToken),
    body: JSON.stringify({
      parent: { type: "data_source_id", data_source_id: schema.dataSourceId },
      properties
    })
  });
  if (!res.ok) return { ok: false, error: await notionError(res) };
  const page = await res.json();
  return { ok: true, pageId: page.id };
}
async function handleSave(input) {
  const rec = makeRecord(input, (/* @__PURE__ */ new Date()).toISOString());
  let list = await getApplications();
  const prior = list.find((r) => r.id === rec.id);
  if (prior?.notionPageId) rec.notionPageId = prior.notionPageId;
  list = upsert(list, rec);
  await chrome.storage.local.set({ applications: list });
  const cfg = await getTracking();
  if (!cfg.notionEnabled || !cfg.notionToken || !cfg.notionDatabaseId) {
    return { record: rec, notion: { ok: false, error: "Notion off" } };
  }
  const sync = await notionSync(cfg, rec);
  if (sync.ok && sync.pageId && sync.pageId !== rec.notionPageId) {
    rec.notionPageId = sync.pageId;
    await chrome.storage.local.set({ applications: upsert(await getApplications(), rec) });
  }
  return { record: rec, notion: { ok: sync.ok, error: sync.error } };
}
async function handleSetStatus(id, status) {
  const list = await getApplications();
  const rec = list.find((r) => r.id === id);
  if (!rec) return { ok: false, error: "not found" };
  rec.status = status;
  await chrome.storage.local.set({ applications: list });
  const cfg = await getTracking();
  if (cfg.notionEnabled && rec.notionPageId && cfg.notionToken) {
    const sync = await notionSync(cfg, rec);
    return { ok: sync.ok, error: sync.error };
  }
  return { ok: true };
}
async function handleSyncAll() {
  const cfg = await getTracking();
  if (!cfg.notionEnabled || !cfg.notionToken || !cfg.notionDatabaseId)
    return {
      synced: 0,
      failed: 0,
      total: 0,
      error: "Notion is off \u2014 enable it and set the database link in Options first."
    };
  const list = await getApplications();
  const pending = list.filter((r) => !r.notionPageId);
  let synced = 0;
  let failed = 0;
  let firstErr = "";
  for (const rec of pending) {
    const sync = await notionSync(cfg, rec);
    if (sync.ok && sync.pageId) {
      rec.notionPageId = sync.pageId;
      synced++;
    } else {
      failed++;
      if (!firstErr) firstErr = sync.error ?? "unknown";
    }
  }
  await chrome.storage.local.set({ applications: list });
  return { synced, failed, total: pending.length, error: failed ? firstErr : void 0 };
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg.type !== "string" || !msg.type.startsWith("track:")) return void 0;
  const fail = (e) => sendResponse({ error: e instanceof Error ? e.message : String(e) });
  switch (msg.type) {
    case "track:save":
      handleSave(msg.input).then(sendResponse).catch(fail);
      return true;
    case "track:list":
      getApplications().then((applications) => sendResponse({ applications })).catch(fail);
      return true;
    case "track:setStatus":
      handleSetStatus(msg.id, msg.status).then(sendResponse).catch(fail);
      return true;
    case "track:syncAll":
      handleSyncAll().then(sendResponse).catch(fail);
      return true;
    case "track:testNotion":
      notionSchema(msg.config).then(sendResponse).catch(fail);
      return true;
    default:
      return void 0;
  }
});
