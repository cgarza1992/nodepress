"use strict";
(() => {
  // src/options/profile.default.ts
  var DEFAULT_PROFILE = {
    identity: {
      firstName: "",
      middleName: "",
      lastName: "",
      preferredName: "",
      email: "",
      altEmail: "",
      phone: "",
      extension: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      postal: "",
      county: "",
      country: "United States of America",
      workAuthorized: "",
      needsSponsorship: "",
      willingToRelocate: "",
      phoneType: "",
      hearAboutUs: "",
      countryPhoneCode: ""
    },
    links: { linkedin: "", portfolio: "", github: "" },
    work: [],
    education: [],
    skills: [],
    certifications: [],
    compensation: {
      directHireMin: null,
      directHireMax: null,
      hourlyW2: "",
      hourly1099: "",
      currency: "USD",
      desiredSalary: null,
      note: ""
    },
    answers: {
      summary: "",
      whyCompany: "",
      strength: "",
      whyLeaving: "",
      salaryText: "",
      experienceBlock: "",
      highlights: "",
      experienceYears: {}
    }
  };

  // src/shared/tracking.ts
  var DEFAULT_TRACKING = {
    notionEnabled: false,
    notionToken: "",
    notionDatabaseId: ""
  };
  var STATUSES = [
    "applied",
    "interview",
    "offer",
    "rejected",
    "withdrawn"
  ];
  function toCsv(apps) {
    const cols = [
      ["Company", (a) => a.company],
      ["Role", (a) => a.role],
      ["Status", (a) => a.status],
      ["Applied", (a) => a.appliedAt],
      ["Board", (a) => a.board],
      ["URL", (a) => a.url],
      ["Notes", (a) => a.notes]
    ];
    const cell = (v) => {
      const s = v ?? "";
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const header = cols.map(([name]) => name).join(",");
    const rows = apps.map((a) => cols.map(([, get]) => cell(String(get(a) ?? ""))).join(","));
    return [header, ...rows].join("\r\n");
  }
  function parseNotionId(input) {
    const path = (input || "").trim().split(/[?#]/)[0];
    const compact = path.replace(/-/g, "");
    const runs = compact.match(/[0-9a-fA-F]{32}/g);
    return runs ? runs[runs.length - 1].toLowerCase() : "";
  }

  // src/shared/profile-schema.ts
  var EMPTY = {
    identity: {
      firstName: "",
      middleName: "",
      lastName: "",
      preferredName: "",
      email: "",
      altEmail: "",
      phone: "",
      extension: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      postal: "",
      county: "",
      country: "United States of America",
      workAuthorized: "",
      needsSponsorship: "",
      willingToRelocate: "",
      phoneType: "",
      hearAboutUs: "",
      countryPhoneCode: ""
    },
    links: { linkedin: "", portfolio: "", github: "" },
    work: [],
    education: [],
    skills: [],
    certifications: [],
    compensation: {
      directHireMin: null,
      directHireMax: null,
      hourlyW2: "",
      hourly1099: "",
      currency: "USD",
      desiredSalary: null,
      note: ""
    },
    answers: {
      summary: "",
      whyCompany: "",
      strength: "",
      whyLeaving: "",
      salaryText: "",
      experienceBlock: "",
      highlights: "",
      experienceYears: {}
    }
  };
  function normalize(p) {
    const out = structuredClone(EMPTY);
    if (!p || typeof p !== "object") return out;
    const src = p;
    const target = out;
    for (const section2 of Object.keys(EMPTY)) {
      const base = EMPTY[section2];
      const val = src[section2];
      if (Array.isArray(base)) {
        target[section2] = Array.isArray(val) ? val : [];
      } else {
        target[section2] = { ...base, ...val ?? {} };
      }
    }
    return out;
  }

  // src/options/profile-form.ts
  var esc = (s) => String(s ?? "").replace(
    /[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c
  );
  var fid = (path) => "pf-" + path.replace(/[^a-z0-9]/gi, "-");
  var text = (path, label, value, type = "text", placeholder = "") => {
    const id = fid(path);
    const ph = placeholder ? ` placeholder="${esc(placeholder)}"` : "";
    return `<div class="field"><label for="${id}">${esc(label)}</label><input id="${id}" data-f="${path}" type="${type}" value="${esc(value)}"${ph}></div>`;
  };
  var area = (path, label, value, hint = "") => {
    const id = fid(path);
    return `<div class="field"><label for="${id}">${esc(label)}</label>${hint ? `<div class="fhint">${esc(hint)}</div>` : ""}<textarea id="${id}" data-f="${path}">${esc(value)}</textarea></div>`;
  };
  var yesno = (path, label, value) => {
    const id = fid(path);
    const v = String(value ?? "");
    const opt = (o) => `<option ${v === o ? "selected" : ""}>${o}</option>`;
    return `<div class="field"><label for="${id}">${esc(label)}</label><select id="${id}" data-f="${path}"><option value=""></option>${opt("Yes")}${opt("No")}</select></div>`;
  };
  var cardSeq = 0;
  function workCardHTML(e) {
    const w = e ?? {};
    const n = ++cardSeq;
    const f = (k, l, v, type = "text") => {
      const id = `w${n}-${k}`;
      return `<div class="field"><label for="${id}">${l}</label><input id="${id}" data-w="${k}" type="${type}" value="${esc(v)}"></div>`;
    };
    return `<div class="card work-card">
    <div class="card-head"><b>Role</b><button type="button" class="btn mini" data-remove>Remove</button></div>
    <div class="grid2">${f("company", "Company", w.company)}${f("title", "Title", w.title)}</div>
    <div class="grid2">${f("location", "Location", w.location)}
      <div class="field"><label class="chk"><input data-w="current" type="checkbox" ${w.current ? "checked" : ""}> Current role</label></div></div>
    <div class="grid2">${f("start", "Start (YYYY-MM)", w.start)}${f("end", "End (YYYY-MM or present)", w.end)}</div>
    <div class="field"><label for="w${n}-description">What you did / impact</label><textarea id="w${n}-description" data-w="description">${esc(w.description)}</textarea></div>
  </div>`;
  }
  function eduCardHTML(e) {
    const d = e ?? {};
    const n = ++cardSeq;
    const f = (k, l, v) => {
      const id = `e${n}-${k}`;
      return `<div class="field"><label for="${id}">${l}</label><input id="${id}" data-e="${k}" value="${esc(v)}"></div>`;
    };
    return `<div class="card edu-card">
    <div class="card-head"><b>Education</b><button type="button" class="btn mini" data-remove>Remove</button></div>
    <div class="grid2">${f("school", "School", d.school)}${f("degree", "Degree", d.degree)}</div>
    <div class="grid2">${f("fieldOfStudy", "Field of study", d.fieldOfStudy)}${f("gpa", "GPA (optional)", d.gpa)}</div>
  </div>`;
  }
  var section = (title, body, open = false) => `<details class="sec"${open ? " open" : ""}><summary>${title}</summary><div class="sec-body">${body}</div></details>`;
  function experienceLines(map) {
    return Object.entries(map || {}).map(([k, v]) => `${k || "Total"} = ${v}`).join("\n");
  }
  function parseExperienceYears(text2) {
    const out = {};
    for (const line of String(text2 || "").split("\n")) {
      const m = line.trim().match(/^(.*?)[=:]\s*(\d+(?:\.\d+)?)/);
      if (!m) continue;
      const key = /^(total|overall|experience)$/i.test(m[1].trim()) ? "" : m[1].trim();
      out[key] = Number(m[2]);
    }
    return out;
  }
  function renderProfileForm(box, p) {
    const id = p.identity;
    const skillLines = p.skills.map((s) => s.label || s.q).join("\n");
    box.innerHTML = section(
      "You",
      `<div class="grid2">${text("identity.firstName", "First name", id.firstName)}${text("identity.lastName", "Last name", id.lastName)}</div>
       <div class="grid2">${text("identity.middleName", "Middle name", id.middleName)}${text("identity.preferredName", "Preferred name", id.preferredName)}</div>
       <div class="grid2">${text("identity.email", "Email", id.email, "email")}${text("identity.altEmail", "Alt email", id.altEmail, "email")}</div>
       <div class="grid2">${text("identity.phone", "Phone", id.phone, "tel")}${text("identity.extension", "Ext.", id.extension)}</div>`,
      true
    ) + section(
      "Address",
      `<div class="grid2">${text("identity.address1", "Address line 1", id.address1)}${text("identity.address2", "Address line 2", id.address2)}</div>
       <div class="grid2">${text("identity.city", "City", id.city)}${text("identity.state", "State", id.state)}</div>
       <div class="grid2">${text("identity.postal", "Postal code", id.postal)}${text("identity.county", "County", id.county)}</div>
       ${text("identity.country", "Country", id.country)}`,
      true
    ) + section(
      "Work eligibility &amp; preferences",
      `<div class="grid2">${yesno("identity.workAuthorized", "Authorized to work (US)", id.workAuthorized)}${yesno("identity.needsSponsorship", "Needs visa sponsorship", id.needsSponsorship)}</div>
       ${text("identity.willingToRelocate", "Relocation preference", id.willingToRelocate)}
       <div class="grid2">${text("identity.hearAboutUs", "How you heard (default)", id.hearAboutUs)}${text("identity.phoneType", "Phone type", id.phoneType)}</div>`,
      true
    ) + section(
      "Links",
      `${text("links.linkedin", "LinkedIn", p.links.linkedin, "url")}
       ${text("links.portfolio", "Portfolio", p.links.portfolio, "url")}
       ${text("links.github", "GitHub", p.links.github, "url")}`,
      true
    ) + section(
      "Compensation",
      `<div class="grid2">${text("compensation.directHireMin", "Base / target salary (number)", p.compensation.directHireMin ?? "", "number", "120000")}${text("compensation.directHireMax", "Max salary (number)", p.compensation.directHireMax ?? "", "number", "150000")}</div>
       ${text("compensation.currency", "Currency", p.compensation.currency)}
       ${area("compensation.note", "Salary as text (range OK)", p.compensation.note, "For free-text salary boxes \u2014 numbers plus characters are fine, e.g. \u201C$120k\u2013$150k\u201D, \u201C120,000+\u201D, or \u201COpen / negotiable\u201D. Leave blank to fall back to your base number.")}`
    ) + section(
      `Work history <span class="hint">(${p.work.length})</span>`,
      `<div id="work-cards">${p.work.map((w) => workCardHTML(w)).join("")}</div>
       <button type="button" class="btn addbtn" data-add="work">+ Add role</button>`
    ) + section(
      `Education <span class="hint">(${p.education.length})</span>`,
      `<div id="edu-cards">${p.education.map((e) => eduCardHTML(e)).join("")}</div>
       <button type="button" class="btn addbtn" data-add="edu">+ Add education</button>`
    ) + section(
      `Skills <span class="hint">(${p.skills.length})</span>`,
      area(
        "skills",
        "One skill per line",
        skillLines,
        "These fill skill pickers and 'select all you're proficient in' checkboxes."
      )
    ) + section(
      "Years of experience",
      area(
        "answers.experienceYears",
        "One per line: subject = years",
        experienceLines(p.answers.experienceYears),
        "Optional. Overrides the auto-count for \u201Chow many years of X\u201D screeners. Use \u201CTotal = 12\u201D for overall experience. Works for any field \u2014 e.g. \u201Ccustomer service = 9\u201D, \u201Cwelding = 6\u201D, \u201CReact = 5\u201D."
      )
    ) + section(
      "Application answers",
      `${area("answers.summary", "Professional summary", p.answers.summary, "Your elevator pitch \u2014 used for \u201Ctell us about yourself\u201D.")}
       ${area("answers.experienceBlock", "Experience block", p.answers.experienceBlock, "A denser background paragraph for \u201Cdescribe your experience\u201D fields.")}
       ${area("answers.strength", "Biggest strength", p.answers.strength, "For \u201Cwhat\u2019s your greatest strength\u201D questions.")}
       ${area("answers.whyCompany", "Why this company", p.answers.whyCompany, "For \u201Cwhy do you want to work here\u201D. Tip: text in [BRACKETS] is a fill-in placeholder \u2014 the AI swaps it per company from the posting. Write a fixed answer if you\u2019d rather not rely on the AI.")}
       ${area("answers.whyLeaving", "Why looking / leaving", p.answers.whyLeaving, "For \u201Cwhy are you looking to move\u201D questions.")}
       ${area("answers.salaryText", "Salary text answer", p.answers.salaryText, "Free-text salary reply, e.g. \u201COpen and flexible \u2014 happy to discuss\u201D.")}
       ${area("answers.highlights", "Career highlights / brag sheet (feeds the AI for essays)", p.answers.highlights, "Proudest builds, how you work, AI tooling \u2014 concrete and metric-backed.")}`
    );
  }
  var trim = (v) => String(v ?? "").trim();
  function readProfileForm(box, base) {
    const g = (path) => trim(box.querySelector(`[data-f="${path}"]`)?.value);
    const work = [...box.querySelectorAll(".work-card")].map((c) => {
      const cg = (k) => trim(c.querySelector(`[data-w="${k}"]`)?.value);
      return {
        company: cg("company"),
        title: cg("title"),
        location: cg("location"),
        start: cg("start"),
        end: cg("end"),
        current: c.querySelector('[data-w="current"]')?.checked ?? false,
        description: cg("description")
      };
    }).filter((w) => w.company || w.title);
    const education = [...box.querySelectorAll(".edu-card")].map((c) => {
      const cg = (k) => trim(c.querySelector(`[data-e="${k}"]`)?.value);
      return {
        school: cg("school"),
        degree: cg("degree"),
        fieldOfStudy: cg("fieldOfStudy"),
        gpa: cg("gpa")
      };
    }).filter((e) => e.school || e.degree);
    const skills = g("skills").split("\n").map((s) => s.trim()).filter(Boolean).map((s) => ({ q: s, label: s }));
    const numOrNull = (v) => v ? Number(v) || null : null;
    const baseMin = numOrNull(g("compensation.directHireMin"));
    return normalize({
      identity: {
        firstName: g("identity.firstName"),
        middleName: g("identity.middleName"),
        lastName: g("identity.lastName"),
        preferredName: g("identity.preferredName"),
        email: g("identity.email"),
        altEmail: g("identity.altEmail"),
        phone: g("identity.phone"),
        extension: g("identity.extension"),
        address1: g("identity.address1"),
        address2: g("identity.address2"),
        city: g("identity.city"),
        state: g("identity.state"),
        postal: g("identity.postal"),
        county: g("identity.county"),
        country: g("identity.country"),
        workAuthorized: g("identity.workAuthorized"),
        needsSponsorship: g("identity.needsSponsorship"),
        willingToRelocate: g("identity.willingToRelocate"),
        hearAboutUs: g("identity.hearAboutUs"),
        phoneType: g("identity.phoneType"),
        // Preserve fields the form doesn't surface.
        countryPhoneCode: base.identity.countryPhoneCode
      },
      links: {
        linkedin: g("links.linkedin"),
        portfolio: g("links.portfolio"),
        github: g("links.github")
      },
      work,
      education,
      skills,
      certifications: base.certifications,
      compensation: {
        ...base.compensation,
        directHireMin: baseMin,
        directHireMax: numOrNull(g("compensation.directHireMax")),
        // Keep the legacy single value in sync with the base so older fill rules
        // that still read desiredSalary keep working.
        desiredSalary: baseMin,
        currency: g("compensation.currency") || base.compensation.currency,
        note: g("compensation.note")
      },
      answers: {
        summary: g("answers.summary"),
        whyCompany: g("answers.whyCompany"),
        strength: g("answers.strength"),
        whyLeaving: g("answers.whyLeaving"),
        salaryText: g("answers.salaryText"),
        experienceBlock: g("answers.experienceBlock"),
        highlights: g("answers.highlights"),
        experienceYears: parseExperienceYears(g("answers.experienceYears"))
      }
    });
  }

  // src/shared/docx.ts
  function u16(b, o) {
    return b[o] | b[o + 1] << 8;
  }
  function u32(b, o) {
    return (b[o] | b[o + 1] << 8 | b[o + 2] << 16 | b[o + 3] << 24) >>> 0;
  }
  async function inflateRaw(data) {
    const copy = new Uint8Array(data.length);
    copy.set(data);
    const stream = new Blob([copy.buffer]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  var unescapeXml = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  function tokenKey(name) {
    return name.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function xmlBodyToText(xml) {
    return unescapeXml(
      xml.replace(/<\/w:p>/g, "\n").replace(/<w:br\s*\/?>/g, "\n").replace(/<w:tab\s*\/?>/g, "	").replace(/<[^>]+>/g, "")
    );
  }
  function readRaw(b) {
    let eocd = -1;
    for (let i = b.length - 22; i >= 0 && i > b.length - 22 - 65536; i--) {
      if (u32(b, i) === 101010256) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw new Error("not a zip");
    const count = u16(b, eocd + 10);
    let cd = u32(b, eocd + 16);
    const out = [];
    for (let e = 0; e < count; e++) {
      if (u32(b, cd) !== 33639248) break;
      const method = u16(b, cd + 10);
      const crc = u32(b, cd + 16);
      const compSize = u32(b, cd + 20);
      const uncompSize = u32(b, cd + 24);
      const nameLen = u16(b, cd + 28);
      const extraLen = u16(b, cd + 30);
      const commentLen = u16(b, cd + 32);
      const localOff = u32(b, cd + 42);
      const name = new TextDecoder().decode(b.subarray(cd + 46, cd + 46 + nameLen));
      const lNameLen = u16(b, localOff + 26);
      const lExtraLen = u16(b, localOff + 28);
      const dataStart = localOff + 30 + lNameLen + lExtraLen;
      out.push({ name, method, comp: b.subarray(dataStart, dataStart + compSize).slice(), crc, uncompSize });
      cd += 46 + nameLen + extraLen + commentLen;
    }
    return out;
  }
  async function entryBytes(e) {
    return e.method === 0 ? e.comp : inflateRaw(e.comp);
  }
  var CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  async function extractDocxText(bytes) {
    try {
      const entries = readRaw(new Uint8Array(bytes));
      const doc = entries.find((e) => e.name === "word/document.xml");
      return doc ? xmlBodyToText(new TextDecoder().decode(await entryBytes(doc))) : "";
    } catch {
      return "";
    }
  }
  var SYNONYMS = {
    company: "company",
    companyname: "company",
    organization: "company",
    organisation: "company",
    org: "company",
    employer: "company",
    role: "role",
    roletitle: "role",
    position: "role",
    jobtitle: "role",
    title: "role",
    job: "role",
    date: "date",
    today: "date",
    todaysdate: "date"
  };
  function templatePlaceholders(text2) {
    const seen = /* @__PURE__ */ new Map();
    for (const m of text2.matchAll(/\[([^\]\n]{1,60})\]/g)) {
      const key = tokenKey(m[1]);
      if (key in SYNONYMS && !seen.has(key)) seen.set(key, m[0]);
    }
    return [...seen.values()];
  }

  // src/options/options.ts
  var $ = (id) => document.getElementById(id);
  var THEME_KEY = "af-theme";
  var darkMedia = window.matchMedia("(prefers-color-scheme: dark)");
  var effectiveTheme = () => {
    const attr = document.documentElement.getAttribute("data-theme");
    if (attr === "light" || attr === "dark") return attr;
    return darkMedia.matches ? "dark" : "light";
  };
  var updateThemeIcon = () => {
    const btn = document.getElementById("themeToggle");
    if (btn) btn.textContent = effectiveTheme() === "dark" ? "\u2600\uFE0F" : "\u{1F319}";
  };
  var setTheme = (t) => {
    document.documentElement.setAttribute("data-theme", t);
    try {
      localStorage.setItem(THEME_KEY, t);
    } catch {
    }
    void chrome.storage.local.set({ [THEME_KEY]: t });
    updateThemeIcon();
  };
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === "light" || saved === "dark") {
      document.documentElement.setAttribute("data-theme", saved);
      void chrome.storage.local.set({ [THEME_KEY]: saved });
    }
  } catch {
  }
  updateThemeIcon();
  $("themeToggle").addEventListener("click", () => {
    setTheme(effectiveTheme() === "dark" ? "light" : "dark");
  });
  darkMedia.addEventListener("change", updateThemeIcon);
  var ta = $("profile");
  var formBox = $("profileForm");
  var statusEl = $("status");
  var flash = (msg, color = "#16a34a") => {
    statusEl.style.color = color;
    statusEl.textContent = msg;
    setTimeout(() => statusEl.textContent = "", 1800);
  };
  var seedProfile = () => window.PROFILE_SEED ?? DEFAULT_PROFILE;
  var current = normalize(seedProfile());
  var PLACEHOLDER_RE = /\[[A-Za-z][A-Za-z0-9 _/-]*\]/;
  function flagPlaceholders() {
    formBox.querySelectorAll("[data-f]").forEach((el) => {
      el.parentElement?.querySelector(".ph-warn")?.remove();
      if (PLACEHOLDER_RE.test(el.value)) {
        const note = document.createElement("div");
        note.className = "fhint ph-warn";
        note.style.color = "#b45309";
        note.textContent = "\u26A0 Has [placeholders] \u2014 the AI fills these per company from the posting, or replace them with real text.";
        el.after(note);
      }
    });
  }
  function setProfile(p) {
    current = p;
    renderProfileForm(formBox, p);
    ta.value = JSON.stringify(p, null, 2);
    flagPlaceholders();
  }
  formBox.addEventListener("input", flagPlaceholders);
  async function load() {
    const { profile } = await chrome.storage.local.get("profile");
    setProfile(normalize(profile || seedProfile()));
  }
  formBox.addEventListener("click", (ev) => {
    const t = ev.target;
    const add = t.closest("[data-add]");
    if (add) {
      ev.preventDefault();
      const kind = add.getAttribute("data-add");
      const list = formBox.querySelector(kind === "work" ? "#work-cards" : "#edu-cards");
      list?.insertAdjacentHTML("beforeend", kind === "work" ? workCardHTML() : eduCardHTML());
      return;
    }
    const rm = t.closest("[data-remove]");
    if (rm) {
      ev.preventDefault();
      rm.closest(".card")?.remove();
    }
  });
  $("save").addEventListener("click", async () => {
    const p = readProfileForm(formBox, current);
    await chrome.storage.local.set({ profile: p });
    setProfile(p);
    flash("Saved");
  });
  $("reset").addEventListener("click", async () => {
    const base = normalize(seedProfile());
    await chrome.storage.local.set({ profile: base });
    setProfile(base);
    flash("Reset to seed");
  });
  $("applyJson").addEventListener("click", () => {
    const jsonStatus = $("jsonStatus");
    try {
      setProfile(normalize(JSON.parse(ta.value)));
      jsonStatus.style.color = "#16a34a";
      jsonStatus.textContent = "Applied to form \u2014 review and Save";
    } catch (e) {
      jsonStatus.style.color = "#dc2626";
      jsonStatus.textContent = "Invalid JSON: " + (e instanceof Error ? e.message : String(e));
    }
  });
  void load();
  var fileToDataUrl = (file) => new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error ?? new Error("read failed"));
    r.readAsDataURL(file);
  });
  function wireDoc(inputId, btnId, key, nameElId, label, emptyMsg = `No ${label} saved yet.`, onChange) {
    const input = $(inputId);
    const btn = $(btnId);
    const nameEl = $(nameElId);
    const removeBtn = document.querySelector(`.doc-remove[data-key="${key}"]`);
    const render = (name) => {
      if (name) {
        nameEl.textContent = `Saved: ${name}`;
        nameEl.classList.add("has");
        btn.textContent = "Replace";
        removeBtn.hidden = false;
      } else {
        nameEl.textContent = emptyMsg;
        nameEl.classList.remove("has");
        btn.textContent = "Choose file";
        removeBtn.hidden = true;
      }
    };
    void chrome.storage.local.get(key).then((o) => render(o[key]?.name));
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      if (file.size > 4e6) {
        nameEl.textContent = "Too big \u2014 keep it under ~4 MB.";
        return;
      }
      const dataUrl = await fileToDataUrl(file);
      await chrome.storage.local.set({ [key]: { name: file.name, dataUrl } });
      input.value = "";
      render(file.name);
      onChange?.();
    });
    removeBtn.addEventListener("click", async () => {
      await chrome.storage.local.remove(key);
      render();
      onChange?.();
    });
  }
  wireDoc("resumeUpload", "resumeBtn", "resumeFile", "resumeFileName", "resume");
  wireDoc(
    "coverUpload",
    "coverBtn",
    "coverLetterFile",
    "coverFileName",
    "cover letter",
    "No cover letter saved \u2014 this is optional.",
    // Re-check placeholders whenever the cover letter is added, replaced, OR removed,
    // so the "heads up" clears when it should.
    () => void checkCoverPlaceholders()
  );
  async function checkCoverPlaceholders() {
    const warnEl = $("coverWarn");
    const setWarn = (msg) => {
      warnEl.textContent = msg;
      warnEl.hidden = !msg;
    };
    const stored = (await chrome.storage.local.get("coverLetterFile")).coverLetterFile;
    if (!stored?.dataUrl) {
      setWarn("");
      await chrome.storage.local.remove("coverLetterPlaceholders");
      return;
    }
    const name = stored.name || "";
    const bytes = await (await fetch(stored.dataUrl)).arrayBuffer();
    if (!/\.docx$/i.test(name)) {
      setWarn(
        "Reminder: I can't read inside a PDF, so double-check this has no leftover placeholders (like [Company]) before you submit."
      );
      await chrome.storage.local.remove("coverLetterPlaceholders");
      return;
    }
    const placeholders = templatePlaceholders(await extractDocxText(bytes));
    if (placeholders.length) {
      setWarn(`Heads up: this still has ${placeholders.join(", ")} in it. Update it before you submit.`);
      await chrome.storage.local.set({ coverLetterPlaceholders: placeholders });
    } else {
      setWarn("");
      await chrome.storage.local.remove("coverLetterPlaceholders");
    }
  }
  void checkCoverPlaceholders();
  function wireReplacements() {
    const list = $("replacementsList");
    const addBtn = $("addReplacement");
    const statusEl2 = $("replacementsStatus");
    let flashTimer;
    const flash2 = () => {
      statusEl2.textContent = "Saved";
      if (flashTimer) clearTimeout(flashTimer);
      flashTimer = setTimeout(() => statusEl2.textContent = "", 1200);
    };
    const collect = () => [...list.querySelectorAll(".repl-row")].map((row) => ({
      token: row.querySelector(".repl-token").value.trim(),
      value: row.querySelector(".repl-value").value
    })).filter((r) => r.token);
    let saveTimer;
    const persist = () => {
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer = setTimeout(
        () => void chrome.storage.local.set({ coverLetterReplacements: collect() }).then(flash2),
        400
      );
    };
    const addRow = (r, focus = false) => {
      const row = document.createElement("div");
      row.className = "repl-row";
      row.style.cssText = "display:flex;gap:6px;align-items:center;margin-bottom:6px";
      const token = document.createElement("input");
      token.className = "repl-token";
      token.placeholder = "Token, e.g. Portfolio";
      token.value = r?.token ?? "";
      token.style.cssText = "flex:0 0 38%";
      token.setAttribute("aria-label", "Replacement token name");
      const val = document.createElement("input");
      val.className = "repl-value";
      val.placeholder = "Value to insert";
      val.value = r?.value ?? "";
      val.style.cssText = "flex:1";
      val.setAttribute("aria-label", "Replacement value");
      const tag = document.createElement("span");
      tag.className = "hint";
      tag.textContent = "per application";
      tag.title = "Blank value: a box for this token appears in the fill dialog, where you type it per application.";
      tag.style.cssText = "flex:0 0 auto;white-space:nowrap;font-size:11px;opacity:.75";
      const syncTag = () => {
        tag.style.display = token.value.trim() && !val.value.trim() ? "" : "none";
      };
      const rm = document.createElement("button");
      rm.type = "button";
      rm.className = "btn-secondary";
      rm.textContent = "Remove";
      rm.addEventListener("click", () => {
        row.remove();
        persist();
      });
      token.addEventListener("input", () => {
        persist();
        syncTag();
      });
      val.addEventListener("input", () => {
        persist();
        syncTag();
      });
      row.append(token, val, tag, rm);
      syncTag();
      list.appendChild(row);
      if (focus) token.focus();
    };
    void chrome.storage.local.get("coverLetterReplacements").then((o) => {
      (o.coverLetterReplacements || []).forEach((r) => addRow(r));
    });
    addBtn.addEventListener("click", () => addRow(void 0, true));
  }
  wireReplacements();
  var resumeStatus = $("resumeStatus");
  var undoParseBtn = $("undoParse");
  var parseBackup = null;
  void chrome.storage.local.get("profileBackup").then((o) => {
    const b = o.profileBackup?.profile;
    if (b) {
      parseBackup = normalize(b);
      undoParseBtn.hidden = false;
    }
  });
  undoParseBtn.addEventListener("click", () => {
    if (!parseBackup) return;
    setProfile(parseBackup);
    resumeStatus.style.color = "#16a34a";
    resumeStatus.textContent = "Restored your previous fields. Review and Save.";
  });
  $("parseResume").addEventListener("click", async () => {
    const btn = $("parseResume");
    const text2 = $("resumeText").value.trim();
    if (!text2) {
      resumeStatus.style.color = "#dc2626";
      resumeStatus.textContent = "Paste your resume text first";
      return;
    }
    parseBackup = readProfileForm(formBox, current);
    await chrome.storage.local.set({
      profileBackup: { profile: parseBackup, at: (/* @__PURE__ */ new Date()).toISOString() }
    });
    undoParseBtn.hidden = false;
    btn.disabled = true;
    const orig = btn.textContent;
    btn.textContent = "Drafting\u2026 (~15s)";
    resumeStatus.style.color = "#6b7280";
    resumeStatus.textContent = "Asking your local Ollama\u2026";
    try {
      const res = await chrome.runtime.sendMessage({ type: "parseResume", text: text2 });
      if (res?.error) throw new Error(res.error);
      const raw = res?.profile ?? {};
      if (Array.isArray(raw.skills)) {
        raw.skills = raw.skills.map((s) => ({ q: String(s), label: String(s) }));
      }
      setProfile(normalize(raw));
      resumeStatus.style.color = "#16a34a";
      resumeStatus.textContent = "Drafted into the form below \u2014 review every field, then Save. Undo restores your previous fields.";
    } catch (e) {
      resumeStatus.style.color = "#dc2626";
      resumeStatus.textContent = "Failed: " + (e instanceof Error ? e.message : String(e));
    } finally {
      btn.disabled = false;
      btn.textContent = orig;
    }
  });
  var SENSITIVE = [
    {
      key: "citizenship",
      label: "U.S. person / citizenship (export control)",
      type: "yesno",
      def: "Yes"
    },
    { key: "willingToTravel", label: "Willing to travel", type: "yesno", def: "Yes" },
    { key: "willingToRelocate", label: "Willing to relocate", type: "yesno", def: "No" },
    {
      key: "restrictiveAgreements",
      label: "Non-compete / NDA / restrictive agreements",
      type: "yesno",
      def: "No"
    },
    { key: "otherWork", label: "Perform other paid/unpaid work if hired", type: "yesno", def: "No" },
    { key: "smsConsent", label: "Consent to calls / text messages (SMS)", type: "yesno", def: "No" },
    { key: "signName", label: "Sign certifications by typing my name", type: "bool" },
    { key: "salaryExpectations", label: "Fill salary expectations text", type: "bool" }
  ];
  var prefsEl = $("prefs");
  var prefStatus = $("prefStatus");
  async function loadPrefs() {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const prefs = answerPrefs || {};
    prefsEl.innerHTML = "";
    for (const s of SENSITIVE) {
      const cur = prefs[s.key] || { enabled: false };
      const row = document.createElement("div");
      row.className = "prefrow";
      let valctl = "";
      if (s.type === "yesno") {
        const v = cur.value || s.def;
        valctl = `<select data-val="${s.key}" aria-label="${s.label} answer">
        <option value="Yes" ${v === "Yes" ? "selected" : ""}>Yes</option>
        <option value="No" ${v === "No" ? "selected" : ""}>No</option>
      </select>`;
      }
      row.innerHTML = `<label><input type="checkbox" data-key="${s.key}" ${cur.enabled ? "checked" : ""}> ${s.label}</label> ${valctl}`;
      prefsEl.appendChild(row);
    }
  }
  $("savePrefs").addEventListener("click", async () => {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const prefs = { ...answerPrefs || {} };
    for (const s of SENSITIVE) {
      const cb = prefsEl.querySelector(`input[data-key="${s.key}"]`);
      const sel = prefsEl.querySelector(`select[data-val="${s.key}"]`);
      prefs[s.key] = { enabled: !!cb?.checked };
      if (sel) prefs[s.key].value = sel.value;
    }
    await chrome.storage.local.set({ answerPrefs: prefs });
    prefStatus.textContent = "Saved";
    setTimeout(() => prefStatus.textContent = "", 1500);
  });
  void loadPrefs();
  var EEO_CATS = [
    { key: "eeoGender", label: "Gender", ph: "e.g. Male / Female / Decline to self-identify" },
    {
      key: "eeoRace",
      label: "Race / ethnicity",
      ph: "e.g. White (Not Hispanic or Latino) / Decline to self-identify"
    },
    { key: "eeoVeteran", label: "Veteran status", ph: "e.g. I am not a protected veteran" },
    { key: "eeoDisability", label: "Disability status", ph: "e.g. No, I don't have a disability" }
  ];
  var eeoBox = $("eeo");
  var eeoStatus = $("eeoStatus");
  var escAttr = (s) => s.replace(/"/g, "&quot;");
  async function loadEeo() {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const prefs = answerPrefs || {};
    eeoBox.innerHTML = "";
    for (const c of EEO_CATS) {
      const cur = prefs[c.key] || { enabled: false };
      const row = document.createElement("div");
      row.className = "prefrow";
      row.innerHTML = `<label><input type="checkbox" data-eeo="${c.key}" ${cur.enabled ? "checked" : ""}> ${c.label}</label>
      <input type="text" data-eeoval="${c.key}" aria-label="${c.label} \u2014 your self-identification value" placeholder="${c.ph}" value="${escAttr(cur.value || "")}">`;
      eeoBox.appendChild(row);
    }
  }
  $("saveEeo").addEventListener("click", async () => {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const prefs = { ...answerPrefs || {} };
    for (const c of EEO_CATS) {
      const cb = eeoBox.querySelector(`[data-eeo="${c.key}"]`);
      const v = eeoBox.querySelector(`[data-eeoval="${c.key}"]`);
      prefs[c.key] = { enabled: !!cb?.checked, value: (v?.value || "").trim() };
    }
    await chrome.storage.local.set({ answerPrefs: prefs });
    eeoStatus.style.color = "#16a34a";
    eeoStatus.textContent = "Saved";
    setTimeout(() => eeoStatus.textContent = "", 1500);
  });
  void loadEeo();
  var workAuthEnabled = $("workAuthEnabled");
  var workAuthValue = $("workAuthValue");
  var workAuthStatus = $("workAuthStatus");
  async function loadWorkAuth() {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const wa = (answerPrefs || {}).workAuth || { enabled: false };
    workAuthEnabled.checked = !!wa.enabled;
    workAuthValue.value = wa.value || "";
  }
  $("saveWorkAuth").addEventListener("click", async () => {
    const { answerPrefs } = await chrome.storage.local.get("answerPrefs");
    const prefs = { ...answerPrefs || {} };
    prefs.workAuth = { enabled: workAuthEnabled.checked, value: workAuthValue.value.trim() };
    await chrome.storage.local.set({ answerPrefs: prefs });
    workAuthStatus.textContent = "Saved";
    setTimeout(() => workAuthStatus.textContent = "", 1500);
  });
  void loadWorkAuth();
  var aiProviderEl = $("aiProvider");
  var aiHostEl = $("aiHost");
  var aiModelEl = $("aiModel");
  var aiHumanizeEl = $("aiHumanize");
  var aiStyleEl = $("aiStyle");
  var aiStatus = $("aiStatus");
  async function loadAi() {
    const { aiConfig } = await chrome.storage.local.get("aiConfig");
    const c = aiConfig || {};
    aiProviderEl.value = c.provider || "none";
    aiHostEl.value = c.host || "http://localhost:11434";
    aiModelEl.value = c.model || "llama3.1";
    aiHumanizeEl.value = c.humanizeLevel || "standard";
    aiStyleEl.value = c.styleNote || "";
  }
  $("saveAi").addEventListener("click", async () => {
    const cfg = {
      provider: aiProviderEl.value,
      host: aiHostEl.value.trim() || "http://localhost:11434",
      model: aiModelEl.value.trim() || "llama3.1",
      humanizeLevel: aiHumanizeEl.value,
      styleNote: aiStyleEl.value.trim()
    };
    await chrome.storage.local.set({ aiConfig: cfg });
    aiStatus.textContent = "Saved";
    setTimeout(() => aiStatus.textContent = "", 1500);
  });
  void loadAi();
  var notionEnabledEl = $("notionEnabled");
  var notionTokenEl = $("notionToken");
  var notionDbEl = $("notionDb");
  var trackStatus = $("trackStatus");
  var appsList = $("appsList");
  var flashTrack = (msg, color = "#16a34a") => {
    trackStatus.style.color = color;
    trackStatus.textContent = msg;
  };
  var readTrackingForm = () => ({
    notionEnabled: notionEnabledEl.checked,
    notionToken: notionTokenEl.value.trim(),
    // Accept a full Notion link or a bare id — pull the database id out either way.
    notionDatabaseId: parseNotionId(notionDbEl.value)
  });
  notionDbEl.addEventListener("blur", () => {
    const id = parseNotionId(notionDbEl.value);
    if (id) notionDbEl.value = id;
  });
  async function loadTracking() {
    const { trackingConfig } = await chrome.storage.local.get("trackingConfig");
    const cfg = { ...DEFAULT_TRACKING, ...trackingConfig };
    notionEnabledEl.checked = cfg.notionEnabled;
    notionTokenEl.value = cfg.notionToken;
    notionDbEl.value = cfg.notionDatabaseId;
  }
  $("saveTracking").addEventListener("click", async () => {
    await chrome.storage.local.set({ trackingConfig: readTrackingForm() });
    flashTrack("Saved");
    setTimeout(() => trackStatus.textContent = "", 1500);
  });
  $("testNotion").addEventListener("click", async (ev) => {
    const btn = ev.currentTarget;
    btn.disabled = true;
    flashTrack("Testing\u2026", "#6b7280");
    try {
      const res = await chrome.runtime.sendMessage({
        type: "track:testNotion",
        config: readTrackingForm()
      });
      if (res?.ok) flashTrack(`Connected to "${res.title}"`);
      else flashTrack(`Failed: ${res?.error ?? "no response"}`, "#dc2626");
    } finally {
      btn.disabled = false;
    }
  });
  var fmtDate = (iso) => {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? iso : d.toLocaleDateString();
  };
  var csvStatus = $("csvStatus");
  $("syncNotion").addEventListener("click", async (ev) => {
    const btn = ev.currentTarget;
    btn.disabled = true;
    csvStatus.style.color = "";
    csvStatus.textContent = "Syncing\u2026";
    try {
      const res = await chrome.runtime.sendMessage({ type: "track:syncAll" });
      if (res?.error && !res.total) {
        csvStatus.style.color = "#b45309";
        csvStatus.textContent = res.error;
      } else if (!res?.total) {
        csvStatus.textContent = "All caught up \u2014 nothing new to sync.";
      } else {
        const failed = res.failed ?? 0;
        csvStatus.style.color = failed ? "#b45309" : "";
        csvStatus.textContent = `Synced ${res.synced ?? 0} of ${res.total}.` + (failed ? ` ${failed} failed: ${res.error}` : "");
        await loadApps();
      }
    } finally {
      btn.disabled = false;
      setTimeout(() => csvStatus.textContent = "", 6e3);
    }
  });
  $("exportCsv").addEventListener("click", async () => {
    const res = await chrome.runtime.sendMessage({ type: "track:list" });
    const apps = res?.applications ?? [];
    if (!apps.length) {
      csvStatus.textContent = "Nothing to export yet.";
      setTimeout(() => csvStatus.textContent = "", 2e3);
      return;
    }
    const blob = new Blob([toCsv(apps)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `applications-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    csvStatus.textContent = `Exported ${apps.length} application${apps.length === 1 ? "" : "s"}.`;
    setTimeout(() => csvStatus.textContent = "", 2500);
  });
  async function loadApps() {
    const res = await chrome.runtime.sendMessage({ type: "track:list" });
    const apps = res?.applications ?? [];
    appsList.innerHTML = "";
    if (!apps.length) {
      appsList.innerHTML = `<p class="hint">Nothing logged yet.</p>`;
      return;
    }
    for (const app of apps) {
      const row = document.createElement("div");
      row.className = "prefrow";
      const opts = STATUSES.map(
        (s) => `<option value="${s}" ${s === app.status ? "selected" : ""}>${s}</option>`
      ).join("");
      row.innerHTML = `
      <label style="flex:2">
        <b>${escapeHtml(app.company || "(no company)")}</b> \u2014 ${escapeHtml(app.role || "(no role)")}
        <span style="color:#6b7280">\xB7 ${fmtDate(app.appliedAt)} \xB7 ${escapeHtml(app.board)}${app.notionPageId ? " \xB7 Notion \u2713" : ""}</span>
      </label>
      <select data-id="${escapeHtml(app.id)}">${opts}</select>`;
      const sel = row.querySelector("select");
      sel.addEventListener("change", async () => {
        const r = await chrome.runtime.sendMessage({
          type: "track:setStatus",
          id: app.id,
          status: sel.value
        });
        if (!r?.ok) flashTrack(`Status update: ${r?.error ?? "failed"}`, "#dc2626");
      });
      appsList.appendChild(row);
    }
  }
  function escapeHtml(s) {
    return s.replace(
      /[&<>"]/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c
    );
  }
  void loadTracking();
  void loadApps();
  var BACKUP_KEYS = [
    "profile",
    "answerPrefs",
    "aiConfig",
    "trackingConfig",
    "applications",
    "resumeFile",
    "coverLetterFile"
  ];
  var backupStatus = $("backupStatus");
  var flashBackup = (msg, color = "#16a34a") => {
    backupStatus.style.color = color;
    backupStatus.textContent = msg;
  };
  $("exportBtn").addEventListener("click", async () => {
    const data = await chrome.storage.local.get(BACKUP_KEYS);
    const payload = { app: "job-autofill", schema: 1, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), data };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `autofill-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    flashBackup("Exported");
    setTimeout(() => backupStatus.textContent = "", 2e3);
  });
  $("importFile").addEventListener("change", async (ev) => {
    const input = ev.target;
    const file = input.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const src = parsed.data ?? parsed;
      const toSet = {};
      for (const k of BACKUP_KEYS) if (k in src) toSet[k] = src[k];
      if (!Object.keys(toSet).length) throw new Error("no recognizable settings in this file");
      await chrome.storage.local.set(toSet);
      await Promise.all([load(), loadPrefs(), loadAi(), loadTracking(), loadApps()]);
      flashBackup(`Imported ${Object.keys(toSet).length} section(s)`);
      setTimeout(() => backupStatus.textContent = "", 2500);
    } catch (e) {
      flashBackup("Import failed: " + (e instanceof Error ? e.message : String(e)), "#dc2626");
    } finally {
      input.value = "";
    }
  });
})();
