"use strict";
(() => {
  // src/shared/profile-schema.ts
  var EMPTY = {
    identity: {
      firstName: "",
      middleName: "",
      lastName: "",
      preferredName: "",
      email: "",
      altEmail: "",
      phone: "",
      extension: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      postal: "",
      county: "",
      country: "United States of America",
      workAuthorized: "",
      needsSponsorship: "",
      willingToRelocate: "",
      phoneType: "",
      hearAboutUs: "",
      countryPhoneCode: ""
    },
    links: { linkedin: "", portfolio: "", github: "" },
    work: [],
    education: [],
    skills: [],
    certifications: [],
    compensation: {
      directHireMin: null,
      directHireMax: null,
      hourlyW2: "",
      hourly1099: "",
      currency: "USD",
      desiredSalary: null,
      note: ""
    },
    answers: {
      summary: "",
      whyCompany: "",
      strength: "",
      whyLeaving: "",
      salaryText: "",
      experienceBlock: "",
      highlights: "",
      experienceYears: {}
    }
  };
  function get(obj, path) {
    return path.split(".").reduce((o, k) => o == null ? void 0 : o[k], obj);
  }
  function normalize(p) {
    const out = structuredClone(EMPTY);
    if (!p || typeof p !== "object") return out;
    const src = p;
    const target = out;
    for (const section of Object.keys(EMPTY)) {
      const base = EMPTY[section];
      const val = src[section];
      if (Array.isArray(base)) {
        target[section] = Array.isArray(val) ? val : [];
      } else {
        target[section] = { ...base, ...val ?? {} };
      }
    }
    return out;
  }

  // src/content/state.ts
  var state = {
    elements: [],
    groups: {},
    profile: EMPTY,
    answerPrefs: {}
  };

  // src/shared/sensitive.ts
  var EEO_TERMS = /(\bgender|\bsex|transgender|lgbtq|\brace\b|racial|ethnic|hispanic|\blatin|national origin|veteran|disabilit|disabled|pronoun|demographic|equal (employment|opportunity)|\beeo\b|self.?identif|voluntar\w* self)/i;
  function isSensitiveText(s) {
    return !!s && EEO_TERMS.test(s);
  }
  function eeoCategory(s) {
    const t = (s || "").toLowerCase();
    if (/disab/.test(t)) return "disability";
    if (/veteran/.test(t)) return "veteran";
    if (/\brace\b|racial|ethnic|hispanic|latino/.test(t)) return "race";
    if (/gender|\bsex\b/.test(t)) return "gender";
    return null;
  }
  var eeoPrefKey = (c) => "eeo" + c.charAt(0).toUpperCase() + c.slice(1);
  function sectionHeading(el) {
    let node = el;
    for (let hops = 0; node && hops < 6; hops++) {
      node = node.parentElement;
      if (!node) break;
      const id = `${node.id} ${node.className}`;
      if (/eeo|demograph|self.?ident|voluntar|diversit/i.test(id)) return id;
      const h = node.querySelector("h1,h2,h3,h4,h5,h6,legend");
      if (h && h.textContent) return h.textContent.trim();
    }
    return "";
  }
  function fieldsetTitle(el) {
    const fs = el.closest("fieldset");
    if (!fs) return "";
    const t = fs.querySelector('legend, label, [class*="label"], [class*="title"]');
    return t?.textContent ? t.textContent.trim() : "";
  }
  function isSensitiveField(el, label, group) {
    if (el.closest('[class*="survey-form"], [class*="eeo"], [class*="demographic"]')) return true;
    const parts = [
      label,
      group,
      el.getAttribute("name") || "",
      el.id || "",
      el.getAttribute("aria-label") || "",
      el.getAttribute("placeholder") || "",
      sectionHeading(el),
      fieldsetTitle(el)
    ];
    return parts.some(isSensitiveText);
  }

  // src/shared/scanner.ts
  function eeoPreset(question) {
    const cat = eeoCategory(question);
    if (!cat) return null;
    const pref = state.answerPrefs[eeoPrefKey(cat)];
    return pref?.enabled && pref.value ? pref.value : null;
  }
  function boardFromHost(host = location.hostname) {
    if (/\.myworkdayjobs\.com$/.test(host)) return "workday";
    if (/(job-boards|boards)\.greenhouse\.io$/.test(host)) return "greenhouse";
    if (/\.ashbyhq\.com$/.test(host)) return "ashby";
    if (/(^|\.)linkedin\.com$/.test(host)) return "linkedin";
    return "generic";
  }
  var text = (el) => el?.textContent ? el.textContent.trim() : "";
  var deResume = (s) => s.replace(/r[eé]sum[eé](s?)/gi, (m, plural) => (/^R/.test(m) ? "Resume" : "resume") + plural);
  function cleanLabel(s) {
    let t = (s || "").replace(/\s+/g, " ").trim();
    t = t.replace(/remove\s*file/gi, " ").replace(/\buploaded successfully\b/gi, " ").replace(/\bdrop (?:or|and) select\b/gi, " ").replace(/\bdrag and drop\b/gi, " ").replace(/\b(?:choose|browse|select|upload) file\b/gi, " ").replace(/\bno file chosen\b/gi, " ").replace(/\bremove\b/gi, " ");
    t = t.replace(/\w[\w()+.-]*\.(?:pdf|docx?|rtf|txt|png|jpe?g|gif|webp)\b/gi, " ");
    t = t.replace(/\(\s*\.?[a-z0-9]{2,5}(?:\s*[/,]\s*\.?[a-z0-9]{2,5})*\s*\)/gi, " ");
    return t.replace(/\s+/g, " ").trim();
  }
  function fileFallbackLabel(el) {
    const hay = [
      el.getAttribute("name"),
      el.getAttribute("id"),
      el.getAttribute("aria-label"),
      testId(el),
      automationId(el)
    ].filter(Boolean).join(" ").toLowerCase();
    if (/cover|motivation/.test(hay)) return "Cover letter";
    if (/resume|résumé|\bcv\b|curriculum/.test(hay)) return "Resume";
    if (/portfolio/.test(hay)) return "Portfolio";
    if (/transcript/.test(hay)) return "Transcript";
    if (/letter|reference|recommendation/.test(hay)) return "Supporting document";
    return "File upload";
  }
  function labelFor(el) {
    const isFile = el.tagName === "INPUT" && (el.getAttribute("type") || "").toLowerCase() === "file";
    const finish = (raw) => isFile ? cleanLabel(raw) : raw;
    if (el.id) {
      const lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (lab && text(lab)) {
        const c = finish(text(lab));
        if (c) return c;
      }
    }
    const labelledby = el.getAttribute("aria-labelledby");
    if (labelledby) {
      const parts = labelledby.split(/\s+/).map((id) => {
        const node = document.getElementById(id);
        if (node?.getAttribute("data-testid") === "screen-reader-only") return "";
        return text(node);
      }).filter(Boolean);
      if (parts.length) {
        const c = finish(parts.join(" "));
        if (c) return c;
      }
    }
    const wrap = el.closest(
      '[data-automation-id^="formField"], [data-testid="field"], .css-7t35fz, fieldset, [class*="field"]'
    );
    if (wrap) {
      const rich = wrap.querySelector('[data-automation-id="richText"]');
      if (rich && text(rich)) {
        const c = finish(text(rich));
        if (c) return c;
      }
      const legend = wrap.querySelector("legend");
      if (legend && text(legend)) {
        const c = finish(text(legend));
        if (c) return c;
      }
      const idLabel = wrap.querySelector('[id$="-label"]:not([data-testid="screen-reader-only"])');
      if (idLabel && text(idLabel)) {
        const c = finish(text(idLabel));
        if (c) return c;
      }
      const lab = wrap.querySelector("label");
      if (lab && text(lab)) {
        const c = finish(text(lab));
        if (c) return c;
      }
    }
    const aria = el.getAttribute("aria-label");
    if (aria && !/^\s*(select one|select|search|textbox)\s*$/i.test(aria)) {
      const c = finish(aria.trim());
      if (c) return c;
    }
    const enclosing = el.closest("label");
    if (enclosing) {
      const c = finish(text(enclosing));
      if (c) return c;
    }
    const prox = finish(questionAbove(el));
    if (prox) return prox;
    return isFile ? fileFallbackLabel(el) : "";
  }
  function groupFor(el) {
    const group = el.closest('[role="group"]');
    if (group) {
      const labId = group.getAttribute("aria-labelledby");
      if (labId) return text(document.getElementById(labId));
      const h = group.querySelector("h1,h2,h3,h4,h5,legend");
      if (h) return text(h);
    }
    return "";
  }
  function automationId(el) {
    const own = el.getAttribute("data-automation-id");
    if (own) return own;
    const wrap = el.closest("[data-automation-id]");
    return wrap ? wrap.getAttribute("data-automation-id") ?? "" : "";
  }
  function testId(el) {
    const ids = [];
    let cur = el;
    for (let i = 0; i < 6 && cur; i++) {
      const t = cur.getAttribute("data-testid");
      if (t) ids.push(t);
      if (t === "field") break;
      cur = cur.parentElement;
    }
    return ids.join(" ");
  }
  function classify(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "textarea") return "textarea";
    if (tag === "select") return "select";
    if (tag === "input") {
      const t = (el.getAttribute("type") || "text").toLowerCase();
      if (t === "file") return "file";
      if (t === "checkbox") return "checkbox";
      if (t === "radio") return "radio";
      if (el.getAttribute("role") === "combobox" || el.getAttribute("data-uxi-widget-type") === "selectinput")
        return "combobox";
      return "text";
    }
    if (tag === "button" && el.getAttribute("aria-haspopup") === "listbox") return "listbox-button";
    if (el.getAttribute("role") === "combobox") return "combobox";
    if (el.getAttribute("aria-haspopup") === "listbox") return "listbox-button";
    return "unknown";
  }
  function isVisibleEnough(el) {
    const input = el;
    if (input.disabled) return false;
    if (input.type === "file") return true;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }
  function selectOptions(el) {
    if (el.tagName.toLowerCase() !== "select") return void 0;
    return [...el.options].map((o) => ({ value: o.value, label: o.text.trim() })).filter((o) => o.label);
  }
  function questionAbove(el) {
    const PROMPT = "p, h1, h2, h3, h4, h5, h6, legend, label, [class*='label' i], [class*='question' i]";
    const CONTROL = "input, select, textarea, [role='radiogroup'], [role='combobox'], [role='listbox'], button";
    let node = el.closest('fieldset, [role="radiogroup"], [role="group"]') || el.closest('[data-testid="field"], [class*="field" i], [class*="question" i], [class*="form-group" i]') || el;
    for (let up = 0; node && up < 5; up++, node = node.parentElement) {
      let sib = node.previousElementSibling;
      for (let back = 0; sib && back < 4; back++, sib = sib.previousElementSibling) {
        if (sib.matches(CONTROL) || sib.querySelector(CONTROL)) continue;
        const q = sib.matches(PROMPT) ? sib : sib.querySelector(PROMPT);
        const t = q ? text(q).replace(/\s+/g, " ").trim() : "";
        if (t.length >= 8 && /\s/.test(t)) return t;
      }
    }
    return "";
  }
  function choiceQuestion(el) {
    const fs = el.closest("fieldset");
    if (fs) {
      const legend = fs.querySelector("legend");
      if (legend && text(legend)) return text(legend);
      const lab = fs.querySelector('label, [class*="label"], [class*="title"]');
      if (lab && text(lab) && !fs.contains(lab.querySelector("input"))) return text(lab);
      if (lab && text(lab)) return text(lab);
    }
    const rg = el.closest('[role="radiogroup"], [role="group"]');
    if (rg) {
      const labId = rg.getAttribute("aria-labelledby");
      if (labId) {
        const t = labId.split(/\s+/).map((id) => text(document.getElementById(id))).filter(Boolean).join(" ");
        if (t) return t;
      }
      const al = rg.getAttribute("aria-label");
      if (al && !/^\s*select\s*$/i.test(al)) return al.trim();
    }
    return questionAbove(el);
  }
  function optionLabel(el) {
    const own = el.closest("label");
    if (own && text(own)) return text(own);
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l && text(l)) return text(l);
    }
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = lb.split(/\s+/).map((id) => text(document.getElementById(id))).filter(Boolean).join(" ").trim();
      if (t) return t;
    }
    return el.getAttribute("aria-label") || el.getAttribute("value") || "";
  }
  var isChoiceInput = (el) => el.tagName === "INPUT" && (el.type === "radio" || el.type === "checkbox");
  function choiceKey(el) {
    const fs = el.closest("fieldset");
    if (fs) return fs;
    const name = el.getAttribute("name");
    return el.type === "radio" && name ? `name:${name}` : el;
  }
  function scan() {
    const board = boardFromHost();
    const nodes = [
      // Native controls, plus custom widgets by ROLE — many ATSs build a select as a
      // <div role="combobox"> / [aria-haspopup="listbox"] with no native input, and it
      // would otherwise be missed entirely (not even flagged).
      ...document.querySelectorAll(
        'input, textarea, select, [role="combobox"], [aria-haspopup="listbox"]'
      )
    ];
    const fields = [];
    const elements = [];
    const groups = {};
    let idx = 0;
    const seen = /* @__PURE__ */ new Set();
    const byKey = /* @__PURE__ */ new Map();
    for (const el of nodes) {
      if (isChoiceInput(el)) {
        const k = choiceKey(el);
        const arr = byKey.get(k);
        if (arr) arr.push(el);
        else byKey.set(k, [el]);
      }
    }
    const shouldSkip = (el) => (
      // Never scan our OWN overlay/data-panel controls (the review inputs, tracking
      // fields, and the AI-draft question/JD boxes) — otherwise a re-scan while the
      // panel is open would try to autofill and model-answer our own UI.
      !!el.closest("#af-overlay, #af-data") || el.getAttribute("role") === "spinbutton" || !!el.closest('[aria-labelledby$="-panel"], [aria-labelledby="primaryQuestionnaire-section"]') || !!el.closest('[data-automation-id="utilityButtonBar"], nav, header')
    );
    for (const el of nodes) {
      if (seen.has(el)) continue;
      const type = classify(el);
      if (type === "unknown") continue;
      if (shouldSkip(el)) continue;
      const nativeTag = /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName);
      if (!nativeTag && el.querySelector("input, select, textarea, [role='combobox']")) continue;
      if (isChoiceInput(el) && el.type === "checkbox") {
        const yesno = el.closest('[class*="yesno"], [class*="yesNo"]');
        const btns = yesno ? [...yesno.querySelectorAll("button")].filter(
          (b) => /^(yes|no)$/i.test((b.textContent || "").trim())
        ) : [];
        if (btns.length >= 2) {
          seen.add(el);
          const question = deResume(choiceQuestion(el) || labelFor(el));
          const group2 = groupFor(el);
          if (isSensitiveField(el, question, group2)) continue;
          fields.push({
            idx,
            board,
            type: "radio",
            id: el.id || "",
            name: el.getAttribute("name") || "",
            automationId: automationId(el),
            testId: testId(el),
            label: question,
            ariaLabel: el.getAttribute("aria-label") || "",
            placeholder: "",
            required: el.getAttribute("aria-required") === "true" || el.required === true,
            currentValue: "",
            group: group2,
            options: btns.map((b) => {
              const l = (b.textContent || "").trim();
              return { value: l, label: l };
            })
          });
          elements[idx] = el;
          groups[idx] = btns;
          idx++;
          continue;
        }
      }
      if (isChoiceInput(el)) {
        const members = (byKey.get(choiceKey(el)) ?? [el]).filter((m) => !m.disabled);
        members.forEach((m) => seen.add(m));
        if (!members.length) continue;
        const question = deResume(choiceQuestion(el) || labelFor(el));
        const group2 = groupFor(el);
        let preset;
        if (isSensitiveField(el, question, group2)) {
          const p = eeoPreset(question);
          if (!p) continue;
          preset = p;
        }
        const options = members.map((m) => {
          const l = optionLabel(m);
          return { value: l, label: l };
        });
        const isGroup = members.length >= 2 || !!question && question !== options[0]?.label;
        if (isGroup) {
          fields.push({
            idx,
            board,
            type: el.type === "radio" ? "radio" : "checkbox",
            id: el.id || "",
            name: el.getAttribute("name") || "",
            automationId: automationId(el),
            testId: testId(el),
            label: question,
            ariaLabel: el.getAttribute("aria-label") || "",
            placeholder: "",
            required: el.getAttribute("aria-required") === "true" || el.required === true,
            // Capture the option TEXT that's currently selected (not a bare boolean),
            // so the overlay can show which choice is already picked.
            currentValue: members.filter((m) => m.checked).map((m) => optionLabel(m)).join("\n"),
            group: group2,
            options,
            multi: el.type === "checkbox",
            preset
          });
          elements[idx] = members[0];
          groups[idx] = members;
          idx++;
          continue;
        }
      }
      if (!isVisibleEnough(el)) continue;
      const label = deResume(labelFor(el));
      const group = groupFor(el);
      if (isSensitiveField(el, label, group)) continue;
      seen.add(el);
      const input = el;
      fields.push({
        idx,
        board,
        type,
        id: el.id || "",
        name: el.getAttribute("name") || "",
        automationId: automationId(el),
        testId: testId(el),
        label,
        ariaLabel: el.getAttribute("aria-label") || "",
        placeholder: el.getAttribute("placeholder") || "",
        required: el.getAttribute("aria-required") === "true" || input.required === true,
        currentValue: type === "checkbox" || type === "radio" ? !!input.checked : input.value || "",
        group,
        options: selectOptions(el)
      });
      elements[idx] = el;
      idx++;
    }
    state.elements = elements;
    state.groups = groups;
    return fields;
  }

  // src/shared/deterministic-map.ts
  var g = (p, path) => get(p, path);
  var RULES = [
    // Name (qualified names before the bare "name").
    { any: ["middle", "name"], value: (p) => g(p, "identity.middleName"), why: "middle name" },
    {
      any: ["preferred", "name"],
      value: (p) => g(p, "identity.preferredName"),
      why: "preferred name"
    },
    {
      any: ["first", "name"],
      not: ["preferred"],
      value: (p) => g(p, "identity.firstName"),
      why: "first name"
    },
    { any: ["legal", "first"], value: (p) => g(p, "identity.firstName"), why: "legal first name" },
    { any: ["last", "name"], value: (p) => g(p, "identity.lastName"), why: "last name" },
    { any: ["family", "name"], value: (p) => g(p, "identity.lastName"), why: "family name" },
    { any: ["surname"], value: (p) => g(p, "identity.lastName"), why: "surname" },
    // Bare "Name" / "Full name": first + last. Kept after the qualified rules so
    // First/Last/Preferred still win; excludes user/company/file/etc. name fields.
    {
      any: ["name"],
      not: ["first", "last", "middle", "preferred", "sur", "family", "user", "company", "account", "file", "display", "nick", "screen", "business", "legal name", "maiden"],
      value: (p) => [g(p, "identity.firstName"), g(p, "identity.lastName")].filter(Boolean).join(" "),
      why: "full name"
    },
    // Contact.
    {
      any: ["email"],
      not: ["confirm", "re-enter", "reenter"],
      value: (p) => g(p, "identity.email"),
      why: "email"
    },
    {
      any: ["phone"],
      not: ["type", "device", "extension", "country"],
      value: (p) => g(p, "identity.phone"),
      why: "phone"
    },
    { any: ["extension"], value: (p) => g(p, "identity.extension"), why: "phone extension" },
    // Address.
    {
      any: ["address"],
      anyOf2: ["line 1", "line1", "addressline1", "street"],
      value: (p) => g(p, "identity.address1"),
      why: "address line 1"
    },
    {
      any: ["address"],
      anyOf2: ["line 2", "line2", "addressline2", "apt", "unit", "suite"],
      value: (p) => g(p, "identity.address2"),
      why: "address line 2"
    },
    { any: ["city"], value: (p) => g(p, "identity.city"), why: "city" },
    { any: ["postal"], value: (p) => g(p, "identity.postal"), why: "postal code" },
    { any: ["zip"], value: (p) => g(p, "identity.postal"), why: "zip code" },
    { any: ["county"], value: (p) => g(p, "identity.county"), why: "county" },
    {
      any: ["state"],
      not: ["statement", "united states"],
      value: (p) => g(p, "identity.state"),
      why: "state"
    },
    { any: ["region"], not: ["country"], value: (p) => g(p, "identity.state"), why: "region/state" },
    // "Location" as one field: City, State. Excludes "relocation" (contains "location").
    {
      any: ["location"],
      not: ["relocat", "prior", "previous"],
      value: (p) => [g(p, "identity.city"), g(p, "identity.state")].filter(Boolean).join(", "),
      why: "location"
    },
    // Current employment — from the most recent work entry. Agnostic.
    { any: ["current", "company"], value: (p) => p.work[0]?.company ?? "", why: "current company" },
    { any: ["current", "employer"], value: (p) => p.work[0]?.company ?? "", why: "current employer" },
    { any: ["employer"], not: ["previous", "former", "prior"], value: (p) => p.work[0]?.company ?? "", why: "employer" },
    { any: ["current", "title"], value: (p) => p.work[0]?.title ?? "", why: "current title" },
    { any: ["current", "position"], value: (p) => p.work[0]?.title ?? "", why: "current position" },
    { any: ["current", "role"], value: (p) => p.work[0]?.title ?? "", why: "current role" },
    { any: ["job", "title"], not: ["desired", "seeking"], value: (p) => p.work[0]?.title ?? "", why: "job title" },
    // Links.
    { any: ["linkedin"], value: (p) => g(p, "links.linkedin"), why: "LinkedIn URL" },
    { any: ["github"], value: (p) => g(p, "links.github"), why: "GitHub URL" },
    { any: ["portfolio"], value: (p) => g(p, "links.portfolio"), why: "portfolio URL" },
    {
      any: ["website"],
      not: ["company"],
      value: (p) => g(p, "links.portfolio"),
      why: "personal website"
    },
    // Salary (numeric fields), proposed for review, not auto-filled. A "maximum"
    // field pulls the top of the range; a plain field pulls the base. Both fall
    // back to the legacy single desiredSalary when the range isn't set.
    {
      any: ["salary"],
      anyOf2: ["max", "maximum", "upper", "up to"],
      not: ["history", "current"],
      value: (p) => numOrEmpty(g(p, "compensation.directHireMax") ?? g(p, "compensation.desiredSalary")),
      why: "max salary",
      review: true
    },
    {
      any: ["salary"],
      not: ["history", "range", "current", "max", "maximum", "upper"],
      value: (p) => numOrEmpty(g(p, "compensation.directHireMin") ?? g(p, "compensation.desiredSalary")),
      why: "base salary",
      review: true
    },
    {
      any: ["compensation"],
      not: ["history", "current"],
      value: (p) => numOrEmpty(g(p, "compensation.directHireMin") ?? g(p, "compensation.desiredSalary")),
      why: "desired compensation",
      review: true
    },
    // Education — from the most recent entry. Agnostic: fills whatever the person
    // has. Degree = level ("Bachelor of Arts"); field/major = subject; school = name.
    { any: ["degree"], value: (p) => p.education[0]?.degree ?? "", why: "degree" },
    { any: ["field", "study"], value: (p) => p.education[0]?.fieldOfStudy ?? "", why: "field of study" },
    { any: ["major"], not: ["minor"], value: (p) => p.education[0]?.fieldOfStudy ?? "", why: "major" },
    { any: ["concentration"], value: (p) => p.education[0]?.fieldOfStudy ?? "", why: "concentration" },
    // "high" excluded so a "High School" field doesn't get the university name.
    { any: ["school"], not: ["high"], value: (p) => p.education[0]?.school ?? "", why: "school" },
    { any: ["university"], value: (p) => p.education[0]?.school ?? "", why: "university" },
    { any: ["college"], value: (p) => p.education[0]?.school ?? "", why: "college" },
    { any: ["institution"], value: (p) => p.education[0]?.school ?? "", why: "institution" },
    { any: ["gpa"], value: (p) => p.education[0]?.gpa ?? "", why: "GPA" },
    // Work authorization (yes/no).
    { any: ["authorized"], value: (p) => g(p, "identity.workAuthorized"), why: "work authorization" },
    {
      any: ["legally", "work"],
      value: (p) => g(p, "identity.workAuthorized"),
      why: "authorized to work"
    },
    { any: ["sponsorship"], value: (p) => g(p, "identity.needsSponsorship"), why: "sponsorship" },
    {
      any: ["require", "visa"],
      value: (p) => g(p, "identity.needsSponsorship"),
      why: "visa sponsorship"
    },
    // Anti-nepotism / "do you have a relative employed here" — safe default is "no
    // relationship". The applier matches this to the option containing the phrase.
    {
      any: ["employ"],
      anyOf2: ["relationship", "family member", "significant other", "nepotism", "relative"],
      value: () => "No relationship",
      why: "no relationship to current employees"
    }
  ];
  var numOrEmpty = (n) => n == null ? "" : String(n);
  function salaryText(p) {
    const c = p.compensation;
    if (p.answers.salaryText.trim()) return p.answers.salaryText.trim();
    if (c.note.trim()) return c.note.trim();
    const money = (n) => "$" + n.toLocaleString("en-US");
    if (c.directHireMin && c.directHireMax) return `${money(c.directHireMin)}\u2013${money(c.directHireMax)}`;
    if (c.directHireMin) return money(c.directHireMin);
    return "";
  }
  function haystack(field) {
    return [
      field.label,
      field.automationId,
      field.testId,
      field.id,
      field.name,
      field.placeholder,
      field.ariaLabel
    ].filter(Boolean).join(" ").toLowerCase();
  }
  var STREET = /\b(loop|st|street|ave|avenue|rd|road|dr|drive|blvd|ln|lane|ct|court|way|pkwy|hwy|apt|suite|ste|unit)\b/i;
  function sanityNote(value, why) {
    const v = value.trim();
    if (/county/.test(why) && (/^\d/.test(v) || STREET.test(v)))
      return "looks like a street address, not a county";
    if (/(postal|zip)/.test(why) && !/^\d{3,10}(-\d{4})?$/.test(v))
      return "doesn't look like a postal code";
    if (/email/.test(why) && !v.includes("@")) return "doesn't look like an email";
    if (/phone/.test(why) && v.replace(/\D/g, "").length < 7)
      return "doesn't look like a phone number";
    return null;
  }
  function match(field, profile) {
    const hay = haystack(field);
    if (!hay.trim()) return null;
    for (const rule of RULES) {
      if (!rule.any.every((tok) => hay.includes(tok))) continue;
      if (rule.not && rule.not.some((tok) => hay.includes(tok))) continue;
      if (rule.anyOf2 && !rule.anyOf2.some((tok) => hay.includes(tok))) continue;
      const value = rule.value(profile);
      if (value == null || value === "") {
        return {
          value: "",
          confidence: 0,
          reason: `${rule.why} (empty in your profile)`,
          source: "deterministic"
        };
      }
      const v = String(value);
      const warn = sanityNote(v, rule.why);
      if (warn)
        return {
          value: v,
          confidence: 0.4,
          reason: `${rule.why} \u2014 ${warn}, check this`,
          source: "deterministic"
        };
      if (rule.review) {
        return {
          value: v,
          confidence: 0.5,
          reason: `${rule.why} (your floor \u2014 accept or type the posted range)`,
          source: "deterministic"
        };
      }
      return { value: v, confidence: 0.95, reason: rule.why, source: "deterministic" };
    }
    return null;
  }

  // src/shared/widget-util.ts
  var setNativeValue = (el, value) => {
    Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set?.call(el, value);
  };
  var fireMouse = (el, types) => {
    for (const t of types) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, button: 0 }));
    }
  };
  var escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  function optionMatches(text2, value) {
    const t = text2.trim();
    const v = value.trim();
    if (!v) return false;
    if (t.toLowerCase() === v.toLowerCase()) return true;
    return new RegExp(`\\b${escapeRe(v)}\\b`, "i").test(t);
  }

  // src/shared/experience.ts
  var ym = (year, month0) => year * 12 + month0;
  var PRESENT = /^(present|current|now|ongoing|to date|till date|until now)$/i;
  var MONTH_ABBR = {
    jan: 0,
    feb: 1,
    mar: 2,
    apr: 3,
    may: 4,
    jun: 5,
    jul: 6,
    aug: 7,
    sep: 8,
    oct: 9,
    nov: 10,
    dec: 11
  };
  function currentMonthIndex(d = /* @__PURE__ */ new Date()) {
    return ym(d.getFullYear(), d.getMonth());
  }
  function parseMonth(raw) {
    const s = (raw || "").trim().toLowerCase();
    if (!s || PRESENT.test(s)) return null;
    let m = s.match(/^(\d{4})[-/.](\d{1,2})\b/);
    if (m) return ym(+m[1], Math.min(11, Math.max(0, +m[2] - 1)));
    m = s.match(/^(\d{4})$/);
    if (m) return ym(+m[1], 0);
    m = s.match(/^([a-z]{3,})\.?\s+(\d{4})$/);
    if (m) {
      const mo = MONTH_ABBR[m[1].slice(0, 3)];
      if (mo != null) return ym(+m[2], mo);
    }
    return null;
  }
  function interval(w, now) {
    const start = parseMonth(w.start);
    if (start == null) return null;
    let end = parseMonth(w.end);
    if (end == null) {
      const ongoing = w.current || PRESENT.test((w.end || "").trim());
      if (!ongoing) return null;
      end = now;
    }
    end = Math.min(end, now);
    if (end < start) return null;
    return [start, end];
  }
  function totalMonths(work, now, filter) {
    const intervals = work.filter((w) => !filter || filter(w)).map((w) => interval(w, now)).filter((x) => x != null).sort((a, b) => a[0] - b[0]);
    let total = 0;
    let curStart = -1;
    let curEnd = -1;
    for (const [s, e] of intervals) {
      if (curEnd < 0) {
        curStart = s;
        curEnd = e;
      } else if (s > curEnd) {
        total += curEnd - curStart;
        curStart = s;
        curEnd = e;
      } else {
        curEnd = Math.max(curEnd, e);
      }
    }
    if (curEnd >= 0) total += curEnd - curStart;
    return total;
  }
  function totalYears(work, now, filter) {
    return Math.max(0, Math.round(totalMonths(work, now, filter) / 12));
  }

  // src/shared/experience-resolver.ts
  var TOTAL_KEYS = /* @__PURE__ */ new Set(["", "total", "overall", "experience", "professional"]);
  var normKey = (k) => {
    const s = (k || "").toLowerCase().trim();
    return TOTAL_KEYS.has(s) ? "" : s;
  };
  var SUBJECT_STOP = /* @__PURE__ */ new Set([
    "professional",
    "work",
    "working",
    "relevant",
    "related",
    "total",
    "overall",
    "paid",
    "direct",
    "hands on",
    "full time",
    "part time"
  ]);
  function cleanSubject(raw) {
    const x = raw.toLowerCase().replace(/\bdo you have\b.*$/, "").replace(/[?.:*]+/g, " ").replace(/\b(a|an|the)\b/g, " ").replace(/\bexperience\b/g, " ").replace(/\s+/g, " ").trim();
    return SUBJECT_STOP.has(x) ? "" : x;
  }
  var SUBJECT = "([a-z0-9 +#./&'-]{2,40})";
  function isYearsQuestion(text2) {
    if (!/\byears?\b|\byrs?\b/.test(text2)) return false;
    return /experience|tenure/.test(text2) || new RegExp(`years?\\s+(?:of|with|in|using)\\b`).test(text2);
  }
  function subjectOf(text2) {
    const m = text2.match(new RegExp(`experience\\s+(?:with|in|using|of)\\s+${SUBJECT}`)) || text2.match(new RegExp(`years?\\s+of\\s+${SUBJECT}?\\s+experience`)) || text2.match(new RegExp(`years?\\s+(?:with|in|using|of)\\s+${SUBJECT}`));
    return m ? cleanSubject(m[1] || "") : "";
  }
  var roleMatches = (subject) => (w) => `${w.title} ${w.description} ${w.company}`.toLowerCase().includes(subject.toLowerCase());
  function detectExperience(f, profile, now = currentMonthIndex()) {
    const text2 = [f.label, f.ariaLabel, f.placeholder, f.name].filter(Boolean).join("  ").toLowerCase();
    if (!isYearsQuestion(text2)) return null;
    const subject = subjectOf(text2);
    const overrides = profile.answers.experienceYears && typeof profile.answers.experienceYears === "object" ? profile.answers.experienceYears : {};
    const oKey = Object.keys(overrides).find((k) => normKey(k) === normKey(subject));
    if (oKey !== void 0 && Number.isFinite(Number(overrides[oKey]))) {
      return { years: Math.max(0, Math.round(Number(overrides[oKey]))), subject, source: "profile", roles: -1 };
    }
    if (!subject) {
      return { years: totalYears(profile.work, now), subject: "", source: "derived", roles: profile.work.length };
    }
    const filter = roleMatches(subject);
    return {
      years: totalYears(profile.work, now, filter),
      subject,
      source: "derived",
      roles: profile.work.filter(filter).length
    };
  }
  function reasonFor(hit) {
    if (hit.source === "profile") return "from your Experience settings \u2014 verify";
    if (!hit.subject) return "\u2248 total from your work history \u2014 verify";
    return `\u2248 ${hit.years} yr from ${hit.roles} role${hit.roles === 1 ? "" : "s"} mentioning \u201C${hit.subject}\u201D \u2014 verify`;
  }
  var isBlank = (hit) => hit.source === "derived" && !!hit.subject && hit.roles === 0;
  function experienceForText(f, profile, now = currentMonthIndex()) {
    const hit = detectExperience(f, profile, now);
    if (!hit) return null;
    if (isBlank(hit)) {
      return {
        value: "",
        confidence: 0.4,
        reason: `couldn't find \u201C${hit.subject}\u201D in your roles \u2014 add it under Experience`,
        source: "experience"
      };
    }
    return {
      value: String(hit.years),
      confidence: hit.source === "profile" ? 0.6 : 0.4,
      reason: reasonFor(hit),
      source: "experience"
    };
  }
  function parseRange(label) {
    const t = label.toLowerCase();
    if (/\bnone\b|^\s*0\s*(years?|yrs?)?\s*$/.test(t)) return { lo: 0, hi: 0 };
    let m = t.match(/(?:less than|under|fewer than|<)\s*(\d+)/);
    if (m) return { lo: 0, hi: Math.max(0, +m[1] - 1) };
    m = t.match(/(\d+)\s*(?:\+|or more|or greater|or above|plus|and (?:above|over|up))/);
    if (m) return { lo: +m[1], hi: Infinity };
    m = t.match(/(?:more than|over)\s*(\d+)/);
    if (m) return { lo: +m[1] + 1, hi: Infinity };
    m = t.match(/(?:at least|minimum(?: of)?|>=)\s*(\d+)/);
    if (m) return { lo: +m[1], hi: Infinity };
    m = t.match(/(\d+)\s*(?:-|–|—|to|\.\.)\s*(\d+)/);
    if (m) return { lo: +m[1], hi: +m[2] };
    m = t.match(/(\d+)/);
    if (m) return { lo: +m[1], hi: +m[1] };
    return null;
  }
  function pickBucket(options, years) {
    for (const o of options) {
      const r = parseRange(o.label);
      if (r && years >= r.lo && years <= r.hi) return o.label;
    }
    return null;
  }
  function experienceForChoice(f, profile, now = currentMonthIndex()) {
    const hit = detectExperience(f, profile, now);
    if (!hit || isBlank(hit) || !f.options?.length) return null;
    const opt = pickBucket(f.options, hit.years);
    if (!opt) return null;
    return { value: opt, confidence: 0.5, reason: reasonFor(hit), source: "experience" };
  }

  // src/shared/grounding.ts
  var FACTUAL = /\b(e-?mail|phone|mobile|tel|name|first|last|linkedin|github|url|website|portfolio|address|street|city|state|zip|postal|country|ssn|dob|birth)\b/i;
  var isFactualLabel = (label) => FACTUAL.test(label || "");
  function profileHaystack(profile) {
    const parts = [];
    const walk = (v) => {
      if (v == null) return;
      if (typeof v === "string" || typeof v === "number") parts.push(String(v));
      else if (Array.isArray(v)) v.forEach(walk);
      else if (typeof v === "object") Object.values(v).forEach(walk);
    };
    walk(profile);
    return parts.join(" ").toLowerCase();
  }
  function groundedInProfile(value, profile) {
    const tokens = value.toLowerCase().match(/[a-z0-9]{2,}/g) || [];
    if (!tokens.length) return true;
    const hay = profileHaystack(profile);
    return tokens.every((t) => hay.includes(t));
  }

  // src/shared/planner.ts
  var FILL_THRESHOLD = 0.85;
  var GENERIC_WRITABLE = /* @__PURE__ */ new Set(["text", "textarea", "select", "checkbox", "radio"]);
  var ADAPTER_WIDGETS = /* @__PURE__ */ new Set(["combobox", "listbox-button", "file"]);
  function adapterReason(type) {
    if (type === "file") return "File upload. Attach it with the buttons below.";
    if (type === "combobox") return "Search or type-ahead menu. Pick the option on the page.";
    if (type === "listbox-button") return "Custom dropdown. Open it and choose on the page.";
    return "Handle this one on the page.";
  }
  var CHOICE_WIDGETS = /* @__PURE__ */ new Set(["radio", "checkbox", "select"]);
  var normSkill = (s) => s.toLowerCase().replace(/[^a-z0-9+#.]/g, " ").replace(/\s+/g, " ").trim();
  function matchSkills(options, skills2) {
    const have = /* @__PURE__ */ new Set();
    for (const s of skills2) {
      const a = normSkill(s.label || "");
      const b = normSkill(s.q || "");
      if (a) have.add(a);
      if (b) have.add(b);
    }
    const out = [];
    for (const o of options) {
      const whole = normSkill(o.label);
      const parts = o.label.split(/\s*[/,]\s*|\bor\b/i).map(normSkill).filter(Boolean);
      if (have.has(whole) || parts.some((p) => have.has(p))) out.push(o.label);
    }
    return out;
  }
  var looksSkills = (f) => /proficient|\bskills?\b|technolog|familiar|languages?|frameworks?/i.test(f.label || "");
  var STUDY_STOP = /* @__PURE__ */ new Set([
    "and",
    "the",
    "for",
    "with",
    "degree",
    "major",
    "minor",
    "studies",
    "study",
    "of",
    "in",
    "bachelor",
    "bachelors",
    "master",
    "masters",
    "associate",
    "associates",
    "science",
    "sciences",
    "arts",
    "the",
    "your"
  ]);
  var sigWords = (s) => s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 4 && !STUDY_STOP.has(w));
  function closestOption(options, value) {
    const wanted = sigWords(value);
    if (!wanted.length) return "";
    let best = "";
    let bestScore = 0;
    for (const o of options) {
      const ow = sigWords(o.label);
      let score = 0;
      for (const w of wanted) if (ow.some((x) => x.includes(w) || w.includes(x))) score++;
      if (score > bestScore) {
        bestScore = score;
        best = o.label;
      }
    }
    return bestScore >= 1 ? best : "";
  }
  function resolveChoice(entry, f, profile, now) {
    if (f.preset != null) {
      Object.assign(entry, {
        tier: 1,
        value: f.preset,
        confidence: 0.9,
        reason: "your voluntary self-identification",
        source: "deterministic"
      });
      return;
    }
    const det = match(f, profile);
    if (det && det.value) {
      if (f.options?.length && !f.options.some((o) => optionMatches(o.label, det.value))) {
        const near = closestOption(f.options, det.value);
        Object.assign(entry, {
          tier: 1,
          value: near,
          confidence: 0.5,
          reason: near ? `closest option to \u201C${det.value}\u201D \u2014 confirm` : `pick the closest to \u201C${det.value}\u201D`,
          source: "deterministic"
        });
        return;
      }
      Object.assign(entry, { tier: 1, ...det });
      return;
    }
    const expChoice = experienceForChoice(f, profile, now);
    if (expChoice) {
      Object.assign(entry, { tier: 1, ...expChoice });
      return;
    }
    if (f.multi && f.options?.length && looksSkills(f)) {
      const picked = matchSkills(f.options, profile.skills);
      if (picked.length) {
        Object.assign(entry, {
          tier: 1,
          value: picked.join("\n"),
          confidence: 0.9,
          reason: `matched ${picked.length} of your profile skills`,
          source: "deterministic"
        });
        return;
      }
    }
    Object.assign(entry, {
      tier: 1,
      value: "",
      confidence: 0.5,
      reason: f.options?.length ? f.multi ? "check any that apply" : "pick an option" : "check if this applies to you",
      source: "deterministic"
    });
  }
  var looksFreeText = (f) => f.type === "textarea" || /why|describe|tell us|cover|summary|explain|reason|about you/i.test(f.label || "");
  function decisionFor(confidence, isAdapter) {
    if (isAdapter) return confidence > 0 ? "review" : "skip";
    if (confidence >= FILL_THRESHOLD) return "fill";
    if (confidence > 0) return "review";
    return "skip";
  }
  var mkEntry = (f) => ({
    idx: f.idx,
    field: f,
    tier: "skip",
    value: "",
    confidence: 0,
    reason: "",
    source: "none",
    decision: "skip"
  });
  var PLACEHOLDER = /\[[A-Za-z][A-Za-z0-9 _/-]*\]/;
  function liteProfile(profile) {
    const answers = Object.fromEntries(
      Object.entries(profile.answers).filter(
        ([, v]) => typeof v === "string" && v && !PLACEHOLDER.test(v)
      )
    );
    return {
      identity: profile.identity,
      links: profile.links,
      compensation: profile.compensation,
      answers,
      // The full work history (trimmed) so the model has real material to draw on.
      work: profile.work.slice(0, 6).map((w) => ({
        company: w.company,
        title: w.title,
        dates: [w.start, w.end].filter(Boolean).join("\u2013"),
        description: (w.description || "").slice(0, 400)
      })),
      skills: profile.skills.map((s) => s.label || s.q)
    };
  }
  function summarize(entries) {
    return {
      total: entries.length,
      fill: entries.filter((e) => e.decision === "fill").length,
      review: entries.filter((e) => e.decision === "review").length,
      skip: entries.filter((e) => e.decision === "skip").length,
      adapter: entries.filter((e) => e.tier === "adapter").length
    };
  }
  function planFields(fields, profile, jobContext = "", now = currentMonthIndex()) {
    const entries = fields.map(mkEntry);
    const lite = liteProfile(profile);
    const pending = [];
    for (const e of entries) {
      const f = e.field;
      if (ADAPTER_WIDGETS.has(f.type)) {
        const isDropdown = f.type === "combobox" || f.type === "listbox-button";
        const answered = typeof f.currentValue === "string" && f.currentValue.trim() !== "";
        const highlight2 = isDropdown && f.required && !answered;
        const det2 = highlight2 ? match(f, profile) : null;
        const rec = det2?.value || "";
        Object.assign(e, {
          tier: "adapter",
          source: "adapter",
          value: rec,
          confidence: highlight2 ? 0.5 : 0,
          reason: rec ? `Recommended: \u201C${rec}\u201D \u2014 open the menu on the page and choose it.` : adapterReason(f.type)
        });
        continue;
      }
      if (CHOICE_WIDGETS.has(f.type)) {
        resolveChoice(e, f, profile, now);
        continue;
      }
      if (!GENERIC_WRITABLE.has(f.type)) {
        Object.assign(e, { reason: "Please set this one on the page. I can't fill this kind of field." });
        continue;
      }
      const det = match(f, profile);
      if (det) {
        Object.assign(e, { tier: 1, ...det });
        continue;
      }
      const expText = experienceForText(f, profile, now);
      if (expText) {
        Object.assign(e, { tier: 1, ...expText });
        continue;
      }
      const hasPrompt = !!(f.label.trim() || f.ariaLabel.trim() || f.placeholder.trim());
      if (!hasPrompt) {
        Object.assign(e, { reason: "no readable label \u2014 fill this one by hand on the page" });
        continue;
      }
      const kind = looksFreeText(f) ? "generate" : "map";
      Object.assign(e, {
        tier: kind === "generate" ? 3 : 2,
        value: "",
        confidence: 0,
        reason: "thinking\u2026",
        source: "ai",
        pending: true
      });
      pending.push({
        entry: e,
        item: {
          kind,
          field: {
            label: f.label,
            type: f.type,
            group: f.group,
            options: f.options,
            required: f.required
          },
          profile: lite,
          jobContext: kind === "generate" ? jobContext : void 0
        }
      });
    }
    for (const e of entries)
      e.decision = e.pending ? "review" : decisionFor(e.confidence, e.tier === "adapter");
    const seenFill = /* @__PURE__ */ new Set();
    for (const e of entries) {
      if (e.decision !== "fill" || !e.value) continue;
      const key = `${e.field.label}\0${e.value}`;
      if (seenFill.has(key)) Object.assign(e, { decision: "skip", reason: "duplicate of another field" });
      else seenFill.add(key);
    }
    return { plan: { entries, summary: summarize(entries) }, pending };
  }
  async function resolvePending(pending, resolve) {
    if (!pending.length) return;
    const results = await resolve(pending.map((p) => p.item));
    pending.forEach(({ entry, item }, i) => {
      let r = results[i] ?? { value: "", confidence: 0, reason: "no result", source: "none" };
      if (item.kind === "map" && r.value && isFactualLabel(item.field.label) && !groundedInProfile(r.value, item.profile)) {
        r = { value: "", confidence: 0, reason: "couldn't verify that against your profile", source: r.source };
      }
      const confidence = r.value ? Math.min(r.confidence || 0, 0.8) : 0;
      delete entry.pending;
      Object.assign(entry, { ...r, confidence });
      const d = decisionFor(confidence, false);
      entry.decision = d === "skip" ? "review" : d;
    });
  }

  // src/shared/react-commit.ts
  function nativeSet(el, value) {
    const proto = el.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
  }
  var commitWorkday = (el, value) => {
    el.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
    nativeSet(el, value);
    el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, data: value }));
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Tab" }));
    el.dispatchEvent(new FocusEvent("blur", { bubbles: true }));
    el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    return el.value === value;
  };
  var commitGreenhouse = (el, value) => {
    nativeSet(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    return el.value === value;
  };
  var commitAshby = (el, value) => {
    const old = el.value;
    nativeSet(el, value);
    const tracker = el._valueTracker;
    if (tracker) tracker.setValue(old);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return el.value === value;
  };
  function typeSearch(el, value) {
    nativeSet(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  var log = { filled: [], skipped: [] };
  function report(name, ok, note) {
    (ok ? log.filled : log.skipped).push(note ? `${name} (${note})` : name);
  }
  function flush(label) {
    console.log(
      `%c[${label}] filled: ${log.filled.join(", ") || "none"}`,
      "color:#16a34a;font-weight:bold"
    );
    console.log(
      `%c[${label}] skipped: ${log.skipped.join(", ") || "none"}`,
      "color:#b45309;font-weight:bold"
    );
    log.filled = [];
    log.skipped = [];
  }

  // src/content/kill-switch.ts
  var cleanup = null;
  function claimRun(tag) {
    if (window.__afRunning) {
      console.debug("[autofill] already running, ignoring repeat trigger.");
      return false;
    }
    window.__afRunning = tag || true;
    const onKey = (e) => {
      if (e.isTrusted && e.key === "Escape") {
        window.__afAbort = true;
        console.warn("Autofill aborted by Escape.");
      }
    };
    document.addEventListener("keydown", onKey, true);
    cleanup = () => {
      window.__afRunning = false;
      window.__afAbort = false;
      document.removeEventListener("keydown", onKey, true);
    };
    return true;
  }
  function endRun() {
    cleanup?.();
    cleanup = null;
  }
  var isAborted = () => !!window.__afAbort;

  // src/shared/drafts.ts
  var KEY = "drafts";
  var CAP = 15;
  var JOB_KEY = "draftJob";
  var JOB_STALE_MS = 4 * 60 * 1e3;
  async function getDraftJob() {
    const o = await chrome.storage.local.get(JOB_KEY);
    const j = o[JOB_KEY];
    if (!j) return null;
    return Date.now() - j.startedAt > JOB_STALE_MS ? null : j;
  }
  var queue = Promise.resolve();
  function serialize(fn) {
    const run2 = queue.then(fn, fn);
    queue = run2.catch(() => void 0);
    return run2;
  }
  function newId() {
    return "d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }
  var escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  async function loadDrafts() {
    const o = await chrome.storage.local.get(KEY);
    const list = o[KEY];
    return Array.isArray(list) ? list : [];
  }
  function saveDraft(title, text2) {
    return serialize(async () => {
      const list = await loadDrafts();
      const t = title.trim() || "Draft";
      const at = Date.now();
      const existing = list.find((d) => d.title === t);
      let rec;
      if (existing) {
        existing.text = text2;
        existing.at = at;
        rec = existing;
      } else {
        rec = { id: newId(), title: t, text: text2, at };
        list.push(rec);
      }
      const trimmed = list.sort((a, b) => b.at - a.at).slice(0, CAP);
      await chrome.storage.local.set({ [KEY]: trimmed });
      return rec;
    });
  }
  function saveVariant(baseTitle, text2) {
    return serialize(async () => {
      const list = await loadDrafts();
      const base = baseTitle.trim() || "Draft";
      const re = new RegExp(`^${escapeRegExp(base)} (\\d+)$`);
      let max = 0;
      for (const d of list) {
        const m = re.exec(d.title);
        if (m) max = Math.max(max, parseInt(m[1], 10));
      }
      const rec = { id: newId(), title: `${base} ${max + 1}`, text: text2, at: Date.now() };
      list.push(rec);
      const trimmed = list.sort((a, b) => b.at - a.at).slice(0, CAP);
      await chrome.storage.local.set({ [KEY]: trimmed });
      return rec;
    });
  }
  function updateDraft(id, text2) {
    return serialize(async () => {
      const list = await loadDrafts();
      const d = list.find((x) => x.id === id);
      if (!d) return;
      d.text = text2;
      d.at = Date.now();
      await chrome.storage.local.set({ [KEY]: list });
    });
  }
  function renameDraft(id, title) {
    return serialize(async () => {
      const t = title.trim();
      if (!t) return;
      const list = await loadDrafts();
      const d = list.find((x) => x.id === id);
      if (!d) return;
      d.title = t;
      await chrome.storage.local.set({ [KEY]: list });
    });
  }
  function removeDraft(id) {
    return serialize(async () => {
      const list = (await loadDrafts()).filter((x) => x.id !== id);
      await chrome.storage.local.set({ [KEY]: list });
    });
  }

  // src/shared/overlay-ui.ts
  var SCOPE = ":is(#af-overlay, #af-data, #af-editor, #af-cfill)";
  var COMPONENT_CSS = `
/* Buttons \u2014 one base, three intents, all with hover / active / disabled / focus.
   Matches the overlay's established language: a filled button inverts to outlined
   on hover; an outlined button fills in. */
${SCOPE} .afc-btn {
  cursor: pointer; border: 1px solid transparent; border-radius: 8px; padding: 8px 12px;
  font: inherit; font-weight: 600; font-size: 13px; line-height: 1.45;
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  transition: background .12s, color .12s, border-color .12s, transform .06s; }
${SCOPE} .afc-btn--sm { padding: 6px 11px; font-size: 12px; }
${SCOPE} .afc-btn--block { width: 100%; }
${SCOPE} .afc-btn--primary { background: var(--brand); color: #fff; }
${SCOPE} .afc-btn--primary:hover:not(:disabled) {
  background: var(--card, var(--bg)); color: var(--brand); border-color: var(--brand); transform: translateY(-1px); }
${SCOPE} .afc-btn--secondary { background: var(--surface); color: var(--text); border-color: var(--border); }
${SCOPE} .afc-btn--secondary:hover:not(:disabled) {
  background: var(--brand); color: #fff; border-color: var(--brand); transform: translateY(-1px); }
${SCOPE} .afc-btn--ghost { background: transparent; color: var(--muted); }
${SCOPE} .afc-btn--ghost:hover:not(:disabled) { color: var(--brand); background: var(--surface); }
${SCOPE} .afc-btn:active:not(:disabled) { transform: translateY(1px); }
${SCOPE} .afc-btn:disabled { opacity: .5; cursor: not-allowed; filter: grayscale(.25); transform: none; box-shadow: none; }
${SCOPE} .afc-btn:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }

/* Cards + section headers */
${SCOPE} .afc-card { border: 1px solid var(--border); border-radius: 10px; padding: 12px; background: var(--surface); }
${SCOPE} .afc-card--accent {
  background: var(--card, var(--bg)); border: 1px solid var(--brand); border-left: 4px solid var(--brand); }
${SCOPE} .afc-title {
  font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
  color: var(--brand); margin: 0 0 6px; display: flex; align-items: center; gap: 6px; }
${SCOPE} .afc-count { font-weight: 700; color: var(--brand); }
${SCOPE} .afc-note { font-size: 11px; color: var(--muted); }
${SCOPE} .afc-note--fine { font-size: 10px; }

/* Inputs */
${SCOPE} .afc-label { display: block; font-size: 11px; font-weight: 600; color: var(--text); margin: 10px 0 2px; }
${SCOPE} .afc-input, ${SCOPE} .afc-textarea, ${SCOPE} .afc-select {
  width: 100%; padding: 8px 10px; border: 1px solid var(--border); border-radius: 8px;
  font: inherit; font-size: 13px; background: var(--bg); color: var(--text); box-sizing: border-box; }
${SCOPE} .afc-textarea {
  font-size: 12px; line-height: 1.5; resize: vertical; white-space: pre-wrap; overflow-wrap: anywhere; }
${SCOPE} .afc-select { width: auto; padding: 6px 8px; cursor: pointer; }
${SCOPE} .afc-input:focus, ${SCOPE} .afc-textarea:focus, ${SCOPE} .afc-select:focus {
  outline: none; border-color: var(--brand); box-shadow: 0 0 0 3px color-mix(in srgb, var(--brand) 22%, transparent); }

/* A row inside a list (e.g. a saved draft), with a title and trailing actions */
${SCOPE} .afc-row {
  display: flex; gap: 8px; align-items: center; justify-content: space-between;
  padding: 8px 10px; border: 1px solid var(--border); border-radius: 8px; background: var(--bg); margin-top: 6px; }
${SCOPE} .afc-row__title {
  font-size: 13px; color: var(--text); flex: 1; min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${SCOPE} .afc-row__actions { display: flex; gap: 6px; flex: 0 0 auto; }

/* A cluster of controls \u2014 stacked full-width so each action is its own clear,
   easily-tappable target in the narrow panel (no cramped wrapping row). */
${SCOPE} .afc-toolbar { display: flex; flex-direction: column; align-items: stretch; gap: 8px; margin-top: 10px; }
${SCOPE} .afc-toolbar .afc-inline { justify-content: space-between; }
${SCOPE} .afc-inline { display: flex; align-items: center; gap: 6px; }
/* A vertical stack of buttons (file-upload actions, etc.). */
${SCOPE} .afc-btnstack { display: flex; flex-direction: column; align-items: stretch; gap: 6px; margin-top: 8px; }

/* Reassurance callout \u2014 a highlighted, readable notice (not faint muted text).
   Brand-tinted with a leading glyph; full --text contrast for the body. */
${SCOPE} .afc-notice {
  display: flex; gap: 8px; align-items: flex-start; margin-top: 10px; padding: 9px 11px;
  border-radius: 8px; border: 1px solid color-mix(in srgb, var(--brand) 40%, var(--border));
  background: color-mix(in srgb, var(--brand) 10%, var(--card, var(--bg)));
  color: var(--text); font-size: 12px; line-height: 1.5; }
${SCOPE} .afc-notice__icon {
  flex: 0 0 auto; margin-top: 1px; width: 16px; height: 16px; border-radius: 50%;
  background: var(--brand); color: #fff; font-size: 11px; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center; }

/* Inline "working\u2026" spinner for in-flight jobs */
${SCOPE} .afc-spin {
  display: inline-block; width: 11px; height: 11px; flex: 0 0 auto;
  border: 2px solid var(--border); border-top-color: var(--brand); border-radius: 50%;
  animation: afc-spin .7s linear infinite; vertical-align: -1px; margin-right: 7px; }
@keyframes afc-spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { ${SCOPE} .afc-spin { animation: none; } }

/* Explicit theme choice from the user's Settings toggle. Each root already defines a
   light default + an @media(prefers-color-scheme:dark) override; setting data-theme on
   the root wins over both (higher specificity), so the widget follows the toggle
   instead of only the OS. Palette matches the roots' own variables. */
${SCOPE}[data-theme="light"] {
  --bg:#fff; --surface:#f6f8fc; --card:#fff; --text:#14161c; --muted:#55606f; --border:#d7dce5;
  --brand:#155dfc; --grad:linear-gradient(90deg,#155dfc,#0ea5a4); --ok:#15803d; --ok-fg:#15803d;
  --danger-fg:#b91c1c; --warn-fg:#8a5300; --warn:#b45309; --hover-ring:rgba(15,23,43,.42); }
${SCOPE}[data-theme="dark"] {
  --bg:#16213c; --surface:#111b33; --card:#1b2946; --text:#e8edf6; --muted:#a6b6cd; --border:#2c3d60;
  --brand:#2563eb; --grad:linear-gradient(90deg,#4b8bff,#2dd4bf); --ok:#15803d; --ok-fg:#5bd88a;
  --danger-fg:#fca5a5; --warn-fg:#fbbf24; --warn:#fbbf24; --hover-ring:rgba(255,255,255,.6); }
`;
  function ensureComponentStyles() {
    if (document.getElementById("af-components")) return;
    const style = document.createElement("style");
    style.id = "af-components";
    style.textContent = COMPONENT_CSS;
    (document.head ?? document.documentElement).appendChild(style);
  }

  // src/shared/docx.ts
  function u16(b, o) {
    return b[o] | b[o + 1] << 8;
  }
  function u32(b, o) {
    return (b[o] | b[o + 1] << 8 | b[o + 2] << 16 | b[o + 3] << 24) >>> 0;
  }
  async function inflateRaw(data) {
    const copy = new Uint8Array(data.length);
    copy.set(data);
    const stream = new Blob([copy.buffer]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  async function deflateRaw(data) {
    const copy = new Uint8Array(data.length);
    copy.set(data);
    const stream = new Blob([copy.buffer]).stream().pipeThrough(new CompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  var unescapeXml = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  var escapeXml = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  function tokenKey(name) {
    return name.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function xmlBodyToText(xml) {
    return unescapeXml(
      xml.replace(/<\/w:p>/g, "\n").replace(/<w:br\s*\/?>/g, "\n").replace(/<w:tab\s*\/?>/g, "	").replace(/<[^>]+>/g, "")
    );
  }
  function readRaw(b) {
    let eocd = -1;
    for (let i = b.length - 22; i >= 0 && i > b.length - 22 - 65536; i--) {
      if (u32(b, i) === 101010256) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw new Error("not a zip");
    const count = u16(b, eocd + 10);
    let cd = u32(b, eocd + 16);
    const out = [];
    for (let e = 0; e < count; e++) {
      if (u32(b, cd) !== 33639248) break;
      const method = u16(b, cd + 10);
      const crc = u32(b, cd + 16);
      const compSize = u32(b, cd + 20);
      const uncompSize = u32(b, cd + 24);
      const nameLen = u16(b, cd + 28);
      const extraLen = u16(b, cd + 30);
      const commentLen = u16(b, cd + 32);
      const localOff = u32(b, cd + 42);
      const name = new TextDecoder().decode(b.subarray(cd + 46, cd + 46 + nameLen));
      const lNameLen = u16(b, localOff + 26);
      const lExtraLen = u16(b, localOff + 28);
      const dataStart = localOff + 30 + lNameLen + lExtraLen;
      out.push({ name, method, comp: b.subarray(dataStart, dataStart + compSize).slice(), crc, uncompSize });
      cd += 46 + nameLen + extraLen + commentLen;
    }
    return out;
  }
  async function entryBytes(e) {
    return e.method === 0 ? e.comp : inflateRaw(e.comp);
  }
  var CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(buf) {
    let c = 4294967295;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 255] ^ c >>> 8;
    return (c ^ 4294967295) >>> 0;
  }
  function writeZip(entries) {
    const enc = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;
    for (const e of entries) {
      const nameBytes = enc.encode(e.name);
      const local = new Uint8Array(30 + nameBytes.length);
      const lv = new DataView(local.buffer);
      lv.setUint32(0, 67324752, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(8, e.method, true);
      lv.setUint32(14, e.crc, true);
      lv.setUint32(18, e.comp.length, true);
      lv.setUint32(22, e.uncompSize, true);
      lv.setUint16(26, nameBytes.length, true);
      local.set(nameBytes, 30);
      chunks.push(local, e.comp);
      const cen = new Uint8Array(46 + nameBytes.length);
      const cv = new DataView(cen.buffer);
      cv.setUint32(0, 33639248, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint16(10, e.method, true);
      cv.setUint32(16, e.crc, true);
      cv.setUint32(20, e.comp.length, true);
      cv.setUint32(24, e.uncompSize, true);
      cv.setUint16(28, nameBytes.length, true);
      cv.setUint32(42, offset, true);
      cen.set(nameBytes, 46);
      central.push(cen);
      offset += local.length + e.comp.length;
    }
    const cdSize = central.reduce((n, c) => n + c.length, 0);
    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 101010256, true);
    ev.setUint16(8, entries.length, true);
    ev.setUint16(10, entries.length, true);
    ev.setUint32(12, cdSize, true);
    ev.setUint32(16, offset, true);
    const all = [...chunks, ...central, eocd];
    const total = all.reduce((n, a) => n + a.length, 0);
    const out = new Uint8Array(total);
    let p = 0;
    for (const a of all) {
      out.set(a, p);
      p += a.length;
    }
    return out;
  }
  var SYNONYMS = {
    company: "company",
    companyname: "company",
    organization: "company",
    organisation: "company",
    org: "company",
    employer: "company",
    role: "role",
    roletitle: "role",
    position: "role",
    jobtitle: "role",
    title: "role",
    job: "role",
    date: "date",
    today: "date",
    todaysdate: "date"
  };
  function valueForToken(name, values) {
    const key = tokenKey(name);
    const field = SYNONYMS[key];
    if (field && values[field] && values[field].trim()) return values[field];
    const r = values.custom?.find((x) => tokenKey(x.token) === key && x.value.trim() !== "");
    return r ? r.value : void 0;
  }
  function isTemplateToken(name) {
    return tokenKey(name) in SYNONYMS;
  }
  function fillParagraph(para, values, replaced, unresolved) {
    const tRe = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g;
    const runs = [...para.matchAll(tRe)];
    if (!runs.length) return para;
    const texts = runs.map((m) => unescapeXml(m[1]));
    const concat = texts.join("");
    if (!/\[[^\]\n]{1,60}\]/.test(concat)) return para;
    const spans = [];
    for (const pm of concat.matchAll(/\[([^\]\n]{1,60})\]/g)) {
      const whole = pm[0];
      const name = pm[1];
      const key = tokenKey(name);
      const v = valueForToken(name, values);
      if (v && v.trim()) {
        if (!replaced.has(key)) replaced.set(key, { token: whole, value: v });
        spans.push({ start: pm.index, end: pm.index + whole.length, value: v });
      } else if (/[a-z]/i.test(name) && !unresolved.has(key)) {
        unresolved.set(key, whole);
      }
    }
    if (!spans.length) return para;
    const removed = new Array(concat.length).fill(false);
    const injectAt = /* @__PURE__ */ new Map();
    for (const s of spans) {
      injectAt.set(s.start, s.value);
      for (let c = s.start; c < s.end; c++) removed[c] = true;
    }
    let pos = 0;
    let ri = 0;
    return para.replace(tRe, (full) => {
      const orig = texts[ri++];
      const a = pos;
      const b = pos + orig.length;
      pos = b;
      let next = "";
      for (let c = a; c < b; c++) {
        const inj = injectAt.get(c);
        if (inj) next += inj;
        if (!removed[c]) next += concat[c];
      }
      if (next === orig) return full;
      return `<w:t xml:space="preserve">${escapeXml(next)}</w:t>`;
    });
  }
  async function fillDocx(bytes, values) {
    const entries = readRaw(new Uint8Array(bytes));
    const doc = entries.find((e) => e.name === "word/document.xml");
    if (!doc) throw new Error("This file doesn't look like a Word document.");
    const replaced = /* @__PURE__ */ new Map();
    const unresolved = /* @__PURE__ */ new Map();
    const xml = new TextDecoder().decode(await entryBytes(doc)).replace(
      /<w:p\b[^>]*>[\s\S]*?<\/w:p>/g,
      (para) => fillParagraph(para, values, replaced, unresolved)
    );
    const newBytes = new TextEncoder().encode(xml);
    doc.crc = crc32(newBytes);
    doc.uncompSize = newBytes.length;
    if (doc.method === 8) doc.comp = await deflateRaw(newBytes);
    else doc.comp = newBytes;
    const out = writeZip(entries);
    return {
      blob: new Blob([out.buffer], {
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      }),
      text: xmlBodyToText(xml).trim(),
      replaced: [...replaced.values()],
      unresolved: [...unresolved.values()]
    };
  }

  // src/shared/resume-upload.ts
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function storedFile(key) {
    try {
      const obj = (await chrome.storage.local.get(key))[key];
      if (!obj?.dataUrl) return null;
      const blob = await (await fetch(obj.dataUrl)).blob();
      return { blob, name: obj.name || "" };
    } catch {
      return null;
    }
  }
  async function hasStoredFile(key) {
    return await storedFile(key) !== null;
  }
  function pageShowsFile(el, file) {
    const base = file.name.replace(/\.[^.]+$/, "").slice(0, 24);
    const scope = el.closest(
      "form, fieldset, [data-testid='field'], [class*='upload' i], [class*='file' i], [class*='dropzone' i]"
    ) || el.parentElement?.parentElement || el.parentElement;
    const t = scope?.textContent || "";
    if (t.includes(file.name)) return true;
    if (base.length > 3 && t.includes(base)) return true;
    return /\b([1-9]\d*)\s+files?\s+selected\b/i.test(t);
  }
  async function putFile(el, file, verify) {
    if (!el || el.type !== "file") return { ok: false, note: "not a file input" };
    const dt = new DataTransfer();
    dt.items.add(file);
    el.files = dt.files;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    try {
      const zone = el.closest("[class*='dropzone' i], [class*='upload' i], [data-testid*='upload' i], label") || el.parentElement;
      if (zone) {
        for (const type of ["dragenter", "dragover", "drop"]) {
          const ev = new DragEvent(type, { bubbles: true, cancelable: true });
          Object.defineProperty(ev, "dataTransfer", { value: dt });
          zone.dispatchEvent(ev);
        }
      }
    } catch {
    }
    let shown = false;
    for (let i = 0; i < 6; i++) {
      await sleep(260);
      if (verify ? await verify() : pageShowsFile(el, file)) {
        shown = true;
        break;
      }
    }
    if (shown) return { ok: true, confirmed: true, note: `attached ${file.name}` };
    const held = !!(el.files && el.files.length === 1);
    return held ? {
      ok: true,
      confirmed: false,
      note: `set ${file.name}, but the form didn't visibly show it. Please confirm it, or use the form's own upload button.`
    } : {
      ok: false,
      note: `couldn't attach ${file.name}. Use the form's own upload button for this one.`
    };
  }
  async function attach(el, key, defaultName, missing, verify) {
    if (!el || el.type !== "file") return { ok: false, note: "not a file input" };
    const stored = await storedFile(key);
    if (!stored) return { ok: false, note: missing };
    const file = new File([stored.blob], stored.name || defaultName, {
      type: stored.blob.type || "application/pdf"
    });
    return putFile(el, file, verify);
  }
  function attachPickedFile(el, file, verify) {
    return putFile(el, file, verify);
  }
  function attachResume(el, verify) {
    const last = state.profile.identity.lastName;
    return attach(
      el,
      "resumeFile",
      last ? `${last}_Resume.pdf` : "Resume.pdf",
      "No resume saved. Upload one in the extension's Options (Documents).",
      verify
    );
  }
  var OUR_UI = "#af-overlay, #af-data, #af-editor, #af-cfill, #af-notice";
  var COVER_RE = /cover.?letter|coverletter|motivation|letter of (?:intent|interest|motivation)/;
  function fileInputHay(el) {
    let hay = `${el.name} ${el.id} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("data-testid") || ""} ${el.accept || ""}`;
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) hay += " " + (l.textContent || "");
    }
    const lb = el.getAttribute("aria-labelledby");
    if (lb) for (const id of lb.split(/\s+/)) hay += " " + (document.getElementById(id)?.textContent || "");
    const wrap = el.closest("label");
    if (wrap) hay += " " + (wrap.textContent || "");
    const scope = el.closest(
      "[data-testid='field'], fieldset, [class*='field' i], [class*='upload' i], [class*='question' i]"
    );
    if (scope) hay += " " + (scope.textContent || "").slice(0, 200);
    return hay.toLowerCase();
  }
  function findCoverLetterInput() {
    const inputs = [...document.querySelectorAll('input[type="file"]')].filter(
      (el) => !el.closest(OUR_UI)
    );
    const covers = inputs.filter((el) => COVER_RE.test(fileInputHay(el)));
    return covers.find((el) => /docx|word/i.test(el.accept || "")) || covers[0] || null;
  }
  function attachFileToCoverLetterField(file) {
    const el = findCoverLetterInput();
    if (!el)
      return Promise.resolve({
        ok: false,
        note: "No cover-letter upload found on this page. Download it and use the form's own upload button."
      });
    return putFile(el, file);
  }
  function attachCoverLetter(el) {
    const last = state.profile.identity.lastName;
    return attach(
      el,
      "coverLetterFile",
      last ? `${last}_Cover_Letter.pdf` : "Cover_Letter.pdf",
      "No cover letter saved \u2014 upload one in the extension's Options (Documents)."
    );
  }

  // src/shared/app-context.ts
  var KEY2 = "appContext";
  function jobIdFrom(pathname, search) {
    const q = new URLSearchParams(search);
    for (const [pk, pv] of q) {
      if (/^(currentjobid|gh_jid|job_?id|jid|req_?id|posting_?id)$/i.test(pk) && pv) return pv.toLowerCase();
    }
    let path = pathname;
    try {
      path = decodeURIComponent(pathname);
    } catch {
    }
    const uuid = path.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    if (uuid) return uuid[0].toLowerCase();
    const req = path.match(/(?:^|[^a-z0-9])([a-z]{1,4}[-_]?\d{3,})(?![a-z0-9])/i);
    if (req) return req[1].toLowerCase();
    const ids = path.match(/\d{4,}/g);
    if (ids && ids.length) return ids.sort((a, b) => b.length - a.length)[0];
    return "";
  }
  function jobIdFromUrl() {
    try {
      return jobIdFrom(location.pathname, location.search);
    } catch {
      return "";
    }
  }
  function currentHost() {
    try {
      return location.hostname;
    } catch {
      return "";
    }
  }
  function currentJobKey() {
    return `${currentHost()}#${jobIdFromUrl()}`;
  }
  function debugJobKey() {
    return currentJobKey();
  }
  function jobKeyMatches(savedKey, curHost, curId) {
    if (!savedKey) return false;
    const hash = savedKey.indexOf("#");
    const savedHost = hash >= 0 ? savedKey.slice(0, hash) : savedKey;
    const savedId = hash >= 0 ? savedKey.slice(hash + 1) : "";
    if (savedHost !== curHost) return false;
    if (savedId && curId && savedId !== curId) return false;
    return true;
  }
  function sameJob(savedKey) {
    return jobKeyMatches(savedKey, currentHost(), jobIdFromUrl());
  }
  async function read() {
    const o = await chrome.storage.local.get(KEY2);
    return o[KEY2] || {};
  }
  async function readForThisJob() {
    const s = await read();
    return sameJob(s.jobKey) ? s : {};
  }
  var chain = Promise.resolve();
  function patch(fields) {
    chain = chain.then(async () => {
      const cur = await read();
      const base = sameJob(cur.jobKey) ? cur : {};
      await chrome.storage.local.set({ [KEY2]: { ...base, ...fields, jobKey: currentJobKey() } });
    });
    return chain;
  }
  async function loadConfirmed() {
    const s = await readForThisJob();
    return { company: s.company, role: s.role, jobText: s.jobText, coverAttached: s.coverAttached };
  }
  function saveCoverAttached(v) {
    void patch({ coverAttached: v });
  }
  async function loadPerApp() {
    return (await readForThisJob()).perApp || {};
  }
  function saveConfirmedCompany(v) {
    void patch({ company: v, coverAttached: false });
  }
  function saveConfirmedRole(v) {
    void patch({ role: v, coverAttached: false });
  }
  function saveJobText(v) {
    void patch({ jobText: v });
  }
  function savePerApp(map) {
    void patch({ perApp: map });
  }
  async function clearContext() {
    chain = chain.then(() => chrome.storage.local.remove(KEY2));
    return chain;
  }
  function preferConfirmed(saved, scraped) {
    return saved !== void 0 ? saved : scraped;
  }

  // src/shared/cover-fill-store.ts
  var KEY3 = "pendingCoverFill";
  var STALE_MS = 24 * 60 * 60 * 1e3;
  async function savePendingCoverFill(rec) {
    await chrome.storage.local.set({ [KEY3]: { ...rec, savedAt: Date.now() } });
  }
  async function loadPendingCoverFill() {
    const rec = (await chrome.storage.local.get(KEY3))[KEY3];
    if (!rec || typeof rec.dataUrl !== "string") return null;
    if (Date.now() - (rec.savedAt || 0) > STALE_MS) return null;
    return rec;
  }
  function clearPendingCoverFill() {
    return chrome.storage.local.remove(KEY3);
  }

  // src/shared/review-overlay.ts
  var THEME_ROOTS = "#af-overlay, #af-data, #af-editor, #af-cfill";
  var afTheme = "";
  function applyThemeAttr(root) {
    if (afTheme) root.setAttribute("data-theme", afTheme);
    else root.removeAttribute("data-theme");
  }
  try {
    void chrome.storage.local.get("af-theme").then((o) => {
      const t = o["af-theme"];
      afTheme = t === "light" || t === "dark" ? t : "";
      document.querySelectorAll(THEME_ROOTS).forEach(applyThemeAttr);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes["af-theme"]) return;
      const t = changes["af-theme"].newValue;
      afTheme = t === "light" || t === "dark" ? t : "";
      document.querySelectorAll(THEME_ROOTS).forEach(applyThemeAttr);
    });
  } catch {
  }
  function genericCommit(el, value) {
    const proto = el.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    if (el.value === value) return true;
    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
    const a = norm(el.value);
    const b = norm(value);
    return b !== "" && (a === b || a.includes(b));
  }
  function setterFor(board) {
    if (board === "workday") return commitWorkday;
    if (board === "greenhouse") return commitGreenhouse;
    if (board === "ashby") return commitAshby;
    return genericCommit;
  }
  function highlight(el, ok) {
    const target = el.closest('[data-automation-id^="formField"]') ?? el;
    target.style.outline = ok ? "2px solid #15803d" : "2px dashed #b91c1c";
    target.style.outlineOffset = "1px";
  }
  function applyEntry(entry, value, board) {
    const el = state.elements[entry.idx];
    if (!el) return { ok: false, note: "element gone" };
    const type = entry.field.type;
    try {
      if (type === "text" || type === "textarea") {
        const ok = setterFor(board)(el, value);
        highlight(el, ok);
        return { ok, note: ok ? "" : "value did not stick" };
      }
      if (type === "select") {
        const sel = el;
        const want = String(value).toLowerCase();
        const opt = [...sel.options].find(
          (o) => o.value.toLowerCase() === want || o.text.trim().toLowerCase() === want
        );
        if (!opt) return { ok: false, note: "no matching option" };
        sel.value = opt.value;
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        highlight(el, true);
        return { ok: true, note: "" };
      }
      const opts = entry.field.options;
      const grp = state.groups[entry.idx];
      if (type === "checkbox") {
        if (entry.field.multi && opts && grp) {
          const wanted = new Set(
            value.split("\n").map((s) => s.trim().toLowerCase()).filter(Boolean)
          );
          let ok = true;
          opts.forEach((o, i) => {
            const box = grp[i];
            if (!box) return;
            const want2 = wanted.has(o.label.toLowerCase());
            if (box.checked !== want2) box.click();
            if (box.checked !== want2) ok = false;
          });
          highlight(grp[0] ?? el, ok);
          return { ok, note: ok ? `checked ${wanted.size}` : "some boxes didn't toggle" };
        }
        const cb = el;
        const want = /^(yes|true|1|on)$/i.test(String(value));
        if (cb.checked !== want) cb.click();
        highlight(el, cb.checked === want);
        return { ok: cb.checked === want, note: "" };
      }
      if (type === "radio") {
        if (opts && grp) {
          const i = opts.findIndex((o) => optionMatches(o.label, value));
          const target = i >= 0 ? grp[i] : null;
          if (!target) return { ok: false, note: "no matching option" };
          const inp = target;
          if (inp.type === "radio" || inp.type === "checkbox") {
            if (!inp.checked) inp.click();
            highlight(target, inp.checked);
            return { ok: inp.checked, note: inp.checked ? "" : "did not select" };
          }
          fireMouse(target, ["pointerdown", "mousedown", "mouseup", "click"]);
          highlight(target, true);
          return { ok: true, note: `chose "${value}"` };
        }
        const rb = el;
        rb.click();
        highlight(el, rb.checked);
        return { ok: rb.checked, note: rb.checked ? "" : "did not check" };
      }
      return { ok: false, note: "unsupported here" };
    } catch (e) {
      return { ok: false, note: e instanceof Error ? e.message : String(e) };
    }
  }
  var esc = (s) => String(s == null ? "" : s).replace(
    /[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c
  );
  function sourceBadge(e) {
    if (e.source === "experience") return "\u2248 estimated";
    if (e.source === "ollama" || e.source === "ai" || e.tier === 2 || e.tier === 3)
      return "\u26A0 AI \u2014 verify";
    if (e.source === "deterministic") return "\u2713 matched";
    return `tier ${e.tier}`;
  }
  function debugReport(plan, board) {
    const s = plan.summary;
    const lines = [
      "Autofill debug",
      `url: ${location.href}`,
      `board: ${board}`,
      `fields: ${s.total} \u2014 fill ${s.fill}, review ${s.review}, skip ${s.skip}, adapter ${s.adapter}`,
      ""
    ];
    for (const e of plan.entries) {
      const f = e.field;
      const ref = f.name || f.id || f.automationId;
      const opts = f.options?.length ? `  opts=[${f.options.map((o) => o.label).slice(0, 10).join(" | ")}]` : "";
      lines.push(
        `[${e.decision}] ${JSON.stringify(f.label || "")} (${f.type}${ref ? ` #${ref}` : ""}) = ${JSON.stringify(e.value)}  <${e.source}> ${e.reason}${opts}`
      );
    }
    return lines.join("\n");
  }
  async function copyText(t) {
    try {
      await navigator.clipboard.writeText(t);
      return true;
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = t;
        ta.style.cssText = "position:fixed;opacity:0;pointer-events:none";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }
  function copyButton(getText) {
    const b = document.createElement("button");
    b.className = "copy";
    b.type = "button";
    b.textContent = "Copy";
    b.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const ok = await copyText(getText());
      b.textContent = ok ? "Copied \u2713" : "Copy failed";
      setTimeout(() => b.textContent = "Copy", 1200);
    });
    return b;
  }
  function openEditor(opts) {
    ensureComponentStyles();
    document.getElementById("af-editor")?.remove();
    const back = document.createElement("div");
    back.id = "af-editor";
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    back.setAttribute("aria-label", opts.title);
    back.innerHTML = `
    <style>
      #af-editor { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center;
        justify-content: center; background: rgba(0,0,0,.5); font: 14px/1.5 -apple-system, Segoe UI, sans-serif;
        --bg:#fff; --surface:#f6f8fc; --text:#14161c; --muted:#55606f; --border:#d7dce5; --brand:#155dfc; --warn:#b45309; }
      @media (prefers-color-scheme: dark) { #af-editor {
        --bg:#16213c; --surface:#111b33; --text:#e8edf6; --muted:#a6b6cd; --border:#2c3d60; --brand:#4b8bff; --warn:#fbbf24; } }
      #af-editor * { box-sizing: border-box; }
      #af-editor .card { width: min(760px, 92vw); height: min(80vh, 720px); display: flex; flex-direction: column;
        background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 12px;
        box-shadow: 0 20px 60px rgba(0,0,0,.45); overflow: hidden; }
      #af-editor .head { display: flex; align-items: center; justify-content: space-between; gap: 8px;
        padding: 12px 14px; background: var(--surface); border-bottom: 1px solid var(--border); }
      #af-editor .head b { font-size: 14px; }
      #af-editor .ed-title { flex: 1; min-width: 0; font: inherit; font-size: 14px; font-weight: 600;
        padding: 6px 8px; border: 1px solid var(--border); border-radius: 8px; background: var(--bg); color: var(--text); }
      #af-editor .ed-title:focus { outline: none; border-color: var(--brand); box-shadow: 0 0 0 3px color-mix(in srgb, var(--brand) 22%, transparent); }
      #af-editor .ed-ta { flex: 1; width: 100%; border: 0; padding: 14px; resize: none; font: inherit;
        line-height: 1.6; background: var(--bg); color: var(--text); outline: none; }
      #af-editor .foot { display: flex; gap: 8px; justify-content: flex-end; padding: 10px 14px;
        border-top: 1px solid var(--border); background: var(--surface); }
      #af-editor button { font: inherit; font-weight: 600; font-size: 13px; border-radius: 8px; cursor: pointer; padding: 8px 14px; }
      #af-editor .sec { background: var(--bg); color: var(--text); border: 1px solid var(--border); }
      #af-editor .pri { background: var(--brand); color: #fff; border: 1px solid transparent; }
      #af-editor .x { background: transparent; border: 0; color: var(--muted); font-size: 20px; padding: 0 6px; }
      #af-editor .ed-note { padding: 9px 14px; font-size: 12px; color: var(--text);
        background: color-mix(in srgb, var(--brand) 9%, var(--surface));
        border-bottom: 1px solid var(--border); border-left: 3px solid var(--brand); }
    </style>
    <div class="card">
      <div class="head">
        <b hidden></b>
        <input class="ed-title" type="text" aria-label="Draft name" hidden>
        <button class="x" type="button" aria-label="Close without saving">\xD7</button>
      </div>
      <div class="ed-note" hidden></div>
      <textarea class="ed-ta"></textarea>
      <div class="foot"><button class="ed-copy afc-btn afc-btn--secondary" type="button">Copy</button><button class="ed-done afc-btn afc-btn--primary" type="button">Done</button></div>
    </div>`;
    const titleB = back.querySelector("b");
    const titleIn = back.querySelector(".ed-title");
    if (opts.onRename) {
      titleIn.hidden = false;
      titleIn.value = opts.title;
      titleIn.title = "Rename this draft";
    } else {
      titleB.hidden = false;
      titleB.textContent = opts.title;
    }
    if (opts.note) {
      const noteEl = back.querySelector(".ed-note");
      noteEl.textContent = (opts.warn ? "\u26A0 " : "") + opts.note;
      noteEl.hidden = false;
      if (opts.warn) {
        noteEl.style.color = "var(--text)";
        noteEl.style.fontWeight = "600";
        noteEl.style.borderLeftColor = "var(--warn)";
        noteEl.style.background = "color-mix(in srgb, var(--warn) 14%, var(--surface))";
      }
    }
    document.body.appendChild(back);
    applyThemeAttr(back);
    const ta = back.querySelector(".ed-ta");
    ta.setAttribute("aria-label", opts.title);
    ta.value = opts.value;
    let lastName = opts.title;
    const commitName = () => {
      if (!opts.onRename) return;
      const v = titleIn.value.trim();
      if (v && v !== lastName) {
        lastName = v;
        opts.onRename(v);
      }
    };
    titleIn.addEventListener("blur", commitName);
    titleIn.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        commitName();
        ta.focus();
      }
    });
    const close = () => back.remove();
    back.querySelector(".x").addEventListener("click", close);
    back.querySelector(".ed-copy").addEventListener("click", () => void copyText(ta.value));
    back.querySelector(".ed-done").addEventListener("click", () => {
      commitName();
      opts.onSave?.(ta.value);
      close();
    });
    back.addEventListener("click", (e) => {
      if (e.target === back) close();
    });
    back.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close();
      }
    });
    ta.focus();
  }
  var CFILL_STYLE = `
  <style>
    #af-cfill { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center;
      justify-content: center; background: rgba(0,0,0,.5); font: 14px/1.5 -apple-system, Segoe UI, sans-serif;
      --bg:#fff; --surface:#f6f8fc; --card:#fff; --text:#14161c; --muted:#55606f; --border:#d7dce5; --brand:#155dfc; --warn:#b45309; }
    @media (prefers-color-scheme: dark) { #af-cfill {
      --bg:#16213c; --surface:#111b33; --card:#1b2946; --text:#e8edf6; --muted:#a6b6cd; --border:#2c3d60; --brand:#4b8bff; --warn:#fbbf24; } }
    #af-cfill * { box-sizing: border-box; }
    #af-cfill .card { width: min(720px, 94vw); max-height: 88vh; display: flex; flex-direction: column;
      background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0,0,0,.45); overflow: hidden; }
    #af-cfill .head { display: flex; align-items: center; justify-content: space-between; gap: 8px;
      padding: 12px 14px; background: var(--surface); border-bottom: 1px solid var(--border); }
    #af-cfill .head b { font-size: 14px; }
    #af-cfill .body { padding: 12px 14px; overflow: auto; }
    #af-cfill .grid { display: flex; gap: 10px; flex-wrap: wrap; }
    #af-cfill .grid > label { flex: 1 1 220px; }
    #af-cfill .prev { white-space: pre-wrap; word-break: break-word; background: var(--bg);
      border: 1px solid var(--border); border-radius: 8px; padding: 14px 16px; font-size: 13px;
      line-height: 1.6; max-height: 38vh; overflow: auto; margin-top: 8px; }
    #af-cfill .prev mark.cf-fill { background: color-mix(in srgb, var(--brand) 32%, var(--bg));
      color: var(--text); border-radius: 6px; padding: 1px 5px; box-decoration-break: clone;
      -webkit-box-decoration-break: clone; }
    #af-cfill .prev mark.cf-ph { background: color-mix(in srgb, var(--warn) 55%, var(--bg));
      color: #14161c; border-radius: 6px; padding: 1px 5px; font-weight: 700; box-decoration-break: clone;
      -webkit-box-decoration-break: clone; }
    #af-cfill .cf-debug-out { white-space: pre-wrap; word-break: break-word; font: 11px/1.5 ui-monospace, monospace;
      background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 8px 10px;
      margin-top: 8px; color: var(--text); }
    #af-cfill .prev-legend { display: flex; gap: 14px; flex-wrap: wrap; font-size: 11px;
      color: var(--muted); margin: 8px 0 0; }
    #af-cfill .prev-legend .sw { display: inline-block; width: 10px; height: 10px; border-radius: 2px;
      vertical-align: -1px; margin-right: 4px; }
    #af-cfill .foot { display: flex; gap: 8px; justify-content: flex-end; padding: 10px 14px;
      border-top: 1px solid var(--border); background: var(--surface); }
    #af-cfill .x { background: transparent; border: 0; color: var(--muted); font-size: 20px; cursor: pointer; }
  </style>`;
  async function openCoverFill(values, attachCover) {
    ensureComponentStyles();
    document.getElementById("af-editor")?.remove();
    document.getElementById("af-cfill")?.remove();
    const settings = (await chrome.storage.local.get("coverLetterFile")).coverLetterFile;
    const back = document.createElement("div");
    back.id = "af-cfill";
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    back.setAttribute("aria-label", "Fill cover letter");
    back.innerHTML = `${CFILL_STYLE}
    <div class="card" tabindex="-1">
      <div class="head"><b>Fill cover letter</b><button class="x" type="button" aria-label="Close">\xD7</button></div>
      <div class="body"></div>
    </div>`;
    const body = back.querySelector(".body");
    const card = back.querySelector(".card");
    const prevFocus = document.activeElement;
    const close = () => {
      back.remove();
      prevFocus?.focus?.();
    };
    back.querySelector(".x").addEventListener("click", close);
    back.addEventListener("click", (e) => {
      if (e.target === back) close();
    });
    const focusables = () => [
      ...back.querySelectorAll(
        'a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'
      )
    ].filter((el) => el.offsetParent !== null);
    back.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close();
        return;
      }
      if (e.key === "Tab") {
        const f = focusables();
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        const active = document.activeElement;
        if (e.shiftKey && (active === first || !back.contains(active))) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && (active === last || !back.contains(active))) {
          e.preventDefault();
          first.focus();
        }
      }
    });
    document.body.appendChild(back);
    applyThemeAttr(back);
    card.focus();
    const date = (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    const persistent = (await chrome.storage.local.get("coverLetterReplacements")).coverLetterReplacements || [];
    const savedFill = await loadPerApp();
    const savedMeta = await loadConfirmed();
    const pending = await loadPendingCoverFill();
    body.innerHTML = `
    <div class="afc-note">Fill your .docx cover letter's placeholders and download a new copy. Your saved file is never changed.</div>
    <div class="cf-src" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px"></div>
    <div class="grid" style="margin-top:10px">
      <label class="afc-label">Company<input class="cf-company afc-input" type="text"></label>
      <label class="afc-label">Job title<input class="cf-role afc-input" type="text"></label>
    </div>
    <button type="button" class="cf-reset afc-btn afc-btn--ghost afc-btn--sm" style="margin-top:4px;display:none">Use the values from this page</button>
    <div class="cf-extra"></div>
    <label class="cf-dbg afc-note afc-note--fine" style="display:none;gap:6px;align-items:center;margin-top:8px;cursor:pointer"><input type="checkbox" class="cf-dbg-cb"> Dev: auto-fill placeholders with editable defaults + show a fill readout</label>
    <button type="button" class="cf-update afc-btn afc-btn--secondary afc-btn--sm" style="margin-top:8px">Update preview</button>
    <div class="cf-summary" style="margin-top:10px"></div>
    <div class="prev cf-prev" aria-label="Filled letter preview"></div>
    <div class="prev-legend">
      <span><span class="sw" style="background:color-mix(in srgb, var(--brand) 32%, var(--bg))"></span>Filled from your values</span>
      <span><span class="sw" style="background:color-mix(in srgb, var(--warn) 55%, var(--bg))"></span>Still a placeholder</span>
    </div>
    <div class="afc-note afc-note--fine" style="margin-top:4px">Fonts, formatting, and links are kept in the downloaded .docx \u2014 this preview shows the text only.</div>
    <div class="cf-debug-out" hidden></div>`;
    const companyIn = body.querySelector(".cf-company");
    const roleIn = body.querySelector(".cf-role");
    const extra = body.querySelector(".cf-extra");
    const updateBtn = body.querySelector(".cf-update");
    const summary = body.querySelector(".cf-summary");
    const prev = body.querySelector(".cf-prev");
    const srcRow = body.querySelector(".cf-src");
    const resetBtn = body.querySelector(".cf-reset");
    companyIn.value = pending?.company ?? (typeof savedMeta.company === "string" ? savedMeta.company : values.company);
    roleIn.value = pending?.role ?? (typeof savedMeta.role === "string" ? savedMeta.role : values.role);
    const syncResetVisibility = () => {
      const differs = companyIn.value.trim() !== (values.company || "").trim() || roleIn.value.trim() !== (values.role || "").trim();
      resetBtn.style.display = differs && (values.company || values.role) ? "" : "none";
    };
    const persistMeta = () => {
      saveConfirmedCompany(companyIn.value);
      saveConfirmedRole(roleIn.value);
    };
    for (const inp of [companyIn, roleIn]) {
      inp.addEventListener("input", () => {
        persistMeta();
        syncResetVisibility();
      });
      inp.addEventListener("change", () => void apply());
    }
    resetBtn.addEventListener("click", () => {
      companyIn.value = values.company;
      roleIn.value = values.role;
      persistMeta();
      syncResetVisibility();
      void apply();
    });
    syncResetVisibility();
    let bytes = null;
    let sourceName = "";
    const srcLabel = document.createElement("span");
    srcLabel.className = "afc-note afc-note--fine";
    srcLabel.style.flex = "1 1 160px";
    const picker = document.createElement("input");
    picker.type = "file";
    picker.accept = ".docx";
    picker.style.display = "none";
    const chooseBtn = document.createElement("button");
    chooseBtn.type = "button";
    chooseBtn.className = "afc-btn afc-btn--secondary afc-btn--sm";
    chooseBtn.textContent = "Choose a different file";
    chooseBtn.addEventListener("click", () => picker.click());
    srcRow.append(srcLabel, chooseBtn, picker);
    const foot = document.createElement("div");
    foot.className = "foot";
    const runAttach = (file) => attachCover ? attachCover(file) : attachFileToCoverLetterField(file);
    foot.innerHTML = `
    <button type="button" class="cf-copy afc-btn afc-btn--secondary">Copy text</button>
    <button type="button" class="cf-attach afc-btn afc-btn--secondary">Attach to this application</button>
    <button type="button" class="cf-dl afc-btn afc-btn--primary">Download .docx</button>
    <button type="button" class="cf-done afc-btn afc-btn--ghost">Done</button>`;
    back.querySelector(".card").appendChild(foot);
    const doneBtn = foot.querySelector(".cf-done");
    doneBtn.addEventListener("click", close);
    const copyBtn = foot.querySelector(".cf-copy");
    const dlBtn = foot.querySelector(".cf-dl");
    const attachBtn = foot.querySelector(".cf-attach");
    let lastText = "";
    let lastBlob = null;
    let lastTemplateGaps = [];
    const perApp = /* @__PURE__ */ new Map();
    const seenTokens = /* @__PURE__ */ new Map();
    const renderedKeys = /* @__PURE__ */ new Set();
    const key = (t) => t.toLowerCase().replace(/[^a-z0-9]/g, "");
    for (const [k, v] of Object.entries(pending?.perApp ?? savedFill)) perApp.set(k, v);
    const persistentByKey = /* @__PURE__ */ new Map();
    for (const r of persistent) if (r.token) persistentByKey.set(key(r.token), r.value);
    const savePerApp2 = () => {
      savePerApp(Object.fromEntries(perApp));
    };
    const renderExtra = () => {
      if (!seenTokens.size) return;
      if (!extra.querySelector(".cf-extra-head")) {
        const lbl = document.createElement("div");
        lbl.className = "afc-note afc-note--fine cf-extra-head";
        lbl.style.margin = "10px 0 2px";
        lbl.textContent = "Other placeholders in this letter \u2014 fill any you want for this application (Tab moves between them):";
        extra.appendChild(lbl);
      }
      for (const [k, token] of seenTokens) {
        if (renderedKeys.has(k)) continue;
        renderedKeys.add(k);
        const row = document.createElement("label");
        row.className = "afc-label";
        row.textContent = token;
        const inp = document.createElement("input");
        inp.className = "afc-input";
        inp.type = "text";
        inp.dataset.cfkey = k;
        inp.value = perApp.get(k) ?? persistentByKey.get(k) ?? "";
        inp.addEventListener("input", () => {
          perApp.set(k, inp.value);
          savePerApp2();
        });
        inp.addEventListener("change", () => void apply());
        row.appendChild(inp);
        extra.appendChild(row);
      }
    };
    const apply = async () => {
      if (!bytes) {
        prev.textContent = "";
        summary.textContent = "Choose a .docx cover letter above to fill.";
        dlBtn.disabled = true;
        copyBtn.disabled = true;
        return;
      }
      extra.querySelectorAll("input[data-cfkey]").forEach((inp) => {
        perApp.set(inp.dataset.cfkey, inp.value);
      });
      updateBtn.disabled = true;
      try {
        const byKey = /* @__PURE__ */ new Map();
        for (const r of persistent) {
          if (r.token && r.value.trim()) byKey.set(key(r.token), { token: r.token, value: r.value });
        }
        for (const [k, v] of perApp) {
          if (v.trim()) byKey.set(k, { token: k, value: v });
        }
        const custom = [...byKey.values()];
        const res = await fillDocx(bytes, {
          company: companyIn.value.trim(),
          role: roleIn.value.trim(),
          date,
          custom
        });
        lastText = res.text;
        lastBlob = res.blob;
        lastTemplateGaps = res.unresolved.filter((t) => isTemplateToken(t.replace(/^\[|\]$/g, "")));
        dlBtn.disabled = false;
        copyBtn.disabled = false;
        attachBtn.disabled = false;
        attachBtn.textContent = "Attach to this application";
        try {
          const dataUrl = await new Promise((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(r.result);
            r.onerror = () => reject(r.error);
            r.readAsDataURL(res.blob);
          });
          void savePendingCoverFill({
            name: filledFileName(),
            dataUrl,
            text: res.text,
            company: companyIn.value,
            role: roleIn.value,
            perApp: Object.fromEntries(perApp),
            hasTemplateGaps: lastTemplateGaps.length > 0
          });
        } catch {
        }
        const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        let html = esc(res.text);
        const vals = [...new Set(res.replaced.map((r) => r.value).filter((v) => v && v.trim().length >= 2))].sort(
          (a, b) => b.length - a.length
        );
        for (const v of vals) {
          html = html.replace(new RegExp(escRe(esc(v)), "g"), (m) => `<mark class="cf-fill">${m}</mark>`);
        }
        html = html.replace(/\[[^\]\n]{1,60}\]/g, (m) => `<mark class="cf-ph">${m}</mark>`);
        prev.innerHTML = html;
        for (const t of [...res.replaced.map((r) => r.token), ...res.unresolved]) {
          if (isTemplateToken(t.replace(/^\[|\]$/g, ""))) continue;
          if (!seenTokens.has(key(t))) seenTokens.set(key(t), t);
        }
        renderExtra();
        summary.innerHTML = "";
        if (res.replaced.length) {
          const ok = document.createElement("div");
          ok.className = "afc-note";
          ok.textContent = "Filled: " + res.replaced.map((r) => `${r.token} \u2192 ${r.value}`).join(", ");
          summary.appendChild(ok);
        }
        if (res.unresolved.length) {
          const warn = document.createElement("div");
          warn.className = "afc-note afc-note--fine";
          warn.textContent = `Still unfilled: ${res.unresolved.join(", ")}. Fill them above, or leave them and edit in Word.`;
          summary.appendChild(warn);
        }
        if (dbgCb.checked) {
          const ckey = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
          dbgOut.textContent = "custom sent (key = value):\n" + (custom.length ? custom.map((c) => `  ${ckey(c.token)} = ${JSON.stringify(c.value)}`).join("\n") : "  (none)") + "\n\nreplaced: " + (res.replaced.map((r) => r.token).join(", ") || "(none)") + "\n\nstill unresolved (token \u2192 key): " + (res.unresolved.map((t) => `${t}\u2192${ckey(t)}`).join(", ") || "(none)");
          dbgOut.hidden = false;
        }
      } catch (e) {
        summary.textContent = "Couldn't fill this file: " + (e instanceof Error ? e.message : String(e));
      } finally {
        updateBtn.disabled = false;
      }
    };
    const setSource = (fileName, buf) => {
      bytes = buf;
      sourceName = fileName;
      srcLabel.textContent = "Filling: " + fileName;
      seenTokens.clear();
      renderedKeys.clear();
      extra.innerHTML = "";
      void apply();
    };
    picker.addEventListener("change", async () => {
      const f = picker.files?.[0];
      if (!f) return;
      if (!/\.docx$/i.test(f.name)) {
        srcLabel.textContent = "That's not a .docx \u2014 pick a Word .docx file.";
        return;
      }
      setSource(f.name, await f.arrayBuffer());
      picker.value = "";
    });
    updateBtn.addEventListener("click", () => void apply());
    const dbgCb = body.querySelector(".cf-dbg-cb");
    const dbgOut = body.querySelector(".cf-debug-out");
    try {
      if (localStorage.getItem("af-debug") === "1") {
        body.querySelector(".cf-dbg").style.display = "flex";
      }
    } catch {
    }
    const defVal = (cfkey) => (seenTokens.get(cfkey) || `[${cfkey}]`).replace(/^\[|\]$/g, "");
    dbgCb.addEventListener("change", () => {
      for (const inp of extra.querySelectorAll("input[data-cfkey]")) {
        const d = defVal(inp.dataset.cfkey);
        if (dbgCb.checked && !inp.value.trim()) inp.value = d;
        else if (!dbgCb.checked && inp.value === d) inp.value = "";
        perApp.set(inp.dataset.cfkey, inp.value);
      }
      dbgOut.hidden = !dbgCb.checked;
      savePerApp2();
      void apply();
    });
    const filledFileName = () => {
      const base = sourceName.replace(/\.docx$/i, "") || "Cover_Letter";
      const tag = companyIn.value.trim().replace(/[^\w-]+/g, "_").replace(/^_+|_+$/g, "");
      return tag ? `${tag}_${base}.docx` : `${base}_filled.docx`;
    };
    copyBtn.addEventListener("click", () => void copyText(lastText));
    dlBtn.addEventListener("click", () => {
      if (!lastBlob) return;
      const file = filledFileName();
      const url = URL.createObjectURL(lastBlob);
      const a = document.createElement("a");
      a.href = url;
      a.download = file;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4e3);
    });
    {
      attachBtn.addEventListener("click", async () => {
        if (!lastBlob) return;
        if (lastTemplateGaps.length) {
          summary.style.color = "var(--warn-fg)";
          summary.textContent = `Fill ${lastTemplateGaps.join(", ")} before attaching \u2014 I won't send a cover letter with unreplaced fields. Their boxes are above.`;
          return;
        }
        summary.style.color = "";
        if (!attachCover && !findCoverLetterInput()) {
          summary.textContent = "Saved to this application. There's no cover-letter upload on this page \u2014 when you reach the form, it'll be waiting to attach in one click (or reopen this and attach there).";
          attachBtn.textContent = "Saved for this application \u2713";
          return;
        }
        attachBtn.disabled = true;
        attachBtn.textContent = "Attaching\u2026";
        try {
          const file = new File([lastBlob], filledFileName(), {
            type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          });
          const res = await runAttach(file);
          const done = res.ok && res.confirmed !== false;
          if (done) {
            saveCoverAttached(true);
            document.querySelectorAll("#af-overlay .cover-reminder").forEach((n) => n.remove());
            void clearPendingCoverFill();
          }
          summary.textContent = done ? `\u2713 Attached ${filledFileName()} \u2014 no placeholders remain. This is the version that will be submitted.` : res.ok ? "Attached, but the page didn't confirm it \u2014 check the form's upload box before submitting." : "Couldn't attach it here. Download it and use the form's own upload button.";
          attachBtn.textContent = done ? "Attached \u2713" : "Attach to this application";
          attachBtn.disabled = done;
        } catch (err) {
          summary.textContent = "Couldn't attach it: " + (err instanceof Error ? err.message : String(err));
          attachBtn.textContent = "Attach to this application";
          attachBtn.disabled = false;
        } finally {
          (attachBtn.disabled ? doneBtn : attachBtn).focus();
        }
      });
    }
    if (settings?.dataUrl && /\.docx$/i.test(settings.name || "")) {
      setSource(settings.name, await (await fetch(settings.dataUrl)).arrayBuffer());
    } else {
      srcLabel.textContent = settings?.dataUrl ? "Your saved cover letter is a PDF. Choose a .docx to fill." : "No .docx saved. Choose a .docx cover letter to fill.";
      await apply();
    }
  }
  function expandButton(source, title) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "copy";
    b.textContent = "Expand \u2922";
    b.setAttribute("aria-label", `Open ${title} in a larger editor`);
    b.addEventListener(
      "click",
      () => openEditor({
        title,
        value: source.value,
        onSave: (v) => {
          source.value = v;
          source.dispatchEvent(new Event("input", { bubbles: true }));
        }
      })
    );
    return b;
  }
  var askSeq = 0;
  var NO_ANSWER = "No answer came back \u2014 is your local Ollama running? (Options \u2192 \u201CSet up Ollama\u201D.)";
  var DRAFT_SAFETY = "This is a draft for you to review and copy into your own document. The extension never edits your saved files, and never submits anything, so nothing goes out without your approval.";
  var COVER_LETTER_PROMPT = "Write a complete, professional cover letter for this role in my first-person voice, using ONLY my real experience from my profile. About three short paragraphs: open with specific interest in the company, connect my background to what this role needs, and close briefly. No salutation or signature block, no square-bracket placeholders, and do not just restate the job posting.";
  function askAiBlock(draft, jobText = "", draftCoverLetter, coverFill, scrapeJd, attachCover) {
    const uid = `afai${++askSeq}`;
    const wrap = document.createElement("div");
    wrap.innerHTML = `
    <div class="afai-drafts afc-card afc-card--accent" role="group" aria-label="Saved drafts" hidden style="margin-bottom:12px"></div>
    <div class="afc-title" style="margin-top:14px">Draft answers with AI</div>
    <div class="afc-card">
      <div class="afc-note">Add each application question below, plus the job posting if you have it. \u201CDraft answers\u201D fills any that are still blank \u2014 already-answered ones are left alone; use a question\u2019s Regenerate to redo just that one. Nothing is submitted.</div>
      <div class="afai-qs" role="group" aria-label="Your questions"></div>
      <button type="button" class="afai-add afc-btn afc-btn--secondary afc-btn--sm" style="margin-top:8px">+ Add another question</button>
      <label for="${uid}-jd" class="afc-label">Job description</label>
      <textarea id="${uid}-jd" class="afai-jd afc-textarea" rows="3" placeholder="Paste the job posting to tailor the answers\u2026"></textarea>
      <div class="afc-toolbar" style="margin-top:4px"><button type="button" class="afai-jd-scrape afc-btn afc-btn--secondary afc-btn--sm">Scrape this page</button></div>
      <div class="afc-note afc-note--fine" style="margin-top:2px">Scrape it from the posting page or paste it in \u2014 you decide when, and it's remembered for this application. LinkedIn often hides the full posting behind \u201Cshow more,\u201D so pasting can be more complete.</div>
      <div class="afc-toolbar">
        <button type="button" class="afai-go afc-btn afc-btn--primary">Draft answers</button>
        <button type="button" class="afai-fill afc-btn afc-btn--secondary" hidden title="Fill your saved .docx cover letter's [Company]/[Role] placeholders for this posting, then preview and download a new copy">Fill my cover letter</button>
        <button type="button" class="afai-cl afc-btn afc-btn--secondary" title="Draft a full cover letter from the job posting + your profile, saved below to open and copy">Draft cover letter</button>
        <label class="afc-inline afc-note"><span>Variants</span>
          <select class="afai-cln afc-select" aria-label="How many cover letter variants to draft">
            <option value="1" selected>1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </label>
      </div>
      <div class="afai-status afc-note" role="status" aria-live="polite" style="margin-top:8px;min-height:14px"></div>
      <div class="afc-notice"><span class="afc-notice__icon" aria-hidden="true">\u2713</span><span>Drafts are yours to copy into your cover letter or the application. The extension never edits your saved files, and never submits anything, so nothing goes out without your approval.</span></div>
    </div>`;
    const qs = wrap.querySelector(".afai-qs");
    const addBtn = wrap.querySelector(".afai-add");
    const jd = wrap.querySelector(".afai-jd");
    if (jobText) jd.value = jobText;
    jd.addEventListener("input", () => saveJobText(jd.value));
    const jdScrape = wrap.querySelector(".afai-jd-scrape");
    if (!scrapeJd) jdScrape.style.display = "none";
    jdScrape.addEventListener("click", () => {
      const text2 = (scrapeJd?.() ?? "").trim();
      if (!text2) {
        jdScrape.textContent = "No description found here";
        setTimeout(() => jdScrape.textContent = "Scrape this page", 1800);
        return;
      }
      jd.value = text2;
      saveJobText(text2);
      jdScrape.textContent = "Scraped \u2713";
      setTimeout(() => jdScrape.textContent = "Scrape this page", 1500);
    });
    const go = wrap.querySelector(".afai-go");
    const cl = wrap.querySelector(".afai-cl");
    const clN = wrap.querySelector(".afai-cln");
    const fillBtn = wrap.querySelector(".afai-fill");
    const status = wrap.querySelector(".afai-status");
    const draftsBox = wrap.querySelector(".afai-drafts");
    if (coverFill) {
      void chrome.storage.local.get("coverLetterFile").then((o) => {
        if (o.coverLetterFile?.name) fillBtn.hidden = false;
      });
      fillBtn.addEventListener("click", () => void openCoverFill(coverFill, attachCover));
    }
    const openDraftEditor = (id, title, text2) => openEditor({
      title,
      value: text2,
      note: (title.startsWith("Cover letter") ? "Formatting like line breaks and spacing isn\u2019t kept, so format it in your own document and re-upload. " : "") + DRAFT_SAFETY,
      onSave: (v) => void updateDraft(id, v).then(() => void refreshDrafts()),
      // Name it right here — on creation (this opens after drafting) or any review.
      onRename: (name) => void renameDraft(id, name).then(() => void refreshDrafts())
    });
    let editingId = null;
    let localBusy = false;
    let staleTimer;
    const refreshDrafts = async () => {
      const [list, job] = await Promise.all([loadDrafts(), getDraftJob()]);
      if (staleTimer) {
        clearTimeout(staleTimer);
        staleTimer = void 0;
      }
      if (job) {
        cl.disabled = true;
        go.disabled = true;
        clN.disabled = true;
        cl.textContent = "Drafting\u2026";
      } else if (!localBusy) {
        cl.disabled = false;
        go.disabled = false;
        clN.disabled = false;
        cl.textContent = "Draft cover letter";
      }
      draftsBox.innerHTML = "";
      draftsBox.hidden = list.length === 0 && !job;
      if (!list.length && !job) return;
      const h = document.createElement("div");
      h.className = "afc-title";
      h.style.marginBottom = "2px";
      h.innerHTML = list.length ? `Saved drafts <span class="afc-count">(${list.length})</span>` : "Saved drafts";
      const note = document.createElement("div");
      note.className = "afc-note afc-note--fine";
      note.style.margin = "0 0 6px";
      note.textContent = "Kept even if you move to another page. Open, rename, copy, or edit.";
      draftsBox.append(h, note);
      if (job) {
        const banner = document.createElement("div");
        banner.className = "afc-row";
        banner.style.cssText = "flex-direction:column;align-items:flex-start;gap:2px";
        banner.setAttribute("role", "status");
        const label = document.createElement("div");
        label.style.cssText = "display:flex;align-items:center;color:var(--text)";
        const n = job.count > 1 ? `${job.count} cover letter variants` : "your cover letter";
        label.innerHTML = `<span class="afc-spin" aria-hidden="true"></span>Drafting ${n}\u2026`;
        const sub = document.createElement("div");
        sub.className = "afc-note afc-note--fine";
        sub.textContent = "This keeps going even if you switch pages \u2014 it'll appear here when ready.";
        banner.append(label, sub);
        draftsBox.appendChild(banner);
        const remaining = JOB_STALE_MS - (Date.now() - job.startedAt) + 500;
        staleTimer = setTimeout(() => void refreshDrafts(), Math.max(1e3, remaining));
      }
      for (const d of list) {
        const row = document.createElement("div");
        row.className = "afc-row";
        const actions = document.createElement("div");
        actions.className = "afc-row__actions";
        if (editingId === d.id) {
          const input = document.createElement("input");
          input.className = "afc-input";
          input.value = d.title;
          input.style.flex = "1";
          input.setAttribute("aria-label", "Draft name");
          const commit = async () => {
            const v = input.value.trim();
            editingId = null;
            if (v && v !== d.title) await renameDraft(d.id, v);
            await refreshDrafts();
          };
          const cancel = () => {
            editingId = null;
            void refreshDrafts();
          };
          input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              void commit();
            } else if (e.key === "Escape") {
              e.preventDefault();
              e.stopPropagation();
              cancel();
            }
          });
          const save = document.createElement("button");
          save.type = "button";
          save.className = "afc-btn afc-btn--primary afc-btn--sm";
          save.textContent = "Save";
          save.addEventListener("click", () => void commit());
          const cancelBtn = document.createElement("button");
          cancelBtn.type = "button";
          cancelBtn.className = "afc-btn afc-btn--ghost afc-btn--sm";
          cancelBtn.textContent = "Cancel";
          cancelBtn.addEventListener("click", cancel);
          actions.append(save, cancelBtn);
          row.append(input, actions);
        } else {
          const title = document.createElement("span");
          title.className = "afc-row__title";
          title.textContent = d.title;
          title.title = d.title;
          const open = document.createElement("button");
          open.type = "button";
          open.className = "afc-btn afc-btn--primary afc-btn--sm";
          open.textContent = "Open";
          open.setAttribute("aria-label", `Open saved draft: ${d.title}`);
          open.addEventListener("click", () => openDraftEditor(d.id, d.title, d.text));
          const rename = document.createElement("button");
          rename.type = "button";
          rename.className = "afc-btn afc-btn--ghost afc-btn--sm";
          rename.textContent = "Rename";
          rename.setAttribute("aria-label", `Rename saved draft: ${d.title}`);
          rename.addEventListener("click", () => {
            editingId = d.id;
            void refreshDrafts();
          });
          const del = document.createElement("button");
          del.type = "button";
          del.className = "afc-btn afc-btn--ghost afc-btn--sm";
          del.textContent = "Remove";
          del.setAttribute("aria-label", `Remove saved draft: ${d.title}`);
          del.addEventListener("click", () => void removeDraft(d.id).then(() => void refreshDrafts()));
          actions.append(open, rename, del);
          row.append(title, actions);
        }
        draftsBox.appendChild(row);
      }
      if (editingId) {
        const input = draftsBox.querySelector("input.afc-input");
        input?.focus();
        input?.select();
      }
    };
    void refreshDrafts();
    const onStorage = (changes, area) => {
      if (area !== "local") return;
      if (!("drafts" in changes) && !("draftJob" in changes)) return;
      if (!draftsBox.isConnected) {
        chrome.storage.onChanged.removeListener(onStorage);
        return;
      }
      void refreshDrafts();
    };
    chrome.storage.onChanged.addListener(onStorage);
    const CL_ANGLES = [
      "",
      "Give this version a warmer, more personal tone.",
      "Make this version more concise and direct, cutting any filler."
    ];
    cl.addEventListener("click", async () => {
      const count = Math.max(1, Math.min(3, Number(clN.value) || 1));
      localBusy = true;
      cl.disabled = true;
      go.disabled = true;
      clN.disabled = true;
      cl.textContent = count > 1 ? `Drafting ${count}\u2026` : "Drafting\u2026";
      status.textContent = count > 1 ? `Drafting ${count} cover letter variants\u2026` : "Drafting your cover letter\u2026";
      try {
        const prompts = Array.from(
          { length: count },
          (_, i) => CL_ANGLES[i] ? `${COVER_LETTER_PROMPT} ${CL_ANGLES[i]}` : COVER_LETTER_PROMPT
        );
        let drafts;
        if (draftCoverLetter) {
          drafts = await draftCoverLetter(prompts, jd.value.trim());
        } else {
          const texts = await draft(prompts, jd.value.trim());
          drafts = [];
          for (const t of texts) if (t) drafts.push(await saveVariant("Cover letter", t));
        }
        if (drafts.length) {
          openDraftEditor(drafts[0].id, drafts[0].title, drafts[0].text);
          status.textContent = drafts.length > 1 ? `${drafts.length} variants saved under \u201CSaved drafts\u201D \u2014 open each and pick the best.` : "Saved under \u201CSaved drafts\u201D \u2014 reopen it any time, even on another page.";
        } else {
          status.textContent = NO_ANSWER;
        }
      } catch (e) {
        status.textContent = "Couldn't reach the AI: " + (e instanceof Error ? e.message : String(e));
      } finally {
        localBusy = false;
        await refreshDrafts();
      }
    });
    const stateOf = /* @__PURE__ */ new WeakMap();
    const allRows = () => [...qs.querySelectorAll(".afai-row")];
    const renumber = () => {
      const rows = allRows();
      rows.forEach((row, i) => {
        row.querySelector(".afai-qlabel").textContent = `Question ${i + 1}`;
        const rm = row.querySelector(".afai-rm");
        rm.setAttribute("aria-label", `Remove question ${i + 1}`);
        rm.style.display = rows.length > 1 ? "" : "none";
      });
    };
    const draftRows = async (rows) => {
      const jobs = rows.map((row) => ({ s: stateOf.get(row), question: stateOf.get(row).q.value.trim() })).filter((j) => j.question);
      if (!jobs.length) return;
      go.disabled = true;
      go.textContent = "Drafting\u2026";
      status.textContent = `Drafting ${jobs.length} answer${jobs.length > 1 ? "s" : ""}\u2026`;
      jobs.forEach((j) => {
        j.s.ansWrap.hidden = false;
        j.s.ans.value = "";
        j.s.ans.placeholder = "Thinking\u2026";
      });
      try {
        const answers = await draft(
          jobs.map((j) => j.question),
          jd.value.trim()
        );
        jobs.forEach((j, i) => {
          const a = answers[i] || NO_ANSWER;
          j.s.ans.value = a;
          j.s.ans.rows = Math.min(10, Math.max(4, Math.ceil((a.length || 40) / 55)));
          j.s.answeredFor = j.question;
        });
        for (let i = 0; i < jobs.length; i++) {
          if (answers[i]) await saveDraft(jobs[i].question.slice(0, 70), answers[i]);
        }
        await refreshDrafts();
        status.textContent = `${jobs.length} answer${jobs.length > 1 ? "s" : ""} ready \u2014 copy each into the form.`;
      } catch (e) {
        status.textContent = "Couldn't reach the AI: " + (e instanceof Error ? e.message : String(e));
      } finally {
        go.disabled = false;
        go.textContent = "Draft answers";
      }
    };
    let qn = 0;
    const addQuestion = (focus) => {
      const n = ++qn;
      const qid = `${uid}-q${n}`;
      const aid = `${uid}-a${n}`;
      const row = document.createElement("div");
      row.className = "afai-row";
      row.style.cssText = "margin-top:10px";
      const qlabel = document.createElement("label");
      qlabel.className = "afai-qlabel afc-label";
      qlabel.htmlFor = qid;
      const q = document.createElement("textarea");
      q.id = qid;
      q.className = "afai-q afc-textarea";
      q.rows = 2;
      q.placeholder = "Paste an application question\u2026";
      const rm = document.createElement("button");
      rm.type = "button";
      rm.className = "afai-rm afc-btn afc-btn--ghost afc-btn--sm";
      rm.textContent = "Remove";
      rm.style.marginTop = "6px";
      rm.addEventListener("click", () => {
        const rows = allRows();
        const idx = rows.indexOf(row);
        row.remove();
        renumber();
        const left = qs.querySelectorAll(".afai-q");
        (left[Math.max(0, idx - 1)] ?? addBtn).focus();
      });
      const ansWrap = document.createElement("div");
      ansWrap.hidden = true;
      const alabel = document.createElement("label");
      alabel.htmlFor = aid;
      alabel.className = "afc-label";
      alabel.textContent = "Answer";
      const ans = document.createElement("textarea");
      ans.id = aid;
      ans.rows = 5;
      ans.className = "afc-textarea";
      const btns = document.createElement("div");
      btns.style.cssText = "display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:6px";
      const regen = document.createElement("button");
      regen.type = "button";
      regen.textContent = "Regenerate";
      regen.setAttribute("aria-label", "Regenerate this answer");
      regen.className = "afc-btn afc-btn--secondary afc-btn--sm";
      regen.addEventListener("click", () => void draftRows([row]));
      const copy = copyButton(() => ans.value);
      copy.setAttribute("aria-label", "Copy this answer");
      const expand = expandButton(ans, "Answer");
      btns.append(regen, copy, expand);
      ansWrap.append(alabel, ans, btns);
      q.addEventListener("input", () => {
        const s = stateOf.get(row);
        if (s.answeredFor !== null && q.value.trim() !== s.answeredFor) s.answeredFor = null;
      });
      row.append(qlabel, q, rm, ansWrap);
      stateOf.set(row, { q, ansWrap, ans, answeredFor: null });
      qs.appendChild(row);
      renumber();
      if (focus) q.focus();
    };
    addQuestion(false);
    addBtn.addEventListener("click", () => addQuestion(true));
    go.addEventListener("click", () => {
      const rows = allRows();
      const withQ = rows.filter((r) => stateOf.get(r).q.value.trim());
      if (!withQ.length) {
        status.textContent = "Add a question first.";
        stateOf.get(rows[0])?.q.focus();
        return;
      }
      const todo = withQ.filter((r) => {
        const s = stateOf.get(r);
        return s.answeredFor !== s.q.value.trim();
      });
      if (!todo.length) {
        status.textContent = "All questions already have answers \u2014 edit a question or use its Regenerate.";
        return;
      }
      void draftRows(todo);
    });
    return wrap;
  }
  function trackBlock(capture) {
    const wrap = document.createElement("div");
    wrap.innerHTML = `
    <div class="afc-title" style="margin-top:14px">Log this application</div>
    <div class="afc-card">
      <div class="afc-note">Autofill couldn't fill this form, but once you've applied by hand you can still record it here \u2014 saved in this browser, and synced to your Notion if you set it up.</div>
      <label for="tkd-company" class="afc-label">Company</label>
      <input id="tkd-company" class="tkd-company afc-input" value="${esc(capture.company)}" placeholder="Company">
      <label for="tkd-role" class="afc-label">Role</label>
      <input id="tkd-role" class="tkd-role afc-input" value="${esc(capture.role)}" placeholder="Role / title">
      <button type="button" class="tkd-save afc-btn afc-btn--primary" style="margin-top:10px">Log application</button>
      <div class="tkd-note afc-note" role="status" aria-live="polite" style="margin-top:8px;min-height:14px"></div>
    </div>`;
    const company = wrap.querySelector(".tkd-company");
    const role = wrap.querySelector(".tkd-role");
    const save = wrap.querySelector(".tkd-save");
    const note = wrap.querySelector(".tkd-note");
    company.addEventListener("input", () => saveConfirmedCompany(company.value));
    role.addEventListener("input", () => saveConfirmedRole(role.value));
    save.addEventListener("click", async () => {
      save.disabled = true;
      save.textContent = "Saving\u2026";
      const input = {
        company: company.value,
        role: role.value,
        url: capture.url,
        board: capture.board
      };
      try {
        const res = await chrome.runtime.sendMessage({ type: "track:save", input });
        if (res?.error) throw new Error(res.error);
        const n = res?.notion;
        const warn = n && !n.ok && n.error !== "Notion off";
        note.style.color = warn ? "var(--warn-fg)" : "var(--ok-fg)";
        note.textContent = (warn ? "\u26A0 " : "\u2713 ") + (n?.ok ? "Saved locally + synced to Notion." : n?.error === "Notion off" ? "Saved locally. (Turn on Notion in Options to sync.)" : `Saved locally. Notion sync failed: ${n?.error ?? "unknown"}`);
        save.textContent = "Logged \u2713";
      } catch (e) {
        note.style.color = "var(--danger-fg)";
        note.textContent = "\u2715 Could not save: " + (e instanceof Error ? e.message : String(e));
        save.disabled = false;
        save.textContent = "Log application";
      }
    });
    return wrap;
  }
  function makeDraggable(root, handle) {
    handle.style.cursor = "move";
    handle.style.touchAction = "none";
    handle.title = "Drag to move";
    let dragging = false;
    let startX = 0;
    let startY = 0;
    let baseLeft = 0;
    let baseTop = 0;
    handle.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button, a, input, select, textarea")) return;
      const rect = root.getBoundingClientRect();
      baseLeft = rect.left;
      baseTop = rect.top;
      root.style.left = `${baseLeft}px`;
      root.style.top = `${baseTop}px`;
      root.style.right = "auto";
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    handle.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const w = root.offsetWidth;
      const h = root.offsetHeight;
      const nx = Math.max(4, Math.min(baseLeft + (e.clientX - startX), window.innerWidth - w - 4));
      const ny = Math.max(4, Math.min(baseTop + (e.clientY - startY), window.innerHeight - h - 4));
      root.style.left = `${nx}px`;
      root.style.top = `${ny}px`;
    });
    const end = (e) => {
      if (!dragging) return;
      dragging = false;
      try {
        handle.releasePointerCapture(e.pointerId);
      } catch {
      }
    };
    handle.addEventListener("pointerup", end);
    handle.addEventListener("pointercancel", end);
  }
  function renderMisses(row, misses) {
    row.querySelector(".af-misses")?.remove();
    const box = document.createElement("div");
    box.className = "af-misses";
    box.style.cssText = "margin-top:8px;border-top:1px solid #eee;padding-top:6px";
    const head = document.createElement("div");
    head.className = "why";
    head.textContent = `${misses.length} to add by hand \u2014 copy, paste into the Skills box, pick the match:`;
    box.appendChild(head);
    misses.forEach((m) => {
      const query = m.q || m.label || "";
      const line = document.createElement("div");
      line.style.cssText = "display:flex;align-items:center;gap:6px;margin-top:4px";
      const txt2 = document.createElement("span");
      txt2.style.cssText = "flex:1;font-size:12px";
      txt2.textContent = m.label && m.label !== query ? `${query}  \u2192  pick "${m.label}"` : query;
      const cbtn = document.createElement("button");
      cbtn.className = "btn";
      cbtn.style.cssText = "font-size:11px;padding:3px 9px;margin-top:0";
      cbtn.textContent = "Copy";
      cbtn.addEventListener("click", async () => {
        const ok = await copyText(query);
        cbtn.textContent = ok ? "Copied" : "!";
        setTimeout(() => cbtn.textContent = "Copy", 1200);
      });
      line.append(txt2, cbtn);
      box.appendChild(line);
    });
    row.appendChild(box);
  }
  function setAdapterStatus(why, res) {
    const confirmed = res.confirmed !== false;
    const icon = !res.ok ? "\u2717" : confirmed ? "\u2713" : "\u26A0";
    const color = !res.ok ? "var(--danger-fg)" : confirmed ? "var(--ok-fg)" : "var(--warn-fg)";
    why.textContent = `${icon} ${res.note}`;
    why.style.color = color;
    why.style.fontWeight = "600";
  }
  function render(plan, ctx) {
    ensureComponentStyles();
    const board = ctx.board;
    document.getElementById("af-overlay")?.remove();
    document.getElementById("af-data")?.remove();
    const fills = plan.entries.filter((e) => e.decision === "fill");
    const reviews = plan.entries.filter((e) => e.decision === "review");
    const skips = plan.entries.filter((e) => e.decision === "skip");
    const pending = [];
    const root = document.createElement("div");
    root.id = "af-overlay";
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-label", "Autofill review");
    root.innerHTML = `
    <style>
      /* Brand palette + tokens, mirroring the options page. Light by default,
         dark via the OS setting (a content-script overlay can't read the options
         page's manual toggle, so it follows the system). Button/accent colors are
         chosen for >=4.5:1 contrast; status is never signalled by color alone. */
      #af-overlay {
        --bg: #fff; --surface: #f6f8fc; --card: #fff; --text: #14161c; --muted: #55606f;
        --border: #d7dce5; --brand: #155dfc; --grad: linear-gradient(90deg, #155dfc, #0ea5a4);
        --ok: #15803d; --ok-fg: #15803d; --danger-fg: #b91c1c; --warn-fg: #8a5300;
        --hover-ring: rgba(15,23,43,.42);
        position: fixed; top: 16px; right: 16px; width: 380px; max-height: 88vh; overflow: auto;
        z-index: 2147483647; background: var(--bg); color: var(--text);
        border: 1px solid var(--border); border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,.25); font: 13px/1.45 -apple-system, Segoe UI, sans-serif; }
      @media (prefers-color-scheme: dark) {
        #af-overlay {
          --bg: #16213c; --surface: #111b33; --card: #1b2946; --text: #e8edf6; --muted: #a6b6cd;
          --border: #2c3d60; --brand: #2563eb; --grad: linear-gradient(90deg, #4b8bff, #2dd4bf);
          --ok: #15803d; --ok-fg: #5bd88a; --danger-fg: #fca5a5; --warn-fg: #fbbf24;
          --hover-ring: rgba(255,255,255,.6); } }
      /* Defend against host-page CSS bleeding in. Some boards (e.g. Ashby/Flock)
         set a global line-height of 0 that our child elements would otherwise
         inherit-lose, collapsing every row to 0 height so text overlaps illegibly.
         The #af-overlay id specificity keeps these from being overridden. */
      #af-overlay, #af-overlay * { line-height: 1.45; text-shadow: none; letter-spacing: normal;
        text-transform: none; }
      #af-overlay header { position: sticky; top: 0; z-index: 1; background: var(--surface); color: var(--text);
        padding: 11px 12px; border-bottom: 1px solid var(--border); border-radius: 12px 12px 0 0;
        display: flex; justify-content: space-between; align-items: center; gap: 8px; }
      #af-overlay .brand { display: flex; align-items: center; gap: 9px; min-width: 0; }
      #af-overlay .logo { width: 26px; height: 26px; border-radius: 7px; background: var(--grad); color: #fff;
        display: grid; place-items: center; font-weight: 800; font-size: 12px; flex: 0 0 auto; }
      #af-overlay header b { font-size: 14px; }
      #af-overlay .sub { font-size: 11px; color: var(--muted); }
      #af-overlay .body { padding: 10px 12px; }
      #af-overlay .sec { font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); margin: 12px 0 6px; }
      #af-overlay .row { border: 1px solid var(--border); border-radius: 8px; padding: 8px; margin-bottom: 6px; background: var(--card); }
      #af-overlay .lab { font-weight: 600; }
      #af-overlay .why { color: var(--muted); font-size: 11px; margin-top: 2px; }
      #af-overlay .val { color: var(--text); margin-top: 2px; word-break: break-word; }
      #af-overlay input.rv, #af-overlay textarea.rv-ta, #af-overlay .tk-in {
        width: 100%; margin-top: 6px; padding: 6px 8px; border: 1px solid var(--border); border-radius: 6px;
        font: inherit; background: var(--bg); color: var(--text); box-sizing: border-box; }
      #af-overlay textarea.rv-ta { font-size: 12px; resize: vertical; white-space: pre-wrap; overflow-wrap: anywhere; }
      /* Buttons: shared base + clearly identifiable hover / active / disabled states. */
      #af-overlay .btn, #af-overlay .copy, #af-overlay .rescan, #af-overlay .opt {
        cursor: pointer; transition: background .12s, color .12s, border-color .12s, transform .06s; }
      /* Transparent border reserved so the hover border doesn't shift layout. */
      #af-overlay .btn { border: 1px solid transparent; border-radius: 8px; padding: 8px 12px; font-weight: 600; color: #fff; background: var(--brand); }
      /* Hover = invert: filled buttons become outlined (light card + brand text/
         border); the light bordered buttons fill in. A big, obvious swap in both themes. */
      #af-overlay .btn:hover { background: var(--card); color: var(--brand); border-color: var(--brand); transform: translateY(-1px); }
      #af-overlay .apply-all:hover, #af-overlay .rv-fill:hover { color: var(--ok); border-color: var(--ok); }
      #af-overlay .copy:hover, #af-overlay .rescan:hover, #af-overlay .opt:hover {
        background: var(--brand); color: #fff; border-color: var(--brand); transform: translateY(-1px); }
      #af-overlay .btn:active, #af-overlay .copy:active, #af-overlay .rescan:active, #af-overlay .opt:active {
        transform: translateY(1px); }
      #af-overlay .btn:disabled, #af-overlay .btn[disabled], #af-overlay .opt:disabled {
        opacity: .5; cursor: not-allowed; filter: grayscale(.25); box-shadow: none; transform: none; }
      #af-overlay :focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
      #af-overlay .fill-all { width: 100%; margin: 0 0 6px; }
      #af-overlay .apply-all { background: var(--ok); width: 100%; margin: 6px 0 2px; }
      #af-overlay .rv-fill { background: var(--ok); margin-top: 6px; padding: 6px 12px; }
      /* A leading check marks the green "apply" actions so green isn't the only cue. */
      #af-overlay .apply-all::before, #af-overlay .rv-fill::before { content: "\\2713\\00a0"; }
      /* "Needs your check" rows call for attention without relying on color alone:
         a warm left accent bar + a pencil glyph on the label + a faint tint, plus a
         brief pulse when the row appears (or when its answer lands). */
      #af-overlay .row.needs { border-left: 3px solid var(--warn-fg);
        background: color-mix(in srgb, var(--warn-fg) 9%, var(--card));
        animation: af-attn 1.1s ease-out 2; }
      #af-overlay .row.needs .lab::before { content: "\\270E\\00a0"; color: var(--warn-fg); font-weight: 700; }
      @keyframes af-attn {
        0% { box-shadow: 0 0 0 0 color-mix(in srgb, var(--warn-fg) 55%, transparent); }
        70% { box-shadow: 0 0 0 7px transparent; }
        100% { box-shadow: 0 0 0 0 transparent; } }
      @media (prefers-reduced-motion: reduce) { #af-overlay .row.needs { animation: none; } }
      #af-overlay .track { background: var(--card); color: var(--text); border: 1px solid var(--border); width: 100%; margin-top: 8px; }
      #af-overlay .close { background: transparent; color: var(--muted); border: 0; font-size: 18px; cursor: pointer; padding: 0 4px; }
      #af-overlay .close:hover { color: var(--text); }
      #af-overlay .rescan, #af-overlay .reset-job { background: var(--card); color: var(--text); border: 1px solid var(--border); border-radius: 6px;
        padding: 4px 8px; font: inherit; font-size: 11px; margin-right: 6px; cursor: pointer; }
      #af-overlay .reset-job:hover { background: var(--warn-fg); color: #fff; border-color: var(--warn-fg); }
      #af-overlay .pill { display: inline-block; font-size: 10px; padding: 1px 7px; border-radius: 10px;
        background: var(--surface); color: var(--text); border: 1px solid var(--border); margin-left: 6px; }
      #af-overlay .copy { background: var(--surface); color: var(--text); border: 1px solid var(--border); border-radius: 6px;
        font-size: 11px; font-weight: 600; padding: 3px 10px; margin-top: 6px; }
      #af-overlay .tk-lab { font-size: 11px; color: var(--muted); margin-top: 6px; }
      #af-overlay .tk-note { font-size: 11px; margin-top: 6px; }
      #af-overlay .opts { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
      #af-overlay .opt { border: 1px solid var(--border); background: var(--surface); color: var(--text); border-radius: 999px;
        padding: 5px 11px; font: inherit; font-size: 12px; }
      #af-overlay .opt.sel { background: var(--brand); color: #fff; border-color: var(--brand); }
      #af-overlay .opt.sel::before { content: "\\2713\\00a0"; }
      #af-overlay .spin { display: inline-block; width: 10px; height: 10px; border: 2px solid var(--border);
        border-top-color: var(--brand); border-radius: 50%; animation: af-spin .7s linear infinite;
        vertical-align: -1px; margin-right: 6px; }
      @keyframes af-spin { to { transform: rotate(360deg); } }
      @media (prefers-reduced-motion: reduce) { #af-overlay * { transition: none !important; animation: none !important; } }
      #af-overlay .grip { cursor: move; font-size: 16px; color: var(--muted); letter-spacing: -3px; }
    </style>
    <header>
      <div class="brand">
        <span class="grip" aria-hidden="true">\u283F</span>
        <span class="logo" aria-hidden="true">CG</span>
        <div style="min-width:0"><b>Autofill review</b><div class="sub">${board} \xB7 ${plan.summary.fill} to fill \xB7 ${plan.summary.review} to check \xB7 drag to move</div></div>
      </div>
      <div style="flex:0 0 auto">
        <button class="dbg" title="Copy a debug report (what was scanned and decided)" style="background:var(--card);color:var(--muted);border:1px solid var(--border);border-radius:6px;padding:4px 8px;font:inherit;font-size:11px;margin-right:6px;cursor:pointer">Debug</button>
        <button class="reset-job" title="Clear this application's saved company, role, job description and placeholders, then re-scan fresh. Your profile and saved documents are kept.">Reset job</button>
        <button class="rescan" title="Re-scan this page">Re-scan</button>
        <button class="close" title="Close (Esc)">\xD7</button>
      </div>
    </header>
    <div class="body">
      <button class="btn fill-all" title="Runs every fill, dropdown, and section on this step in order">Fill everything on this step</button>
      <button class="btn apply-all">Apply ${fills.length} high-confidence fill${fills.length === 1 ? "" : "s"} (Enter)</button>
      <div class="sec" ${fills.length ? "" : 'style="display:none"'}>Will fill</div>
      <div id="af-fills"></div>
      <div class="sec" ${reviews.length ? "" : 'style="display:none"'}>Needs your check</div>
      <div id="af-reviews"></div>
      <div id="af-jd"></div>
      <div class="sec" ${skips.length ? "" : 'style="display:none"'}>Skipped (nothing written)</div>
      <div id="af-skips"></div>
      <div class="sec" id="af-sections-head" style="display:none">Sections</div>
      <div id="af-sections"></div>
      <div class="sec" id="af-track-head" style="display:none">Track this application</div>
      <div id="af-track"></div>
      <div class="why" style="margin-top:10px">Nothing is submitted. EEO and voluntary disclosures are never touched.</div>
    </div>`;
    document.body.appendChild(root);
    applyThemeAttr(root);
    const $ = (sel) => root.querySelector(sel);
    const fillsBox = $("#af-fills");
    fills.forEach((e) => {
      const d = document.createElement("div");
      d.className = "row";
      d.innerHTML = `<div class="lab">${esc(e.field.label || e.field.automationId || "(field)")}<span class="pill">${esc(sourceBadge(e))}</span></div>
      <div class="val">${esc(e.value.replace(/\n/g, ", "))}</div><div class="why">${esc(e.reason)}</div>`;
      d.appendChild(copyButton(() => e.value.replace(/\n/g, ", ")));
      fillsBox.appendChild(d);
    });
    const revBox = $("#af-reviews");
    function buildReviewRow(e) {
      const d = document.createElement("div");
      d.className = e.pending ? "row" : "row needs";
      d.id = `af-rv-${e.idx}`;
      const pill = e.pending ? "" : `<span class="pill">${esc(sourceBadge(e))} \xB7 ${Math.round(e.confidence * 100)}%</span>`;
      d.innerHTML = `<div class="lab">${esc(e.field.label || e.field.automationId || "(field)")}${pill}</div>
      <div class="why"></div>`;
      const why = d.querySelector(".why");
      if (e.pending) {
        why.innerHTML = `<span class="spin"></span>thinking\u2026`;
        return d;
      }
      why.textContent = e.reason;
      if (e.tier === "adapter") {
        if (e.value) {
          const rec = document.createElement("div");
          rec.className = "val";
          rec.textContent = e.value;
          d.append(rec, copyButton(() => e.value));
        }
        return d;
      }
      const opts = e.field.options;
      if (opts && opts.length) {
        const wrap = document.createElement("div");
        wrap.className = "opts";
        wrap.setAttribute("role", "group");
        wrap.setAttribute("aria-label", e.field.label || "Choose an option");
        const norm = (s) => s.trim().toLowerCase();
        const boolMap = { true: "yes", false: "no", "1": "yes", "0": "no" };
        const findOpt = (raw) => {
          const v = norm(raw);
          return opts.find((o) => norm(o.label) === v) ?? opts.find((o) => norm(o.label) === boolMap[v]);
        };
        const selected = /* @__PURE__ */ new Set();
        for (const s of [
          ...e.field.multi ? e.value.split("\n") : [e.value],
          ...String(e.field.currentValue || "").split("\n")
        ]) {
          const o = findOpt(s);
          if (o) selected.add(o.label);
        }
        opts.forEach((o) => {
          const b = document.createElement("button");
          b.className = "opt" + (selected.has(o.label) ? " sel" : "");
          b.type = "button";
          b.textContent = o.label;
          b.setAttribute("aria-label", e.field.label ? `${e.field.label}: ${o.label}` : o.label);
          b.setAttribute("aria-pressed", String(selected.has(o.label)));
          b.addEventListener("click", () => {
            if (e.field.multi) {
              const on = !selected.has(o.label);
              if (on) selected.add(o.label);
              else selected.delete(o.label);
              b.classList.toggle("sel", on);
              b.setAttribute("aria-pressed", String(on));
              const res = applyEntry(e, [...selected].join("\n"), board);
              why.textContent = res.ok ? `checked ${selected.size}` : "didn't apply: " + res.note;
            } else {
              selected.clear();
              selected.add(o.label);
              wrap.querySelectorAll(".opt").forEach((x) => {
                x.classList.remove("sel");
                x.setAttribute("aria-pressed", "false");
              });
              b.classList.add("sel");
              b.setAttribute("aria-pressed", "true");
              const res = applyEntry(e, o.label, board);
              why.textContent = res.ok ? `selected "${o.label}"` : "didn't select: " + res.note;
            }
          });
          wrap.appendChild(b);
        });
        d.appendChild(wrap);
      } else if (e.field.type === "textarea" || e.tier === 3 || e.value.length > 80) {
        const ta = document.createElement("textarea");
        ta.className = "rv-ta";
        ta.value = e.value;
        ta.rows = Math.min(12, Math.max(3, Math.ceil((e.value.length || 40) / 44)));
        ta.placeholder = "Edit the answer, then Fill";
        const fill = document.createElement("button");
        fill.className = "btn rv-fill";
        fill.type = "button";
        fill.textContent = "Fill";
        fill.addEventListener("click", () => {
          const res = applyEntry(e, ta.value, board);
          why.textContent = res.ok ? "filled" : "did not fill: " + res.note;
        });
        d.append(
          ta,
          fill,
          copyButton(() => ta.value),
          expandButton(ta, e.field.label || "Answer")
        );
      } else {
        const input = document.createElement("input");
        input.className = "rv";
        input.value = e.value;
        input.placeholder = "Type a value, Enter to fill";
        input.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter") {
            ev.preventDefault();
            const res = applyEntry(e, input.value, board);
            why.textContent = res.ok ? "filled" : "did not fill: " + res.note;
          }
        });
        d.appendChild(input);
        d.appendChild(copyButton(() => input.value));
      }
      return d;
    }
    reviews.forEach((e) => revBox.appendChild(buildReviewRow(e)));
    const update = (e) => {
      root.querySelector(`#af-rv-${e.idx}`)?.replaceWith(buildReviewRow(e));
    };
    const hasEssays = plan.entries.some((e) => e.pending || e.source === "ai");
    if (ctx.regenerate && hasEssays) {
      const jd = $("#af-jd");
      jd.innerHTML = `<div class="sec">Tailor AI answers</div>
      <div class="row">
        <div class="why">Give the AI this job's description so answers aren't generic. Scrape it from the posting page, or paste it in \u2014 your choice, and it's remembered for this application.</div>
        <textarea class="rv-ta" placeholder="Paste the job description / application copy\u2026"></textarea>
        <div class="af-jd-tools" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
          <button class="btn af-jd-scrape" type="button">Scrape this page</button>
          <button class="btn af-jd-go" type="button">Regenerate answers</button>
        </div>
      </div>`;
      const ta = jd.querySelector("textarea");
      const go = jd.querySelector(".af-jd-go");
      const scrapeBtn = jd.querySelector(".af-jd-scrape");
      if (ctx.jobText) ta.value = ctx.jobText;
      ta.addEventListener("input", () => saveJobText(ta.value));
      if (!ctx.scrapeJd) scrapeBtn.style.display = "none";
      scrapeBtn.addEventListener("click", () => {
        const text2 = (ctx.scrapeJd?.() ?? "").trim();
        if (!text2) {
          scrapeBtn.textContent = "No description found here";
          setTimeout(() => scrapeBtn.textContent = "Scrape this page", 1800);
          return;
        }
        ta.value = text2;
        saveJobText(text2);
        scrapeBtn.textContent = "Scraped \u2713";
        setTimeout(() => scrapeBtn.textContent = "Scrape this page", 1500);
      });
      go.addEventListener("click", () => {
        const text2 = ta.value.trim();
        if (!text2) return;
        saveJobText(text2);
        go.textContent = "Regenerating\u2026";
        ctx.regenerate(text2);
        setTimeout(() => go.textContent = "Regenerate answers", 1500);
      });
    }
    let attachCover;
    if (ctx.adapter) {
      for (const e of plan.entries) {
        if (e.field.type !== "file") continue;
        const h = ctx.adapter.handlerFor(e);
        const hay = `${h?.label ?? ""} ${e.field.label ?? ""}`.toLowerCase();
        if (h?.runWithFile && /cover.?letter|motivation|letter of (?:intent|interest)/.test(hay)) {
          attachCover = h.runWithFile;
          break;
        }
      }
    }
    if (ctx.draft) {
      try {
        $("#af-jd").after(
          askAiBlock(ctx.draft, ctx.jobText, ctx.draftCoverLetter, ctx.coverFill, ctx.scrapeJd, attachCover)
        );
      } catch (err) {
        console.debug("[autofill] ask-ai block failed", err);
      }
    }
    const skipBox = $("#af-skips");
    const adapter = ctx.adapter;
    skips.forEach((e) => {
      try {
        const d = document.createElement("div");
        d.className = "row";
        d.innerHTML = `<div class="lab">${esc(e.field.label || e.field.group || e.field.automationId || "(field)")}</div>
      <div class="why">${esc(e.reason)}</div>`;
        const handler = adapter?.handlerFor(e) ?? null;
        if (handler) {
          const btn = document.createElement("button");
          btn.className = "btn";
          btn.style.cssText = "margin-top:6px";
          btn.textContent = handler.label;
          const why = d.querySelector(".why");
          const runHandler = async () => {
            btn.disabled = true;
            btn.textContent = "Working\u2026";
            try {
              const res = await handler.run();
              setAdapterStatus(why, res);
              if (res.misses && res.misses.length) {
                renderMisses(d, res.misses);
                btn.textContent = handler.label;
                btn.disabled = false;
              } else {
                const done = res.ok && res.confirmed !== false;
                btn.textContent = done ? "Done" : handler.label;
                btn.disabled = done;
              }
            } catch (err) {
              why.textContent = "error: " + (err instanceof Error ? err.message : String(err));
              btn.textContent = handler.label;
              btn.disabled = false;
            }
          };
          btn.addEventListener("click", runHandler);
          if (!handler.manualOnly) pending.push({ label: handler.label, fire: runHandler });
          if (handler.hasDefault) {
            btn.style.display = "none";
            void handler.hasDefault().then((has) => {
              if (has) btn.style.display = "";
            });
          }
          const actions = document.createElement("div");
          actions.className = "afc-btnstack";
          d.appendChild(actions);
          btn.style.cssText = "";
          actions.appendChild(btn);
          if (/cover/i.test(handler.label)) {
            void loadPendingCoverFill().then((pf) => {
              if (!pf || pf.hasTemplateGaps) return;
              const prep = document.createElement("button");
              prep.className = "btn";
              prep.textContent = `Attach prepared cover letter${pf.company ? ` (${pf.company})` : ""}`;
              prep.title = "Attach the cover letter you already filled for this application, with its placeholders swapped.";
              prep.addEventListener("click", async () => {
                prep.disabled = true;
                prep.textContent = "Attaching\u2026";
                const setStatus = (msg, okState) => {
                  why.textContent = msg;
                  why.style.color = okState ? "var(--ok-fg)" : "var(--warn-fg)";
                  why.style.fontWeight = "600";
                };
                try {
                  const cur = await loadPendingCoverFill() ?? pf;
                  const blob = await (await fetch(cur.dataUrl)).blob();
                  const file = new File([blob], cur.name, {
                    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  });
                  const res = handler.runWithFile ? await handler.runWithFile(file) : await attachFileToCoverLetterField(file);
                  const done = res.ok && res.confirmed !== false;
                  if (done) {
                    saveCoverAttached(true);
                    document.querySelectorAll("#af-overlay .cover-reminder").forEach((n) => n.remove());
                    void clearPendingCoverFill();
                  }
                  setStatus(
                    done ? `\u2713 Attached ${cur.name} \u2014 no placeholders remain.` : res.ok ? "Attached, but the page didn't confirm it \u2014 check the upload box." : "Couldn't attach here \u2014 open \u201CFill my cover letter\u201D to try again.",
                    done
                  );
                  prep.textContent = done ? "Attached \u2713" : `Attach prepared cover letter${cur.company ? ` (${cur.company})` : ""}`;
                  prep.disabled = done;
                } catch (err) {
                  setStatus("Couldn't attach it: " + (err instanceof Error ? err.message : String(err)), false);
                  prep.textContent = "Attach prepared cover letter";
                  prep.disabled = false;
                }
              });
              actions.insertBefore(prep, actions.firstChild);
            });
          }
          if (handler.runWithFile) {
            const picker = document.createElement("input");
            picker.type = "file";
            if (handler.accept) picker.accept = handler.accept;
            picker.style.display = "none";
            const choose = document.createElement("button");
            choose.className = "copy";
            choose.type = "button";
            choose.textContent = "Choose file\u2026";
            choose.setAttribute("aria-label", `Choose a file to upload for: ${esc(e.field.label || "this")}`);
            choose.addEventListener("click", () => picker.click());
            picker.addEventListener("change", async () => {
              const file = picker.files?.[0];
              if (!file) return;
              choose.disabled = true;
              choose.textContent = "Attaching\u2026";
              try {
                const res = await handler.runWithFile(file);
                setAdapterStatus(why, res);
                const done = res.ok && res.confirmed !== false;
                choose.textContent = done ? "Attached your file" : "Choose file\u2026";
                choose.disabled = done;
                if (done) btn.disabled = true;
              } catch (err) {
                why.textContent = "error: " + (err instanceof Error ? err.message : String(err));
                choose.textContent = "Choose file\u2026";
                choose.disabled = false;
              }
            });
            actions.appendChild(choose);
            actions.appendChild(picker);
          }
          if (handler.openPagePicker) {
            const openBtn = document.createElement("button");
            openBtn.className = "copy";
            openBtn.type = "button";
            openBtn.textContent = "Open the form's uploader";
            openBtn.title = "Opens the site's own file dialog. Works even when auto-attach can't, because your pick counts as a real selection.";
            openBtn.addEventListener("click", () => {
              const ok = handler.openPagePicker();
              why.textContent = ok ? "\u2713 Opened the site's file picker \u2014 choose your file there." : "\u2717 Couldn't find the upload control on the page.";
              why.style.color = ok ? "var(--ok-fg)" : "var(--danger-fg)";
              why.style.fontWeight = "600";
            });
            actions.appendChild(openBtn);
          }
          if (handler.reminder) {
            void handler.reminder().then((msg) => {
              if (!msg) return;
              const note = document.createElement("div");
              note.className = "why cover-reminder";
              note.textContent = "\u26A0 " + msg;
              note.style.color = "var(--warn-fg)";
              note.style.fontWeight = "600";
              note.style.marginTop = "6px";
              d.appendChild(note);
            });
          }
        }
        skipBox.appendChild(d);
      } catch (err) {
        console.debug("[autofill] skip row failed", err);
      }
    });
    try {
      const sectionActions5 = adapter?.sectionActions() ?? [];
      if (sectionActions5.length) {
        $("#af-sections-head").style.display = "";
        const box = $("#af-sections");
        sectionActions5.forEach((a) => {
          const d = document.createElement("div");
          d.className = "row";
          d.innerHTML = `<div class="lab">${esc(a.label)}</div><div class="why">not run yet</div>`;
          const b = document.createElement("button");
          b.className = "btn";
          b.style.cssText = "margin-top:6px";
          b.textContent = a.label;
          const w = d.querySelector(".why");
          const runSection = async () => {
            b.disabled = true;
            b.textContent = "Working\u2026";
            try {
              const res = await a.run();
              w.textContent = res.note || (res.ok ? "done" : "did not run");
            } catch (err) {
              w.textContent = "error: " + (err instanceof Error ? err.message : String(err));
            }
            b.textContent = a.label;
            b.disabled = false;
          };
          b.addEventListener("click", runSection);
          pending.push({ label: a.label, fire: runSection });
          d.appendChild(b);
          box.appendChild(d);
        });
      }
    } catch (err) {
      console.debug("[autofill] sections failed", err);
    }
    try {
      if (ctx.capture) {
        const cap = ctx.capture;
        $("#af-track-head").style.display = "";
        const box = $("#af-track");
        box.innerHTML = `
      <div class="tk-lab">Company</div>
      <input class="tk-in" id="tk-company" value="${esc(cap.company)}" placeholder="Company">
      <div class="tk-lab">Role</div>
      <input class="tk-in" id="tk-role" value="${esc(cap.role)}" placeholder="Role / title">
      <button class="btn track" id="tk-save">Log application</button>
      <div class="tk-note" id="tk-note"></div>`;
        const note = $("#tk-note");
        $("#tk-company").addEventListener(
          "input",
          (e) => saveConfirmedCompany(e.target.value)
        );
        $("#tk-role").addEventListener(
          "input",
          (e) => saveConfirmedRole(e.target.value)
        );
        $("#tk-save").addEventListener("click", async () => {
          const btn = $("#tk-save");
          btn.disabled = true;
          btn.textContent = "Saving\u2026";
          const input = {
            company: $("#tk-company").value,
            role: $("#tk-role").value,
            url: cap.url,
            board: cap.board
          };
          try {
            const res = await chrome.runtime.sendMessage({ type: "track:save", input });
            if (res?.error) throw new Error(res.error);
            const n = res?.notion;
            const warn = n && !n.ok && n.error !== "Notion off";
            note.style.color = warn ? "var(--warn-fg)" : "var(--ok-fg)";
            note.textContent = (warn ? "\u26A0 " : "\u2713 ") + (n?.ok ? "Saved locally + synced to Notion." : n?.error === "Notion off" ? "Saved locally. (Turn on Notion in Options to sync.)" : `Saved locally. Notion sync failed: ${n?.error ?? "unknown"}`);
            btn.textContent = "Logged \u2713";
          } catch (e) {
            note.style.color = "var(--danger-fg)";
            note.textContent = "\u2715 Could not save: " + (e instanceof Error ? e.message : String(e));
            btn.disabled = false;
            btn.textContent = "Log application";
          }
        });
      }
    } catch (err) {
      console.debug("[autofill] track section failed", err);
    }
    const sleep5 = (ms) => new Promise((r) => setTimeout(r, ms));
    const jitter = () => 90 + Math.floor(Math.random() * 160);
    async function applyAll() {
      let ok = 0;
      let fail = 0;
      for (const e of fills) {
        if (isAborted()) break;
        const res = applyEntry(e, e.value, board);
        if (res.ok) ok++;
        else fail++;
        report(e.field.label || e.field.automationId, res.ok, res.ok ? "" : res.note);
        await sleep5(jitter());
      }
      $(".apply-all").textContent = `Applied ${ok} field${ok === 1 ? "" : "s"}${fail ? `, ${fail} failed` : ""}`;
      flush("autofill");
    }
    async function fillEverything() {
      const fa = $(".fill-all");
      fa.disabled = true;
      await applyAll();
      for (const p of pending) {
        if (isAborted()) break;
        fa.textContent = "Running: " + p.label;
        try {
          await p.fire();
        } catch {
        }
      }
      fa.textContent = isAborted() ? "Stopped (Esc)" : "Done \u2014 review everything before Save";
    }
    const fillAllBtn = $(".fill-all");
    if (pending.length) fillAllBtn.addEventListener("click", fillEverything);
    else fillAllBtn.style.display = "none";
    $(".apply-all").addEventListener("click", () => void applyAll());
    const dbg = root.querySelector(".dbg");
    if (dbg)
      dbg.addEventListener("click", async () => {
        const ok = await copyText(debugReport(plan, board));
        dbg.textContent = ok ? "Copied \u2713" : "Copy failed";
        setTimeout(() => dbg.textContent = "Debug", 1200);
      });
    $(".close").addEventListener("click", () => root.remove());
    {
      const resetBtn = $(".reset-job");
      resetBtn.addEventListener("click", async () => {
        resetBtn.disabled = true;
        resetBtn.innerHTML = `<span class="spin"></span>Clearing\u2026`;
        await clearContext();
        await clearPendingCoverFill();
        if (ctx.rescan) await ctx.rescan();
        if (resetBtn.isConnected) {
          resetBtn.disabled = false;
          resetBtn.textContent = "Reset job";
        }
      });
    }
    if (ctx.rescan) {
      const rb = $(".rescan");
      rb.addEventListener("click", async () => {
        rb.disabled = true;
        rb.innerHTML = `<span class="spin"></span>Scanning\u2026`;
        await ctx.rescan();
        if (rb.isConnected) {
          rb.disabled = false;
          rb.textContent = "Re-scan";
        }
      });
    } else {
      $(".rescan").style.display = "none";
    }
    root.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") root.remove();
      const t = ev.target;
      if (ev.key === "Enter" && !t.classList.contains("rv") && t.tagName !== "TEXTAREA") {
        ev.preventDefault();
        void applyAll();
      }
    });
    const hdr = root.querySelector("header");
    if (hdr) makeDraggable(root, hdr);
    root.tabIndex = -1;
    root.focus();
    return { root, update };
  }
  var PLACEHOLDER2 = /\[[A-Za-z][A-Za-z0-9 _/-]*\]/;
  function profileSections(profile) {
    const id = profile.identity;
    const rows = (entries) => entries.map(([label, v, long]) => ({ label, value: String(v ?? "").trim(), long })).filter((r) => r.value && !PLACEHOLDER2.test(r.value));
    const sections = [];
    const push = (title, rs) => {
      if (rs.length) sections.push({ title, rows: rs });
    };
    push(
      "Contact",
      rows([
        ["Full name", `${id.firstName} ${id.lastName}`.trim()],
        ["First name", id.firstName],
        ["Last name", id.lastName],
        ["Email", id.email],
        ["Phone", id.phone],
        ["Address", [id.address1, id.address2].filter(Boolean).join(", ")],
        ["City", id.city],
        ["State", id.state],
        ["Postal", id.postal],
        ["Country", id.country],
        ["Work authorized", id.workAuthorized],
        ["Needs sponsorship", id.needsSponsorship],
        ["Relocation", id.willingToRelocate]
      ])
    );
    push(
      "Links",
      rows([
        ["LinkedIn", profile.links.linkedin],
        ["GitHub", profile.links.github],
        ["Portfolio", profile.links.portfolio]
      ])
    );
    profile.work.forEach((w, i) => {
      push(
        `Role \u2014 ${[w.title, w.company].filter(Boolean).join(", ") || `#${i + 1}`}`,
        rows([
          ["Title", w.title],
          ["Company", w.company],
          ["Location", w.location],
          ["Start", w.start],
          ["End", w.current ? "Present" : w.end],
          ["Experience", w.description, true]
        ])
      );
    });
    profile.education.forEach((e) => {
      push(
        `Education${e.school ? ` \u2014 ${e.school}` : ""}`,
        rows([
          ["School", e.school],
          ["Degree", e.degree],
          ["Field of study", e.fieldOfStudy],
          ["GPA", e.gpa]
        ])
      );
    });
    push("Skills", rows([["All skills", profile.skills.map((s) => s.label || s.q).join(", ")]]));
    push(
      "Answers",
      rows([
        ["Summary", profile.answers.summary, true],
        ["Why this company", profile.answers.whyCompany, true],
        ["Biggest strength", profile.answers.strength, true],
        ["Why looking", profile.answers.whyLeaving, true],
        ["Experience block", profile.answers.experienceBlock, true],
        ["Salary answer", salaryText(profile), true],
        ["Highlights", profile.answers.highlights, true]
      ])
    );
    return sections;
  }
  function renderDataPanel(profile, reason = "", draft, rescan, capture, jobText = "", draftCoverLetter, coverFill, scrapeJd) {
    ensureComponentStyles();
    document.getElementById("af-overlay")?.remove();
    document.getElementById("af-data")?.remove();
    const sections = profileSections(profile);
    const root = document.createElement("div");
    root.id = "af-data";
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-label", "Your resume data to copy and paste");
    root.innerHTML = `
    <style>
      #af-data {
        --bg: #fff; --surface: #f6f8fc; --text: #14161c; --muted: #55606f; --border: #d7dce5;
        --brand: #155dfc; --grad: linear-gradient(90deg, #155dfc, #0ea5a4);
        --warnbg: #fff7ed; --warnbd: #fed7aa; --warnfg: #7c2d12; --hover-ring: rgba(15,23,43,.42);
        --ok-fg: #15803d; --danger-fg: #b91c1c; --warn-fg: #8a5300;
        position: fixed; top: 16px; right: 16px; width: 350px; max-height: 88vh; overflow: auto;
        z-index: 2147483647; background: var(--bg); color: var(--text); border: 1px solid var(--border);
        border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,.25); font: 13px/1.45 -apple-system, Segoe UI, sans-serif; }
      @media (prefers-color-scheme: dark) {
        #af-data {
          --bg: #16213c; --surface: #111b33; --text: #e8edf6; --muted: #a6b6cd; --border: #2c3d60;
          --brand: #4b8bff; --grad: linear-gradient(90deg, #4b8bff, #2dd4bf);
          --warnbg: #3a2c12; --warnbd: #6b4e12; --warnfg: #fcd9a8; --hover-ring: rgba(255,255,255,.6);
          --ok-fg: #5bd88a; --danger-fg: #fca5a5; --warn-fg: #fbbf24; } }
      #af-data, #af-data * { line-height: 1.45; }
      #af-data header { position: sticky; top: 0; z-index: 1; background: var(--surface); color: var(--text);
        padding: 11px 12px; border-bottom: 1px solid var(--border); border-radius: 12px 12px 0 0;
        display: flex; align-items: center; gap: 9px; }
      #af-data .grip { cursor: move; font-size: 16px; color: var(--muted); letter-spacing: -3px; }
      #af-data .logo { width: 26px; height: 26px; border-radius: 7px; background: var(--grad); color: #fff;
        display: grid; place-items: center; font-weight: 800; font-size: 12px; flex: 0 0 auto; }
      #af-data header b { font-size: 14px; }
      #af-data .sub { font-size: 11px; color: var(--muted); }
      #af-data .rescan, #af-data .reset-job { background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;
        padding: 5px 10px; font: inherit; font-size: 11px; font-weight: 600; cursor: pointer; margin-right: 6px;
        transition: background .12s, color .12s, border-color .12s; }
      #af-data .rescan:hover { background: var(--brand); color: #fff; border-color: var(--brand); }
      #af-data .reset-job:hover { background: var(--warn-fg); color: #fff; border-color: var(--warn-fg); }
      #af-data .rescan:disabled { opacity: .7; cursor: default; background: var(--bg); color: var(--text); border-color: var(--border); }
      #af-data .spin { display: inline-block; width: 12px; height: 12px; border: 2px solid var(--border);
        border-top-color: var(--brand); border-radius: 50%; animation: af-spin .7s linear infinite; vertical-align: -1px; margin-right: 4px; }
      @keyframes af-spin { to { transform: rotate(360deg); } }
      #af-data .close { background: transparent; color: var(--muted); border: 0; font-size: 18px; cursor: pointer;
        padding: 0 4px; }
      #af-data .close:hover { color: var(--text); }
      #af-data .body { padding: 8px 12px 12px; }
      #af-data .dsec { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
        color: var(--brand); margin: 14px 2px 6px; }
      #af-data .body > .dsec:first-child { margin-top: 4px; }
      #af-data .drow { border: 1px solid var(--border); border-radius: 8px; padding: 8px; margin-bottom: 6px; background: var(--bg); }
      #af-data .dlab { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); }
      #af-data .dval { margin: 2px 0 6px; word-break: break-word; white-space: pre-wrap; }
      #af-data .dval.long { max-height: 72px; overflow: auto; font-size: 12px; color: var(--muted); }
      #af-data .copy { background: var(--surface); color: var(--text); border: 1px solid var(--border); border-radius: 6px;
        font-size: 11px; font-weight: 600; padding: 3px 10px; cursor: pointer;
        transition: background .12s, color .12s, border-color .12s, transform .06s; }
      #af-data .copy:hover { background: var(--brand); color: #fff; border-color: var(--brand); transform: translateY(-1px); }
      #af-data .copy:active { transform: translateY(1px); }
      #af-data :focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
      #af-data .diag { background: var(--warnbg); border: 1px solid var(--warnbd); color: var(--warnfg);
        border-radius: 8px; padding: 9px 10px; margin: 2px 0 12px; font-size: 12px; }
      #af-data .diag b { display: block; margin-bottom: 2px; }
    </style>
    <header>
      <span class="grip" aria-hidden="true">\u283F</span>
      <span class="logo" aria-hidden="true">CG</span>
      <div style="flex:1;min-width:0"><b>Your resume, on hand</b><div class="sub">We've got you \u2014 copy any field, paste it in. Drag this bar to move.</div></div>
      ${rescan ? `<button class="reset-job" type="button" title="Clear this application's saved company, role, job description and placeholders, then re-scan fresh. Your profile and saved documents are kept.">Reset job</button>` : ""}
      ${rescan ? `<button class="rescan" type="button" title="Scan this page for a form again">Scan this page</button>` : ""}
      <button class="close" title="Close (Esc)" aria-label="Close">\xD7</button>
    </header>
    <div class="body"></div>`;
    document.body.appendChild(root);
    applyThemeAttr(root);
    const body = root.querySelector(".body");
    if (reason) {
      const dg = document.createElement("div");
      dg.className = "diag";
      dg.setAttribute("role", "status");
      dg.innerHTML = `<b>Why autofill didn't run here</b>${esc(reason)}`;
      body.appendChild(dg);
    }
    if (draft) body.appendChild(askAiBlock(draft, jobText, draftCoverLetter, coverFill, scrapeJd));
    if (!sections.length) {
      body.innerHTML = `<div class="drow">No profile saved yet \u2014 open the extension's options and add your details.</div>`;
    }
    sections.forEach((sec) => {
      const h = document.createElement("div");
      h.className = "dsec";
      h.textContent = sec.title;
      body.appendChild(h);
      sec.rows.forEach((r) => {
        const d = document.createElement("div");
        d.className = "drow";
        d.innerHTML = `<div class="dlab">${esc(r.label)}</div><div class="dval${r.long ? " long" : ""}">${esc(r.value)}</div>`;
        d.appendChild(copyButton(() => r.value));
        body.appendChild(d);
      });
    });
    if (capture) body.appendChild(trackBlock(capture));
    root.querySelector(".close").addEventListener("click", () => root.remove());
    const resetJobBtn = root.querySelector(".reset-job");
    if (resetJobBtn && rescan) {
      resetJobBtn.addEventListener("click", async () => {
        resetJobBtn.disabled = true;
        resetJobBtn.innerHTML = `<span class="spin"></span>Clearing\u2026`;
        await clearContext();
        await clearPendingCoverFill();
        await rescan();
        if (resetJobBtn.isConnected) {
          resetJobBtn.disabled = false;
          resetJobBtn.textContent = "Reset job";
        }
      });
    }
    const rescanBtn = root.querySelector(".rescan");
    if (rescanBtn && rescan) {
      rescanBtn.addEventListener("click", async () => {
        rescanBtn.disabled = true;
        rescanBtn.innerHTML = `<span class="spin"></span>Scanning\u2026`;
        await rescan();
        if (rescanBtn.isConnected) {
          rescanBtn.disabled = false;
          rescanBtn.textContent = "Scan this page";
        }
      });
    }
    root.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") root.remove();
    });
    const hdr = root.querySelector("header");
    if (hdr) makeDraggable(root, hdr);
    root.tabIndex = -1;
    root.focus();
    return root;
  }

  // src/shared/tracking.ts
  function cleanUrl(raw) {
    try {
      const u = new URL(raw);
      return (u.origin + u.pathname).replace(/\/+$/, "");
    } catch {
      return raw.trim();
    }
  }

  // src/shared/capture.ts
  var txt = (el) => (el?.textContent ?? "").trim();
  function companyFromWorkdayHost(host) {
    const sub = host.split(".")[0] ?? "";
    if (!sub || /^wd\d*$/.test(sub)) return "";
    return sub.charAt(0).toUpperCase() + sub.slice(1);
  }
  function scrapeRole(board) {
    const header = txt(document.querySelector('[data-automation-id="jobPostingHeader"]')) || txt(document.querySelector("h1")) || (board === "greenhouse" ? txt(document.querySelector(".app-title")) : "");
    if (header) return header;
    return document.title.split(/\s+[-|–]\s+/)[0]?.trim() ?? "";
  }
  function scrapeCompany(board, host) {
    if (board === "workday") return companyFromWorkdayHost(host);
    const title = document.title;
    if (board === "ashby" || board === "greenhouse") {
      const seg = decodeURIComponent(location.pathname.split("/").filter(Boolean)[0] ?? "");
      if (seg && !/^(jobs?|en-us|external|careers)$/i.test(seg)) return seg;
    }
    const at = title.match(/\s(?:@|\bat)\s+(.+?)\s*$/i);
    if (at && at[1]) return at[1].trim();
    const parts = title.split(/\s+[-|–]\s+/).map((p) => p.trim());
    return parts.length > 1 ? parts[parts.length - 1] ?? "" : "";
  }
  function captureContext(board) {
    const host = location.hostname;
    const role = scrapeRole(board);
    let company = scrapeCompany(board, host);
    if (company && role && company.trim().toLowerCase() === role.trim().toLowerCase()) company = "";
    return { company, role, url: cleanUrl(location.href), board };
  }
  var tidy = (s) => s.replace(/\r/g, "").replace(/[ \t]{2,}/g, " ").replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  var JD_CAP = 1e4;
  var OUR_UI2 = "#af-overlay, #af-data, #af-editor, #af-notice";
  function looksLikeData(t) {
    const head = t.slice(0, 400);
    return /"pageProps"|__NEXT_DATA__|initialI18nStore|window\.__|^\s*[[{]"?/.test(head);
  }
  function longestText(selector) {
    let best = "";
    for (const el of document.querySelectorAll(selector)) {
      if (el.closest(OUR_UI2)) continue;
      const t = tidy(el.innerText || "");
      if (t.length > best.length && !looksLikeData(t)) best = t;
    }
    return best;
  }
  function captureJobDescription() {
    const specific = [
      '[data-automation-id="jobPostingDescription"]',
      // Workday
      '[class*="jobPostingDescription" i]',
      '[class*="_descriptionText" i]',
      // Ashby
      '[class*="job-description" i], [class*="jobDescription" i], [class*="job__description" i]',
      '[class*="posting" i][class*="description" i]',
      '[data-testid*="description" i], [data-testid*="posting" i]',
      // LinkedIn's markup (the collapsed body is usually still in the DOM).
      '[class*="show-more-less-html" i], [class*="jobs-description" i], [class*="jobs-box__html" i]',
      '[class*="description" i]'
    ].join(", ");
    const s = longestText(specific);
    if (s.length > 300) return s.slice(0, JD_CAP);
    const main = longestText('main, article, [role="main"], #content, #main-content, section');
    if (main.length > 300) return main.slice(0, JD_CAP);
    const parts = [];
    for (const child of Array.from(document.body?.children ?? [])) {
      const el = child;
      if (el.matches?.(OUR_UI2) || el.tagName === "SCRIPT" || el.tagName === "STYLE") continue;
      const t = el.innerText || "";
      if (!looksLikeData(t)) parts.push(t);
    }
    const body = tidy(parts.join("\n"));
    return body.length > 120 && !looksLikeData(body) ? body.slice(0, JD_CAP) : "";
  }

  // src/ai/bridge.ts
  var none = (items, reason) => items.map(() => ({ value: "", confidence: 0, reason, source: "none" }));
  async function resolveMany(items) {
    if (!items.length) return [];
    try {
      const res = await chrome.runtime.sendMessage({ type: "resolveFields", items });
      if (res && Array.isArray(res.results)) return res.results;
      throw new Error(res?.error ?? "no results");
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      console.debug("[autofill] model call failed:", msg);
      return none(items, "AI unavailable \u2014 write this one yourself (or turn on Ollama in Options)");
    }
  }

  // src/content/adapters/workday.ts
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  var q1 = (root, sel) => root.querySelector(sel);
  function resumeUpload(entry) {
    return attachResume(state.elements[entry.idx], verifyUpload);
  }
  async function verifyUpload() {
    for (let i = 0; i < 20; i++) {
      const item = document.querySelector('[data-automation-id="file-upload-item"]');
      if (item) {
        const success = item.querySelector('[data-automation-id="file-upload-successful"]');
        const nm = item.querySelector('[data-automation-id="file-upload-item-name"]');
        if (success || nm && nm.textContent?.trim()) return true;
      }
      await sleep2(150);
    }
    return false;
  }
  var container = () => document.querySelector('[data-automation-id="activeListContainer"]');
  var optionsIn = (c) => [
    ...c.querySelectorAll('[data-automation-id="promptOption"]')
  ];
  var labelOf = (o) => (o.getAttribute("data-automation-label") || o.textContent || "").trim();
  function isChecked(opt) {
    const mi = opt.closest('[data-automation-id="menuItem"]');
    const leaf = mi?.querySelector('[data-automation-id="promptLeafNode"]');
    return leaf?.getAttribute("data-automation-checked") === "Checked";
  }
  function queryToken(query) {
    const toks = query.toLowerCase().split(/[\s./]+/).filter(Boolean).sort((a, b) => b.length - a.length);
    return toks[0] || query.toLowerCase();
  }
  function clearSearch(input) {
    const scope = input.closest('[data-automation-id="multiSelectContainer"]') ?? document;
    const btn = scope.querySelector('[data-automation-id="clearSearchButton"]');
    if (btn) btn.click();
    else typeSearch(input, "");
  }
  async function waitForFresh(query, timeout = 3e3) {
    const tok = queryToken(query);
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const c = container();
      const opts = c ? optionsIn(c) : [];
      if (opts.length && opts.some((o) => labelOf(o).toLowerCase().includes(tok))) return c;
      await sleep2(140);
    }
    return container();
  }
  async function searchFor(input, query) {
    const tok = queryToken(query);
    const fresh = (c) => !!c && optionsIn(c).some((o) => labelOf(o).toLowerCase().includes(tok));
    for (let attempt = 0; attempt < 3; attempt++) {
      input.focus();
      clearSearch(input);
      await sleep2(180);
      typeSearch(input, query);
      const last = query.slice(-1) || "a";
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: last }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: last }));
      for (const type of ["keydown", "keyup"]) {
        input.dispatchEvent(
          new KeyboardEvent(type, { bubbles: true, key: "Enter", code: "Enter", keyCode: 13 })
        );
      }
      const c = await waitForFresh(query, 2600);
      if (fresh(c)) return c;
    }
    return container();
  }
  async function findOption(c, query, label) {
    const exact = (arr, t) => {
      if (!t) return null;
      const tt = t.trim().toLowerCase();
      return arr.find((o) => labelOf(o).toLowerCase() === tt) ?? null;
    };
    const paren = (arr, t) => {
      if (!t) return null;
      const tt = `(${t.trim().toLowerCase()})`;
      const m = arr.filter((o) => labelOf(o).toLowerCase().includes(tt));
      return m.length === 1 ? m[0] : null;
    };
    const probe = (arr) => exact(arr, label) || exact(arr, query) || exact(arr, query + ".js") || paren(arr, query) || paren(arr, label);
    c.scrollTop = 0;
    await sleep2(120);
    let prev = -1;
    for (let i = 0; i < 15; i++) {
      const hit = probe(optionsIn(c));
      if (hit) return hit;
      if (c.scrollTop === prev) break;
      prev = c.scrollTop;
      if (c.scrollTop + c.clientHeight >= c.scrollHeight - 4) break;
      c.scrollTop += c.clientHeight;
      await sleep2(160);
    }
    return probe(optionsIn(c));
  }
  async function locate(label) {
    const c = container();
    if (!c) return null;
    const norm = label.toLowerCase();
    const hit = () => optionsIn(c).find((o) => labelOf(o).toLowerCase() === norm);
    let cur = hit();
    if (cur) return cur;
    c.scrollTop = 0;
    await sleep2(90);
    let prev = -1;
    for (let i = 0; i < 16; i++) {
      cur = hit();
      if (cur) return cur;
      if (c.scrollTop === prev) break;
      prev = c.scrollTop;
      if (c.scrollTop + c.clientHeight >= c.scrollHeight - 4) break;
      c.scrollTop += c.clientHeight;
      await sleep2(120);
    }
    return hit() ?? null;
  }
  async function selectOption(opt) {
    const label = labelOf(opt);
    for (const kind of ["promptOption", "checkboxPanel", "promptLeafNode"]) {
      const cur = await locate(label);
      if (!cur) return false;
      if (isChecked(cur)) return true;
      const mi = cur.closest('[data-automation-id="menuItem"]');
      const target = kind === "promptOption" ? cur : mi?.querySelector(
        kind === "checkboxPanel" ? 'input[data-automation-id="checkboxPanel"]' : '[data-automation-id="promptLeafNode"]'
      );
      if (!target) continue;
      target.click();
      for (let i = 0; i < 8; i++) {
        await sleep2(200);
        const v2 = await locate(label);
        if (v2 && isChecked(v2)) return true;
      }
    }
    const v = await locate(label);
    return !!(v && isChecked(v));
  }
  async function skills(entry) {
    const input = document.getElementById("skills--skills") ?? state.elements[entry.idx];
    if (!input) return { ok: false, note: "skills input not found" };
    const list = state.profile.skills;
    if (!list.length) return { ok: false, note: "no skills in profile" };
    if (!claimRun("skills")) return { ok: false, note: "already running" };
    let added = 0;
    let already = 0;
    let aborted = false;
    const attempt = async (sk) => {
      const query = (sk.q || sk.label || "").trim();
      const label = (sk.label || sk.q || "").trim();
      if (!query) return "skip";
      const c = await searchFor(input, query);
      if (!c || !optionsIn(c).length) return "missed";
      const opt = await findOption(c, query, label);
      if (!opt) return "missed";
      if (isChecked(opt)) return "already";
      return await selectOption(opt) ? "added" : "missed";
    };
    let pending = list.slice();
    try {
      for (let round = 0; round < 3 && pending.length && !isAborted(); round++) {
        const next = [];
        for (const sk of pending) {
          if (isAborted()) {
            aborted = true;
            break;
          }
          const r = await attempt(sk);
          if (r === "added") added++;
          else if (r === "already") already++;
          else if (r === "missed") next.push(sk);
          await sleep2(120);
        }
        pending = next;
      }
    } finally {
      endRun();
    }
    const missNames = pending.map((s) => s.label || s.q);
    const note = `added ${added}, already had ${already}, missed ${pending.length}${aborted ? ", aborted" : ""}` + (pending.length ? ` \u2014 ${missNames.slice(0, 6).join(", ")}${pending.length > 6 ? "\u2026" : ""}` : "");
    console.log("[autofill][skills]", note);
    return { ok: added > 0 || already > 0, note, misses: pending };
  }
  var workSection = () => document.querySelector('[role="group"][aria-labelledby="Work-Experience-section"]');
  var eduSection = () => document.querySelector('[role="group"][aria-labelledby="Education-section"]');
  var certSection = () => document.querySelector('[role="group"][aria-labelledby="Certifications-section"]');
  var questionnaireSection = () => document.querySelector('[role="group"][aria-labelledby="primaryQuestionnaire-section"]');
  var panelsMatching = (re) => [...document.querySelectorAll('[role="group"][aria-labelledby$="-panel"]')].filter(
    (g2) => re.test(g2.getAttribute("aria-labelledby") || "")
  );
  var workPanels = () => panelsMatching(/Work-Experience-\d+-panel/);
  var eduPanels = () => panelsMatching(/Education-\d+-panel/);
  var certPanels = () => panelsMatching(/Certifications-\d+-panel/);
  function addPanel(section) {
    const btn = section?.querySelector('[data-automation-id="add-button"]');
    if (!btn) return false;
    btn.click();
    return true;
  }
  var parseDate = (s) => {
    const m = /^(\d{4})-(\d{1,2})(?:-(\d{1,2}))?/.exec(String(s || ""));
    return m ? { year: +m[1], month: +m[2], day: m[3] ? +m[3] : void 0 } : null;
  };
  function typeSpin(input, digits) {
    if (!input) return false;
    input.focus();
    Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set?.call(
      input,
      digits
    );
    input.dispatchEvent(new Event("input", { bubbles: true }));
    for (const ch of digits) {
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: ch }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: ch }));
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter" }));
    const display = input.parentElement?.querySelector('[data-automation-id$="-display"]');
    const txt2 = display ? (display.textContent ?? "").trim() : "";
    return /\d/.test(txt2) || input.value !== "";
  }
  function setDate(fieldEl, d) {
    if (!fieldEl || !d) return false;
    const month = fieldEl.querySelector(
      '[data-automation-id="dateSectionMonth-input"]'
    );
    const day = fieldEl.querySelector(
      '[data-automation-id="dateSectionDay-input"]'
    );
    const year = fieldEl.querySelector(
      '[data-automation-id="dateSectionYear-input"]'
    );
    let ok = true;
    if (month && d.month != null) ok = typeSpin(month, String(d.month).padStart(2, "0")) && ok;
    if (day && d.day != null) ok = typeSpin(day, String(d.day).padStart(2, "0")) && ok;
    if (year && d.year != null) ok = typeSpin(year, String(d.year)) && ok;
    return ok;
  }
  async function fillWorkPanel(panel, e) {
    const text2 = (aid, val) => {
      if (val == null || val === "") return;
      const el = panel.querySelector(
        `[data-automation-id="${aid}"] input, [data-automation-id="${aid}"] textarea`
      );
      if (el) commitWorkday(el, String(val));
    };
    text2("formField-jobTitle", e.title);
    text2("formField-companyName", e.company);
    text2("formField-location", e.location);
    const cw = panel.querySelector(
      '[data-automation-id="formField-currentlyWorkHere"] input[type="checkbox"]'
    );
    if (e.current) {
      if (cw && !cw.checked) cw.click();
    } else if (cw) {
      if (!cw.checked) {
        cw.click();
        await sleep2(160);
      }
      if (cw.checked) {
        cw.click();
        await sleep2(160);
      }
    }
    const sd = parseDate(e.start);
    if (sd) setDate(q1(panel, '[data-automation-id="formField-startDate"]'), sd);
    if (!e.current) {
      const ed = parseDate(e.end);
      if (ed) setDate(q1(panel, '[data-automation-id="formField-endDate"]'), ed);
    }
    text2("formField-roleDescription", e.description);
    await sleep2(120);
  }
  async function fillSectionPanels(tag, items, section, panels, fill, emptyNote) {
    if (!items.length) return { ok: false, note: emptyNote };
    if (!section()) return { ok: false, note: `no ${tag} section on this step` };
    if (!claimRun(tag)) return { ok: false, note: "already running" };
    let filled = 0;
    let aborted = false;
    const notes = [];
    try {
      for (let i = 0; i < items.length; i++) {
        if (isAborted()) {
          aborted = true;
          break;
        }
        let panel = panels()[i];
        if (!panel) {
          if (!addPanel(section())) {
            notes.push(`could not add panel ${i + 1}`);
            break;
          }
          await sleep2(450);
          panel = panels()[i];
          if (!panel) {
            notes.push(`panel ${i + 1} missing after add`);
            break;
          }
        }
        await fill(panel, items[i]);
        filled++;
        await sleep2(220);
      }
    } finally {
      endRun();
    }
    return {
      ok: filled > 0,
      note: `filled ${filled}/${items.length}${aborted ? ", aborted" : ""}${notes.length ? " \u2014 " + notes.join("; ") : ""}`
    };
  }
  var fillWorkExperience = () => fillSectionPanels(
    "Work Experience",
    state.profile.work,
    workSection,
    workPanels,
    fillWorkPanel,
    "no work history in profile"
  );
  function openOptions() {
    return [
      ...document.querySelectorAll(
        '[data-automation-id="promptOption"], li[role="option"], [role="option"]'
      )
    ].filter(
      (o) => !o.closest('[data-automation-id="selectedItemList"]') && o.getAttribute("data-automation-id") !== "selectedItem"
    );
  }
  var optLabel = (o) => (o.getAttribute("data-automation-label") || o.textContent || "").trim();
  function pickOption(list, value) {
    const want = value.trim().toLowerCase();
    if (!want) return null;
    const esc2 = want.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const labels = list.map((o) => optLabel(o).toLowerCase());
    let i = labels.indexOf(want);
    if (i < 0) i = labels.findIndex((l) => new RegExp("^" + esc2 + "\\b").test(l));
    if (i < 0) i = labels.findIndex((l) => new RegExp("\\b" + esc2 + "\\b").test(l));
    return i >= 0 ? list[i] : null;
  }
  async function pickFromListbox(button, value) {
    if (!button) return false;
    button.click();
    let list = [];
    for (let i = 0; i < 14; i++) {
      await sleep2(150);
      list = openOptions();
      if (list.length) break;
    }
    const opt = pickOption(list, value);
    if (opt) {
      opt.click();
      await sleep2(150);
      return true;
    }
    button.click();
    return false;
  }
  async function pickCombobox(input, value) {
    if (!input) return false;
    input.focus();
    typeSearch(input, value);
    for (const t of ["keydown", "keyup"]) {
      input.dispatchEvent(
        new KeyboardEvent(t, { bubbles: true, key: "Enter", code: "Enter", keyCode: 13 })
      );
    }
    let list = [];
    for (let i = 0; i < 16; i++) {
      await sleep2(160);
      list = openOptions();
      if (list.length) break;
    }
    const opt = pickOption(list, value);
    if (opt) {
      opt.click();
      await sleep2(150);
      return true;
    }
    return false;
  }
  function pickDegree(panel, degree) {
    const btn = panel.querySelector(
      '[data-automation-id="formField-degree"] button[aria-haspopup="listbox"]'
    );
    return pickFromListbox(btn, degree);
  }
  async function pickFieldOfStudy(panel, value) {
    const input = panel.querySelector(
      '[data-automation-id="formField-fieldOfStudy"] input'
    );
    if (!input) return false;
    const c = await searchFor(input, value);
    if (!c || !optionsIn(c).length) return false;
    const opt = await findOption(c, value, value);
    if (!opt) return false;
    return selectOption(opt);
  }
  async function fillEduPanel(panel, e) {
    const school = panel.querySelector('[data-automation-id="formField-schoolName"] input');
    if (school && e.school) commitWorkday(school, e.school);
    if (e.degree) await pickDegree(panel, e.degree);
    if (e.fieldOfStudy) await pickFieldOfStudy(panel, e.fieldOfStudy);
    const gpa = panel.querySelector('[data-automation-id="formField-gradeAverage"] input');
    if (gpa && e.gpa != null && e.gpa !== "") commitWorkday(gpa, String(e.gpa));
  }
  var fillEducation = () => fillSectionPanels(
    "Education",
    state.profile.education,
    eduSection,
    eduPanels,
    fillEduPanel,
    "no education in profile"
  );
  function dropdownValueFor(field) {
    const id = state.profile.identity;
    const hay = `${field.label || ""} ${field.automationId || ""}`.toLowerCase();
    if (/how did you hear/.test(hay)) return id.hearAboutUs;
    if (/phone code|country code/.test(hay)) return id.countryPhoneCode;
    if (/device type|phone type/.test(hay)) return id.phoneType;
    if (/\bcountry\b/.test(hay)) return id.country;
    if (/\bstate\b|region/.test(hay)) return id.state;
    return null;
  }
  async function pickDropdown(entry, value) {
    const el = state.elements[entry.idx];
    if (!el) return { ok: false, note: "field gone" };
    const ok = entry.field.type === "combobox" ? await pickCombobox(el, value) : await pickFromListbox(el, value);
    return {
      ok,
      note: ok ? `set "${value}"` : "could not pick \u2014 grab the open dropdown's options for me to tune"
    };
  }
  async function fillCertPanel(panel, c) {
    if (c.name) {
      const input = panel.querySelector(
        '[data-automation-id="formField-certification"] input'
      );
      if (input) {
        const cc = await searchFor(input, c.name);
        if (cc && optionsIn(cc).length) {
          const opt = await findOption(cc, c.name, c.name);
          if (opt) await selectOption(opt);
        }
      }
    }
    const num = panel.querySelector(
      '[data-automation-id="formField-certificationNumber"] input'
    );
    if (num && c.number) commitWorkday(num, String(c.number));
    const issued = parseDate(c.issued);
    if (issued) setDate(q1(panel, '[data-automation-id="formField-issuedDate"]'), issued);
    const noExp = !c.expiration || c.expiration === "none";
    const exp = noExp ? { year: 9999, month: 1, day: 1 } : parseDate(c.expiration);
    if (exp) setDate(q1(panel, '[data-automation-id="formField-expirationDate"]'), exp);
  }
  var fillCertifications = () => fillSectionPanels(
    "Certifications",
    state.profile.certifications,
    certSection,
    certPanels,
    fillCertPanel,
    "no certifications in profile"
  );
  var shortQ = (t) => {
    const s = (t || "").replace(/\s+/g, " ").trim();
    return s.length > 80 ? s.slice(0, 80) + "\u2026" : s;
  };
  function answerQuestion(text2, profile, prefs) {
    const id = profile.identity;
    const t = (text2 || "").toLowerCase();
    const Yes = (c) => ({ value: "Yes", confidence: c });
    const No = (c) => ({ value: "No", confidence: c });
    if (/over the age of 18|are you .*\b18\b/.test(t)) return Yes(0.97);
    if (/legally authorized to work/.test(t))
      return { value: id.workAuthorized || "Yes", confidence: 0.95 };
    if (/require .*sponsorship|sponsorship for an immigration/.test(t))
      return { value: id.needsSponsorship || "No", confidence: 0.95 };
    if (/resident of the state of maryland/.test(t)) return No(0.9);
    if (/highest .*security clearance|security clearance obtained/.test(t))
      return { value: "None", confidence: 0.8 };
    if (/currently or formerly employed by a general dynamics/.test(t))
      return { value: "None", confidence: 0.8 };
    if (/independent contractor or contract labor/.test(t)) return No(0.8);
    if (/relatives|close personal relationship/.test(t)) return No(0.8);
    if (/debarred or suspended/.test(t)) return No(0.85);
    if (/worked for the u\.?s\.? government|military active duty/.test(t)) return No(0.8);
    if (/foreign, state or local government/.test(t)) return No(0.8);
    if (/retained by the u\.?s\.? government/.test(t)) return No(0.8);
    const on = (k) => !!prefs[k]?.enabled;
    const pv = (k) => prefs[k]?.value || "";
    if (on("citizenship") && /citizen or national of the united states|export control|foreign person|lawfully admitted for permanent/.test(
      t
    ))
      return { value: pv("citizenship") || "Yes", confidence: 0.9 };
    if (on("willingToTravel") && /willing to travel/.test(t))
      return { value: pv("willingToTravel") || "Yes", confidence: 0.9 };
    if (on("willingToRelocate") && /willing to relocate/.test(t))
      return { value: pv("willingToRelocate") || "No", confidence: 0.9 };
    if (on("restrictiveAgreements") && /non-compet|agreements .*restrict your ability|non-solicit|non-disclosure/.test(t))
      return { value: pv("restrictiveAgreements") || "No", confidence: 0.9 };
    if (on("otherWork") && /perform work .*for any other company|other company or entity/.test(t))
      return { value: pv("otherWork") || "No", confidence: 0.9 };
    if (on("smsConsent") && /consent to receive telephone calls|text messages/.test(t))
      return { value: pv("smsConsent") || "No", confidence: 0.9 };
    if (on("signName") && /by typing your name|hereby certify/.test(t))
      return { value: `${id.firstName || ""} ${id.lastName || ""}`.trim(), confidence: 0.9 };
    if (on("salaryExpectations") && /salary expectations/.test(t))
      return {
        value: salaryText(profile) || "Negotiable",
        confidence: 0.85
      };
    return null;
  }
  function isSensitiveQuestion(text2) {
    const t = (text2 || "").toLowerCase();
    return /citizen or national of the united states|export control|foreign person|lawfully admitted for permanent|willing to travel|willing to relocate|non-compet|agreements .*restrict your ability|non-solicit|non-disclosure|perform work .*for any other company|other company or entity|consent to receive telephone calls|text messages|by typing your name|hereby certify|salary expectation|desired salary/.test(
      t
    );
  }
  async function fillApplicationQuestions() {
    const section = questionnaireSection();
    if (!section) return { ok: false, note: "no Application Questions section on this step" };
    if (!claimRun("appq")) return { ok: false, note: "already running" };
    const profile = state.profile;
    let answered = 0;
    let total = 0;
    let aiAnswered = 0;
    let aborted = false;
    const unresolved = [];
    try {
      const fields = [...section.querySelectorAll('[data-automation-id^="formField-"]')];
      for (const f of fields) {
        if (isAborted()) {
          aborted = true;
          break;
        }
        const rich = f.querySelector('[data-automation-id="richText"]');
        const qtext = rich ? (rich.textContent ?? "").trim() : (f.querySelector("legend")?.textContent ?? "").trim();
        if (!qtext) continue;
        total++;
        const btn = f.querySelector('button[aria-haspopup="listbox"]');
        const ta = f.querySelector("textarea");
        const ans = answerQuestion(qtext, profile, state.answerPrefs);
        if (ans && ans.value && ans.confidence >= 0.8) {
          const ok = btn ? await pickFromListbox(btn, ans.value) : ta ? commitWorkday(ta, ans.value) : false;
          if (ok) {
            answered++;
            console.log(`[autofill][appq] "${shortQ(qtext)}" -> ${ans.value}`);
            await sleep2(160);
            continue;
          }
        }
        unresolved.push({ qtext, btn, ta });
      }
      const aiTargets = unresolved.filter((u) => !isSensitiveQuestion(u.qtext));
      if (aiTargets.length && !isAborted()) {
        const lite = {
          identity: profile.identity,
          links: profile.links,
          compensation: profile.compensation,
          answers: profile.answers,
          recentRole: profile.work[0] ?? null,
          skills: profile.skills.map((s) => s.label || s.q)
        };
        const items = aiTargets.map((u) => ({
          kind: u.ta ? "generate" : "map",
          field: { label: u.qtext, type: u.ta ? "textarea" : "select" },
          profile: lite
        }));
        const results = await resolveMany(items);
        for (let i = 0; i < aiTargets.length; i++) {
          if (isAborted()) {
            aborted = true;
            break;
          }
          const r = results[i];
          const u = aiTargets[i];
          if (!r || !r.value || r.confidence < 0.7) continue;
          const ok = u.btn ? await pickFromListbox(u.btn, r.value) : u.ta ? commitWorkday(u.ta, r.value) : false;
          if (ok) {
            answered++;
            aiAnswered++;
            console.log(`[autofill][appq][ai] "${shortQ(u.qtext)}" -> ${r.value} (${r.confidence})`);
            await sleep2(160);
          }
        }
      }
    } finally {
      endRun();
    }
    const note = `answered ${answered}/${total}${aiAnswered ? ` (${aiAnswered} via AI)` : ""}${aborted ? ", aborted" : ""}. REVIEW each before continuing \u2014 these are legal attestations.`;
    return { ok: answered > 0, note };
  }
  function sectionActions() {
    const actions = [];
    const { work, education, certifications } = state.profile;
    if (workSection() && work.length)
      actions.push({ label: `Fill Work Experience (${work.length})`, run: fillWorkExperience });
    if (eduSection() && education.length)
      actions.push({ label: `Fill Education (${education.length})`, run: fillEducation });
    if (certSection() && certifications.length)
      actions.push({
        label: `Fill Certifications (${certifications.length})`,
        run: fillCertifications
      });
    if (questionnaireSection())
      actions.push({ label: "Answer standard Application Questions", run: fillApplicationQuestions });
    return actions;
  }
  function handlerFor(entry) {
    const f = entry.field;
    const hay = `${f.label || ""} ${f.group || ""} ${f.automationId || ""}`.toLowerCase();
    if (f.type === "file" && /resume|cv|attach|upload/.test(hay)) {
      return { label: "Upload resume", run: () => resumeUpload(entry) };
    }
    if (f.type === "combobox" && /skill/.test(hay)) {
      return {
        label: `Add ${state.profile.skills.length} skills from profile`,
        run: () => skills(entry)
      };
    }
    if (f.type === "listbox-button" || f.type === "combobox") {
      const val = dropdownValueFor(f);
      if (val) return { label: `Set "${val}"`, run: () => pickDropdown(entry, val) };
    }
    return null;
  }
  var workdayAdapter = { handlerFor, sectionActions };

  // src/content/adapters/greenhouse.ts
  var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
  function optionEls(input) {
    const listId = input.getAttribute("aria-controls");
    let els = [];
    if (listId) els = [...document.querySelectorAll(`#${CSS.escape(listId)} [role="option"]`)];
    if (!els.length)
      els = [...document.querySelectorAll('.select__menu [role="option"], .select__option')];
    return els;
  }
  async function pickReactSelect(input, value) {
    const control = input?.closest(".select__control");
    if (!input || !control) return false;
    input.focus();
    fireMouse(control, ["pointerdown", "mousedown", "mouseup"]);
    let opts = [];
    for (let i = 0; i < 20 && !opts.length; i++) {
      await sleep3(120);
      opts = optionEls(input);
    }
    let opt = opts.find((o) => optionMatches(o.textContent || "", value));
    if (!opt) {
      setNativeValue(input, value);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      for (let i = 0; i < 20; i++) {
        await sleep3(140);
        opts = optionEls(input);
        opt = opts.find((o) => optionMatches(o.textContent || "", value));
        if (opt) break;
      }
    }
    if (!opt) return false;
    const wanted = opt.textContent?.trim() || "";
    fireMouse(opt, ["pointerdown", "mousedown", "mouseup", "click"]);
    await sleep3(150);
    const shown = control.querySelector(".select__single-value")?.textContent?.trim() || "";
    return shown === wanted;
  }
  function dropdownValueFor2(field) {
    const det = match(field, state.profile);
    return det && det.value ? det.value : null;
  }
  async function pickDropdown2(entry, value) {
    const el = state.elements[entry.idx];
    const ok = await pickReactSelect(el, value);
    return {
      ok,
      note: ok ? `set "${value}"` : "could not pick \u2014 leave it for manual selection"
    };
  }
  function handlerFor2(entry) {
    const f = entry.field;
    const hay = `${f.label} ${f.group} ${f.id} ${f.name}`.toLowerCase();
    if (f.type === "file" && /resume|cv/.test(hay) && !/cover/.test(hay)) {
      return {
        label: "Upload resume",
        run: () => attachResume(state.elements[entry.idx])
      };
    }
    if (f.type === "combobox") {
      const val = dropdownValueFor2(f);
      if (val) return { label: `Set "${val}"`, run: () => pickDropdown2(entry, val) };
    }
    return null;
  }
  function sectionActions2() {
    return [];
  }
  var greenhouseAdapter = { handlerFor: handlerFor2, sectionActions: sectionActions2 };

  // src/content/adapters/ashby.ts
  var sleep4 = (ms) => new Promise((r) => setTimeout(r, ms));
  async function pickTypeahead(input, query, state2) {
    input.focus();
    setNativeValue(input, query);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    let opts = [];
    for (let i = 0; i < 25 && !opts.length; i++) {
      await sleep4(160);
      opts = [...document.querySelectorAll('[role="option"]')];
    }
    const withCity = opts.filter((o) => optionMatches(o.textContent || "", query));
    const pick = (state2 ? withCity.find((o) => optionMatches(o.textContent || "", state2)) : void 0) ?? withCity[0];
    if (!pick) return false;
    const wanted = (pick.textContent || "").trim();
    fireMouse(pick, ["pointerdown", "mousedown", "mouseup", "click"]);
    await sleep4(250);
    return input.value.trim() === wanted;
  }
  async function fillLocation(entry) {
    const el = state.elements[entry.idx];
    if (!el) return { ok: false, note: "field gone" };
    const { city, state: st } = state.profile.identity;
    if (!city) return { ok: false, note: "no city in profile" };
    const ok = await pickTypeahead(el, city, st);
    return { ok, note: ok ? `set location to ${el.value}` : "could not match a location option" };
  }
  async function fillTypeaheadValue(entry, value) {
    const el = state.elements[entry.idx];
    if (!el) return { ok: false, note: "field gone" };
    const ok = await pickTypeahead(el, value, "");
    return { ok, note: ok ? `set to "${el.value}"` : "couldn't match that answer \u2014 pick it yourself" };
  }
  function handlerFor3(entry) {
    const f = entry.field;
    const hay = `${f.label} ${f.group} ${f.id} ${f.name} ${f.placeholder} ${f.testId ?? ""}`.toLowerCase();
    if (f.type === "file" && /resume|cv/.test(hay) && !/cover/.test(hay)) {
      return {
        label: "Upload resume",
        run: () => attachResume(state.elements[entry.idx])
      };
    }
    if (f.type === "combobox" && /location|city|where/.test(hay) && state.profile.identity.city) {
      return { label: `Set location (${state.profile.identity.city})`, run: () => fillLocation(entry) };
    }
    if (f.type === "combobox" && /authoriz|lawfully|eligible to work|work in the u\.?s|\bvisa\b|sponsor/.test(hay)) {
      const wa = state.answerPrefs.workAuth;
      if (wa?.enabled && wa.value) {
        const v = wa.value;
        const short = v.length > 26 ? `${v.slice(0, 24)}\u2026` : v;
        return { label: `Set work auth: ${short}`, run: () => fillTypeaheadValue(entry, v) };
      }
    }
    return null;
  }
  function sectionActions3() {
    return [];
  }
  var ashbyAdapter = { handlerFor: handlerFor3, sectionActions: sectionActions3 };

  // src/content/adapters/generic.ts
  var FILE_ACCEPT = ".pdf,.doc,.docx";
  function openNativePicker(el) {
    if (!el) return false;
    el.click();
    return true;
  }
  function handlerFor4(entry) {
    const f = entry.field;
    const hay = `${f.label} ${f.group} ${f.id} ${f.name} ${f.placeholder} ${f.automationId} ${f.testId ?? ""}`.toLowerCase();
    const fileEl = () => {
      const cached = state.elements[entry.idx];
      if (cached && cached.isConnected) return cached;
      const tid = (f.testId || "").split(/\s+/)[0];
      if (tid) {
        const live = document.querySelector(`input[data-testid="${CSS.escape(tid)}"]`);
        if (live) return live;
      }
      if (f.id) {
        const byId = document.getElementById(f.id);
        if (byId instanceof HTMLInputElement) return byId;
      }
      if (f.name) {
        const byName = document.querySelector(`input[name="${CSS.escape(f.name)}"]`);
        if (byName) return byName;
      }
      return cached;
    };
    if (f.type === "file" && /cover.?letter|coverletter|motivation|letter of (?:intent|interest|motivation)/.test(hay)) {
      return {
        label: "Use saved cover letter",
        // GATE: never attach the saved template while it still has our template
        // placeholders ([Company]/[Role]/[Date]). This is the hard stop behind the
        // warning — applies to the button AND any bulk run — so a bracketed letter can't
        // be uploaded. The user swaps them via "Fill my cover letter" and attaches that.
        run: async () => {
          const ph = (await chrome.storage.local.get("coverLetterPlaceholders")).coverLetterPlaceholders;
          if (ph?.length) {
            return {
              ok: false,
              note: `Your saved cover letter still has ${ph.join(", ")}. Use \u201CFill my cover letter\u201D to swap them, then attach that \u2014 I won't upload a letter with unfilled placeholders.`
            };
          }
          return attachCoverLetter(fileEl());
        },
        runWithFile: (file) => attachPickedFile(fileEl(), file),
        accept: FILE_ACCEPT,
        hasDefault: () => hasStoredFile("coverLetterFile"),
        manualOnly: true,
        openPagePicker: () => openNativePicker(fileEl()),
        reminder: async () => {
          if ((await loadConfirmed()).coverAttached) return null;
          const ph = (await chrome.storage.local.get("coverLetterPlaceholders")).coverLetterPlaceholders;
          return ph?.length ? `Reminder: your saved cover letter still has ${ph.join(", ")} in it \u2014 update it before submitting.` : null;
        }
      };
    }
    if (f.type === "file" && /r[eé]sum[eé]|\bcv\b|curriculum\s*vitae/.test(hay)) {
      return {
        label: "Use saved resume",
        run: () => attachResume(fileEl()),
        runWithFile: (file) => attachPickedFile(fileEl(), file),
        accept: FILE_ACCEPT,
        hasDefault: () => hasStoredFile("resumeFile"),
        openPagePicker: () => openNativePicker(fileEl())
      };
    }
    if (f.type === "file") {
      return {
        label: "Attach file",
        run: async () => ({ ok: false, note: "Choose a file with the buttons below." }),
        runWithFile: (file) => attachPickedFile(fileEl(), file),
        accept: FILE_ACCEPT,
        hasDefault: () => Promise.resolve(false),
        manualOnly: true,
        openPagePicker: () => openNativePicker(fileEl())
      };
    }
    return null;
  }
  function sectionActions4() {
    return [];
  }
  var genericAdapter = { handlerFor: handlerFor4, sectionActions: sectionActions4 };

  // src/content/run.ts
  function adapterFor(board) {
    if (board === "workday") return workdayAdapter;
    if (board === "greenhouse") return greenhouseAdapter;
    if (board === "ashby") return ashbyAdapter;
    return genericAdapter;
  }
  function notice(msg) {
    document.getElementById("af-notice")?.remove();
    const n = document.createElement("div");
    n.id = "af-notice";
    n.textContent = msg;
    n.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;max-width:360px;background:#1f2430;color:#fff;padding:12px 14px;border-radius:10px;font:13px/1.4 -apple-system,Segoe UI,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.3)";
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 6e3);
  }
  var hostOf = (src) => {
    try {
      return new URL(src, location.href).hostname.replace(/^www\./, "");
    } catch {
      return "another site";
    }
  };
  function whyNoFill() {
    const iframes = [...document.querySelectorAll("iframe")].filter((f) => f.src);
    const ATS = /ashby|greenhouse|lever|workday|myworkday|icims|jobvite|smartrecruiters|bamboohr|breezy|teamtailor/i;
    const ats = iframes.find((f) => ATS.test(f.src));
    if (ats)
      return `This application is embedded from ${hostOf(ats.src)} inside this page. If the form there didn't fill on its own, Chrome is blocking autofill across that frame \u2014 copy your details below and paste them in.`;
    const crossOrigin = iframes.find((f) => {
      try {
        return new URL(f.src, location.href).origin !== location.origin;
      } catch {
        return false;
      }
    });
    if (crossOrigin)
      return `The form here sits inside an embedded frame from ${hostOf(crossOrigin.src)}, which Chrome won't let me fill directly. Copy your details below instead.`;
    return `I couldn't find any application fields on this page. If the form only appears after a step (like clicking "Apply"), open that step and run me again. Your saved details are below to copy in the meantime.`;
  }
  async function run() {
    if (!claimRun("run")) return;
    try {
      const { profile, answerPrefs } = await chrome.storage.local.get(["profile", "answerPrefs"]);
      if (!profile) {
        notice(
          "No profile saved yet. Open the extension's options page and click Save once, then run again."
        );
        return;
      }
      const prof = normalize(profile);
      state.profile = prof;
      state.answerPrefs = answerPrefs || {};
      const draft = async (questions, jobText2) => {
        const lite = liteProfile(prof);
        const res = await resolveMany(
          questions.map((question) => ({
            kind: "generate",
            field: { label: question, type: "textarea", group: "", options: void 0, required: false },
            profile: lite,
            jobContext: jobText2 || void 0
          }))
        );
        return res.map((r) => r?.value ?? "");
      };
      const draftCoverLetter = async (prompts, jobText2) => {
        const res = await chrome.runtime.sendMessage({
          type: "af:coverLetter",
          items: prompts.map((p) => ({
            kind: "generate",
            field: { label: p, type: "textarea", group: "", options: void 0, required: false },
            profile: liteProfile(prof),
            jobContext: jobText2 || void 0
          }))
        }).catch(() => null);
        if (res?.error) throw new Error(res.error);
        return res?.drafts ?? [];
      };
      const fields = scan();
      const board = boardFromHost();
      const adapter = adapterFor(board);
      const confirmed = await loadConfirmed();
      console.debug("[autofill] jobKey", debugJobKey());
      const hasSections = !!adapter && adapter.sectionActions().length > 0;
      if (!fields.length && !hasSections) {
        if (window.top !== window.self) return;
        if (document.querySelector("iframe")) {
          for (let i = 0; i < 6; i++) {
            const r = await chrome.runtime.sendMessage({ type: "af:wasHandled" }).catch(() => null);
            if (r?.handled) return;
            await new Promise((res) => setTimeout(res, 180));
          }
        }
        const cap = captureContext(board);
        cap.company = preferConfirmed(confirmed.company, cap.company);
        cap.role = preferConfirmed(confirmed.role, cap.role);
        const jd = confirmed.jobText ?? "";
        renderDataPanel(
          prof,
          whyNoFill(),
          draft,
          run,
          cap,
          jd,
          draftCoverLetter,
          { company: cap.company, role: cap.role },
          () => captureJobDescription()
        );
        return;
      }
      const capture = captureContext(board);
      capture.company = preferConfirmed(confirmed.company, capture.company);
      capture.role = preferConfirmed(confirmed.role, capture.role);
      const jobText = confirmed.jobText ?? "";
      const jobContext = [
        capture.company ? `Company: ${capture.company}` : "",
        capture.role ? `Role: ${capture.role}` : "",
        jobText
      ].filter(Boolean).join("\n\n");
      const { plan, pending } = planFields(fields, prof, jobContext);
      const resolveEssays = async () => {
        if (!pending.length) return;
        await resolvePending(pending, resolveMany);
        pending.forEach(({ entry }) => view.update(entry));
      };
      const regenerate = (jobText2) => {
        if (!pending.length) return;
        const ctx = [
          capture.company ? `Company: ${capture.company}` : "",
          capture.role ? `Role: ${capture.role}` : "",
          jobText2
        ].filter(Boolean).join("\n\n");
        pending.forEach((p) => {
          p.item.jobContext = ctx;
          Object.assign(p.entry, { pending: true, value: "", reason: "thinking\u2026" });
          view.update(p.entry);
        });
        void resolveEssays().catch((err) => console.debug("[autofill] regenerate failed", err));
      };
      const view = render(plan, {
        board,
        adapter,
        rescan: run,
        capture,
        regenerate: pending.length ? regenerate : void 0,
        draft,
        draftCoverLetter,
        coverFill: { company: capture.company, role: capture.role },
        jobText,
        scrapeJd: () => captureJobDescription()
      });
      void chrome.runtime.sendMessage({ type: "af:handled" }).catch(() => {
      });
      console.log("[autofill] plan", plan.summary);
      void resolveEssays().catch((err) => console.debug("[autofill] model resolve failed", err));
    } catch (e) {
      console.error("[autofill] run failed", e);
      notice("Autofill hit an error: " + (e instanceof Error ? e.message : String(e)));
    } finally {
      endRun();
    }
  }

  // src/content/content.ts
  void run();
})();
